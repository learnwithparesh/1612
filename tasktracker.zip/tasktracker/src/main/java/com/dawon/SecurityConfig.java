package com.dawon;

import org.springframework.context.annotation.Configuration;

@Configuration
	public class SecurityConfig //extends WebSecurityConfigurerAdapter {
	{
	  //  @Inject private SecurityProperties securityProperties;

	   // @Override
	   // protected void configure(HttpSecurity http) throws Exception {
	   //     if (securityProperties.isRequireSsl()) http.requiresChannel().anyRequest().requiresSecure();
	  //  }
	}