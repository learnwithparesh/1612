package com.dawon.service;

import java.nio.file.Path;
import java.util.stream.Stream;
 
import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;
 
public interface FileStorage {
	public void store(MultipartFile file);
	public void store1(MultipartFile file, String pt);
	public Resource loadFile(String filename, String pt);
	public void deleteAll(String pt);
	public void init(String pt);
	public Stream<Path> loadFiles(String pt);
}
