package com.dawon.service;

import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.FileSystemUtils;
import org.springframework.web.multipart.MultipartFile;

@Service
public class FileStorageImpl implements FileStorage{
	
	/*
	 * @Value("${serviceURL}") private String UPLOADED_FOLDER;
	 */
	
	//private final Path rootLocation = Paths.get("E:/dawon 9-14-2019/Projects/tasktracker project/uploadfile");
	
	Logger log = LoggerFactory.getLogger(this.getClass().getName());
	private Path rootLocation;
	/*
	 * private final Path rootLocation =
	 * Paths.get("E:/dawon 9-14-2019/Projects/tasktracker project/uploadfile");
	 * 
	 * @Override public void store(MultipartFile file){ try {
	 * System.out.println("paths"+rootLocation); Files.copy(file.getInputStream(),
	 * this.rootLocation.resolve(file.getOriginalFilename()),
	 * StandardCopyOption.REPLACE_EXISTING); } catch (Exception e) { throw new
	 * RuntimeException("FAIL! -> message = " + e.getMessage()); } }
	 */
	
	@Override
	public void store1(MultipartFile file, String pt){
	
		try {
			
			Path rootlo=Paths.get(pt);
			//System.out.println("location of files" +rootlo);
            Files.copy(file.getInputStream(), rootlo.resolve(file.getOriginalFilename()), StandardCopyOption.REPLACE_EXISTING);
        } catch (Exception e) {
        	throw new RuntimeException("FAIL! -> message = " + e.getMessage());
        }
	}
	
	@Override
    public Resource loadFile(String filename, String pt) {
        try {
            Path file = Paths.get(pt);
            Resource resource = new UrlResource(file.toUri());
            if(resource.exists() || resource.isReadable()) {
                return resource;
            }else{
            	throw new RuntimeException("FAIL!");
            }
        } catch (MalformedURLException e) {
        	throw new RuntimeException("Error! -> message = " + e.getMessage());
        }
    }
    
	@Override
    public void deleteAll(String pt) {
		rootLocation = Paths.get(pt);
        FileSystemUtils.deleteRecursively(rootLocation.toFile());
    }

	@Override
    public void init(String pt) {
		rootLocation = Paths.get(pt);
        try {
            Files.createDirectory(rootLocation);
        } catch (IOException e) {
            throw new RuntimeException("Could not initialize storage!");
        }
    }

	@Override
	public Stream<Path> loadFiles(String pt) {
        try {
        	rootLocation = Paths.get(pt);
            return Files.walk(this.rootLocation, 1)
                .filter(path -> !path.equals(this.rootLocation))
                .map(this.rootLocation::relativize);
        }
        catch (IOException e) {
        	throw new RuntimeException("\"Failed to read stored file");
        }
	}

	@Override
	public void store(MultipartFile file) {
		// TODO Auto-generated method stub
		
	}
}