package com.dawon.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dawon.model.TaskType;
import com.dawon.repositories.TaskTypeRepository;

@RestController
public class TaskTypeController
{
	@Autowired
	TaskTypeRepository tRepo;
	
	@RequestMapping(value = "/showtasktype")
	public List<TaskType> gettask() 
	{
		//System.out.println( "in gettask()");	
		List<TaskType> tasktype = (List<TaskType>) tRepo.findTop5TaskType();
		return tasktype;
	}

}
