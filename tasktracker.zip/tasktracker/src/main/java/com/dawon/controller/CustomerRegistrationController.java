package com.dawon.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.apache.tomcat.util.http.parser.MediaType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.dawon.model.Customer;
import com.dawon.model.Employee;
import com.dawon.model.Property;
import com.dawon.repositories.CustomerRegistrationRepository;

@RestController
public class CustomerRegistrationController 
{
	@Autowired
	CustomerRegistrationRepository custRepo;
	


	@RequestMapping(value="/customerregistration",method = RequestMethod.POST)
	public Customer registerCustomer(@RequestBody Customer customer) throws IOException
	{
		//System.out.println(file.getName()+"file name");
	
		//System.out.println(customer.getPic() +"pic:::::: " +""+customer.getPic().length);
		//System.out.println(customer.getfile() +""+ customer.getfile().length);
		
		byte[] bytes = customer.getPic();
		
		Customer customer1 = new  Customer(customer.getId(),customer.getName(),customer.getEmail(), customer.getContactnumber(), customer.getGender(),customer.getBdate(), customer.getCaddress(), customer.getPaddress(),customer.getadhaarCard(),customer.getPic());
		
		Set<Property> userProfiles = new HashSet<Property>();

		for (Property sp : customer.getProperty()) {
			//System.out.println("hi hi :"+sp.getPropid());
			//System.out.println(sp.getVillages()+"village id");
			Property purpro = sp;
		//	purpro.setVillages(sp.getVillages());
			purpro.setCustomer(customer1);
			userProfiles.add(purpro);
		}
		customer1.setProperty(userProfiles);
		return custRepo.save(customer1);
	}
	
	//, consumes = {"multipart/form-data" } , headers = ("content-type=multipart/form-data") consumes={"application/json"}

	
	//@RequestMapping(value="/customerregistration", method = RequestMethod.POST,consumes = MediaType.MULTIPART_FORM_DATA)//consumes = { "multipart/form-data",}
    /* @RequestMapping(value = "/customerregistration", method = RequestMethod.POST,produces = {MediaType.APPLICATION_JSON}, headers = ("content-type=multipart/*"))//, headers = ("content-type=multipart/form-data")
	 public @ResponseBody String saveUserDataAndFile(@RequestParam("file") MultipartFile file, @RequestPart Customer customer) throws IOException
	{
    	 
    	     System.out.println("output: "+customer.getName() + " files" +file);
    	     
    	             // Im Still wotking on it
    	     return "";*/
    	
	//	System.out.println(file.getSize() +"filesize");
	/*	System.out.println(customer.getName() +"name");
     Customer customer1 = new  Customer(customer.getName(),customer.getEmail(), customer.getContact_number(), customer.getGender(),customer.getBdate(), customer.getC_address(), customer.getP_address(),customer.getadhaarCard(),customer.getfile());
		
		Set<Property> userProfiles = new HashSet<Property>();

		for (Property sp : customer.getProperty()) {
			//System.out.println("hi hi :"+sp.getPropid());
			Property purpro = sp;
			purpro.setCustomer(customer1);
			userProfiles.add(purpro);
		}
		customer1.setProperty(userProfiles);
		return custRepo.save(customer1);*/
	//}
	
  
	
	
	@RequestMapping("/getallcustomers")
	  public ArrayList<Customer> getAllRooms() {
	    return (ArrayList<Customer>) custRepo.findAll();
	  }
	

	@RequestMapping("/getCustCount")
	  public long getCustCount() {
	    return custRepo.count();
	  }
	
	@RequestMapping("/getallcustomers/{adhaar}")
	  public List<Customer> findByCustomer(@PathVariable("adhaar") String adhaar) {
		//System.out.println(adhaar +"adhaar card number");
		//return (ArrayList<Customer> custRepo.findAll());
	  // return (ArrayList<Customer>) custRepo.findByCustomer(adhaar);
		
		List<Customer> customer1 = custRepo.findByAdhaarCard(adhaar);
		for (Customer customer : customer1) {
			System.out.println("customer details" + customer.getadhaarCard() +"Name: " + customer.getName()+"address" + customer.getCaddress());
		}
		
		
		return customer1;
	  }
	
	@RequestMapping("/papdetails/{id}")
	  public Customer findByCustomerid(@PathVariable long id) {
		
		
		Optional<Customer> custOptional = custRepo.findById(id); 
		if (!custOptional.isPresent()) 
			return null;
		
		Customer cust1 = custOptional.get();
		
		return cust1;	
	  
	  }
	
	

}
