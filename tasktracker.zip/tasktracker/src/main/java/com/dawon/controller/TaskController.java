package com.dawon.controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.TimeZone;

import javax.persistence.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dawon.model.Customer;
import com.dawon.model.Employee;
import com.dawon.model.Project;
import com.dawon.model.Property;
import com.dawon.model.Task;
import com.dawon.model.TaskType;
import com.dawon.model.Villages;
import com.dawon.model.Workflow;
import com.dawon.repositories.CalenderTask;
import com.dawon.repositories.EmployeeRepository;
import com.dawon.repositories.MyTask;
import com.dawon.repositories.ProjectRepository;
import com.dawon.repositories.Tapaltask;
import com.dawon.repositories.TaskRepository;
import com.dawon.repositories.WorkflowRepository;

@RestController
public class TaskController {
	@Autowired
	TaskRepository taskRepo;

	@Autowired
	WorkflowRepository workflowrepo;

	@Autowired
	ProjectRepository projectRepo;

	@Autowired
	EmployeeRepository emprepo;
	// private static String UPLOAD_DIR = System.getProperty("user.home") + "/test";
	boolean check = false;

	@RequestMapping(value = "/saveTask", method = RequestMethod.POST)
	public Task saveTaskDetails(@RequestBody Task task) {
		Task task1 = new Task();
		Date date = new Date();

		// System.out.println(task.getLetterdate() + "task letter date");

		if (task.getCustomer().getId() == 0) {
			//task.setTtype(2);
			// task.setTapal(0);
			task1.setStartDate(date);

			task1 = new Task(2, task.getStartDate(), task.getEndDate(), task.getFinaldate(), task.getCompletedate(),
					task.getStatus(), task.getInsertby(), task.getInsertdate(), task.getUpdateby(),
					task.getUpdatedate(), task.getTname(), task.getNoticolor(), task.getAssignto(), task.getColor(),
					task.getCaseno(), task.getCasestartdate(), task.getCasesubmissiondate(), task.getCasesubject(),
					task.getCurtnotification(), task.getInwordno(), task.getInworddate(), task.getLetterdate(),
					task.getArrivedfrom(), task.getSender(), task.getLettertype(), task.getBranch(),
					task.getLettersubject(), task.getLetterdeliverytype(), task.getFilesid(), task.getPapchecked(),
					task.getAssignto(), task.getProject(), task.getTasktype(), task.getEmployee());

		}

		else {
			//task.setTtype(1);
			// task.setTapal(0);

			task1 = new Task(1, task.getStartDate(), task.getEndDate(), task.getFinaldate(), task.getCompletedate(),
					task.getStatus(), task.getInsertby(), task.getInsertdate(), task.getUpdateby(),
					task.getUpdatedate(), task.getTname(), task.getNoticolor(), task.getAssignto(), task.getColor(),
					task.getCaseno(), task.getCasestartdate(), task.getCasesubmissiondate(), task.getCasesubject(),
					task.getCurtnotification(), task.getInwordno(), task.getInworddate(), task.getLetterdate(),
					task.getArrivedfrom(), task.getSender(), task.getLettertype(), task.getBranch(),
					task.getLettersubject(), task.getLetterdeliverytype(), task.getFilesid(), task.getPapchecked(),
					task.getAssignto(), task.getCustomer(), task.getProject(), task.getTasktype(), task.getEmployee(),
					task.getPropertyid());

		}

		if (task.getAssignto().getId() != 0) {
			// long c2 = Long.valueOf(task.getAssignto());
			// Optional<Employee> taskoptional2 =
			// emprepo.findById(task.getAssignto().getId());
			Employee e2 = task.getAssignto();

         System.out.println("insert by: "+task.getInsertby());
			long c1 = Long.valueOf(task.getInsertby());
			
			Optional<Employee> taskoptional = emprepo.findById(c1);
			Employee e = taskoptional.get();
			Workflow w = new Workflow();
			w.setTask(task1);
			w.setTitle("New Task Added");
			w.setNstatus("1");
			w.setTstatus("3");
			w.setTask_to(e2);
			w.setTask_from(e);

			w.setNoticode(task.getNoticolor());
			workflowrepo.save(w);
		}

	//	System.out.println("task type: " + task1.getTtype());
		int thu = taskRepo.storedcalled1(task1.getId(), task1.getTtype());

		task1.setTapal(thu);
		task1 = taskRepo.save(task1);

		return task1;

	}

	//@RequestMapping(value = "/gettasks/{id}/{rid}")
	
	/*
	 * public List<Task1> getemptask(@PathVariable long id, @PathVariable long rid)
	 * { long taskid; // System.out.println("uid: " +id); // } List<Task> task = new
	 * ArrayList<>();
	 * 
	 * List<Task1> task = new ArrayList<>();
	 * 
	 * 
	 * if (rid == 1 || rid == 4) {
	 * 
	 * 
	 * // task = taskRepo.findByAllEmployee1();
	 * 
	 * task = taskRepo.findbyrole(id);
	 * 
	 * 
	 * for (Task1 task2 : task) { // System.out.println("task id : "+task2.getId());
	 * taskid = task2.getId();
	 * 
	 * List<String> workflow = new ArrayList<>();
	 * 
	 * List<Object[]> list = workflowrepo.findBylastassign(taskid); String tf1 =
	 * null; String tf2 = null; String maxdates = null;
	 * 
	 * tf1 = String.valueOf(list.get(0)[0]); tf2 = String.valueOf(list.get(0)[1]);
	 * maxdates = String.valueOf(list.get(0)[2]);
	 * System.out.println("date from database: " + maxdates); Date date1 = null;
	 * Date utilDate = null; SimpleDateFormat formatter = new
	 * SimpleDateFormat("dd/MM/yyyy");
	 * 
	 * try { Date date4 = new SimpleDateFormat("yyyy-MM-dd").parse(maxdates); }
	 * //System.out.println("date4 : " + date4);
	 * 
	 * task2.setCurrentMaxDate(date4); // System.out.println("hi hi" +
	 * task2.getCurrentMaxDate()); } catch (ParseException e) { // TODO
	 * Auto-generated catch block e.printStackTrace(); }
	 * 
	 * // System.out.println("value of tf1: " + tf1 + " value of id " + id +
	 * "status = " + task2.getStatus());
	 * 
	 * if (tf1.equalsIgnoreCase(String.valueOf(id)) && task2.getStatus() == 2) { //
	 * System.out.println( "status = " + task2.getStatus()); task2.setColor("gray");
	 * //task2.setStartDate(date1);
	 * 
	 * } else if (task2.getStatus() != 0 && task2.getStatus() != 1 &&
	 * task2.getStatus() != 4 && task2.getStatus() != 5) {
	 * task2.setColor("#007bffb8"); //task2.setStartDate(date1); } else if
	 * (task2.getStatus() == 4 && task2.getStatus() != 5) {
	 * //System.out.println("status = " + task2.getStatus());
	 * task2.setColor("#F88017"); //task2.setStartDate(date1); } else if
	 * (task2.getStatus() == 5) { //System.out.println("status = " +
	 * task2.getStatus()); task2.setColor("#7D6608"); //task2.setStartDate(date1); }
	 * 
	 * // } } // System.out.println(task.toString()); return task;
	 * 
	 * } else if (rid == 2) { //System.out.println(task.toString() +
	 * "teamhead in getemptask()"); //task = taskRepo.findByprojectEmployee1(id);
	 * task = taskRepo.findbyUser(id); for (Task1 task2 : task) {
	 * 
	 * taskid = task2.getId(); List<String> workflow = new ArrayList<>();
	 * List<Object[]> list = workflowrepo.findBylastassign(taskid); String tf1 =
	 * null; String tf2 = null; String maxdates = null;
	 * 
	 * 
	 * for (Object[] obj : list) { // System.out.println(obj[0]+":"+obj[1]); tf1 =
	 * String.valueOf(obj[0]); tf2 = String.valueOf(obj[1]);
	 * 
	 * 
	 * tf1 = String.valueOf(list.get(0)[0]); tf2 = String.valueOf(list.get(0)[1]);
	 * maxdates = String.valueOf(list.get(0)[2]); //
	 * System.out.println("date from database: "+maxdates); Date date1 = null; Date
	 * utilDate = null; SimpleDateFormat formatter = new
	 * SimpleDateFormat("dd/MM/yyyy");
	 * 
	 * try { Date date4 = new SimpleDateFormat("yyyy-MM-dd").parse(maxdates); //
	 * System.out.println("date4 : "+date4); date4.after(date4);
	 * task2.setCurrentMaxDate(date4); // System.out.println("hi hi"+
	 * task2.getCurrentMaxDate()); } catch (ParseException e) { // TODO
	 * Auto-generated catch block e.printStackTrace(); }
	 * 
	 * if (tf1.equalsIgnoreCase(String.valueOf(id)) && task2.getStatus() == 2) {
	 * //System.out.println("in if cndition" +task2.getStatus());
	 * task2.setColor("gray");
	 * 
	 * } else if (task2.getStatus() != 0 && task2.getStatus() != 1 &&
	 * task2.getStatus() != 4 && task2.getStatus() != 5) {
	 * 
	 * task2.setColor("#007bffb8"); //task2.setStartDate(date1); } else if
	 * (task2.getStatus() == 4 && task2.getStatus() != 5) { //
	 * System.out.println("status = " + task2.getStatus());
	 * task2.setColor("#F88017"); //task2.setStartDate(date1); }
	 * 
	 * else if (task2.getStatus() == 5) { // System.out.println("status = " +
	 * task2.getStatus()); task2.setColor("#7D6608"); //task2.setStartDate(date1); }
	 * 
	 * // } } for (Task1 task2 : task) { // System.out.println("test :" +
	 * task2.toString()); } return task;
	 * 
	 * // return taskRepo.findByprojectEmployee(id);} } else { //task =
	 * taskRepo.findByEmployee11(id); task = taskRepo.findbyUser(id); for (Task1
	 * task2 : task) { // System.out.println("task id : "+task2.getId()); taskid =
	 * task2.getId();
	 * 
	 * List<String> workflow = new ArrayList<>(); List<Object[]> list =
	 * workflowrepo.findBylastassign(taskid); String tf1 = null; String tf2 = null;
	 * String maxdates = null;
	 * 
	 * 
	 * tf1 = String.valueOf(list.get(0)[0]); tf2 = String.valueOf(list.get(0)[1]);
	 * maxdates = String.valueOf(list.get(0)[2]); //
	 * System.out.println("date from database: "+maxdates); //Date date1 = null;
	 * Date utilDate = null; SimpleDateFormat formatter = new
	 * SimpleDateFormat("dd/MM/yyyy");
	 * 
	 * try { Date date4 = new SimpleDateFormat("yyyy-MM-dd").parse(maxdates); //
	 * System.out.println("date4 : "+date4); date4.after(date4);
	 * task2.setCurrentMaxDate(date4); // System.out.println("hi hi"+
	 * task2.getCurrentMaxDate()); } catch (ParseException e) { // TODO
	 * Auto-generated catch block e.printStackTrace(); }
	 * 
	 * if (tf1.equalsIgnoreCase(String.valueOf(id)) && task2.getStatus() == 2) {
	 * 
	 * task2.setColor("gray");
	 * 
	 * } else if (task2.getStatus() != 0 && task2.getStatus() != 1 &&
	 * task2.getStatus() != 4 && task2.getStatus() != 5) {
	 * task2.setColor("#007bffb8"); //task2.setStartDate(date1); } else if
	 * (task2.getStatus() == 4 && task2.getStatus() != 5) {
	 * task2.setColor("#F88017"); //task2.setStartDate(date1); } else if
	 * (task2.getStatus() == 5) { task2.setColor("#7D6608");
	 */
	  //task2.setStartDate(date1); }
	  
	  // } } return task;
	  
	  // return task; } // return task; }
	  
	 
	@RequestMapping(value = "/addTask", method = RequestMethod.POST)
	public void saveTask(@RequestBody Task task) {

		Date date = new Date();
		// System.out.println(task.getInsert_date());
		// long c1 = Long.valueOf(task.getCustomer().getId());
		taskRepo.save(task);
	}

	@RequestMapping(value = "/showtask1/{id}/{rid}")
	public List<Task> gettask(@PathVariable long id, @PathVariable long rid) {
		/* List<Task> task = (List<Task>) taskRepo.findAll(); */
		List<Task> task = new ArrayList<>();

		if (rid == 1) {
			// System.out.println("dro" +rid + " uid " +id);

			return taskRepo.findByAllEmployee();

		} else if (rid == 2) {
			// System.out.println("teamhead" +rid +" uid " +id);
			return taskRepo.findByprojectEmployee(id);
		} else {

			return taskRepo.findByEmployee1(id);
			// return task;
		}
		// return task;
	}

	@RequestMapping(value = "/tprpt/{id}/{rid}")
	public List<Task> gettaskReportt(@PathVariable long id, @PathVariable long rid, @RequestBody Task task) {
		/* List<Task> task = (List<Task>) taskRepo.findAll(); */
		List<Task> task1 = new ArrayList<>();
		//System.out.println("in tprpt" + rid + "++uid:" + id);

		if (rid == 1 || rid == 4) {

			//System.out.println("start date: " + task.getStartDate());
			task1 = taskRepo.findfordro(task.getStartDate(), task.getEndDate());

		}

		else if (rid == 2) {
			task1 = taskRepo.findByStartDates(id, task.getStartDate(), task.getEndDate());
		}

		else {
			task1 = taskRepo.findByemployeeid(id, task.getStartDate(), task.getEndDate());
		}

		// task1 = taskRepo.findByStartDateBetweenAndProjectIn(task.getStartDate(),
		// task.getendDate(), projectRepo.findByTeamhead(emprepo.findById(id).get()));
		for (Task task2 : task1) {
			// System.out.println("test :" + task2.toString());
		}

		/*
		 * if (rid == 1) { // System.out.println("dro" +rid + " uid " +id);
		 * 
		 * task1 = taskRepo.findByAllEmployee();
		 * 
		 * } else if (rid == 2) { // System.out.println("teamhead" +rid +" uid " +id);
		 * task1 = taskRepo.findByprojectEmployee(id); } else {
		 * 
		 * task1 = taskRepo.findByEmployee1(id); // return task; }
		 */
		return task1;
	}

	@RequestMapping(value = "/sandrabhtask/{id}/{rid}")
	public List<Task> sandrabhdetails(@PathVariable long id, @PathVariable long rid, @RequestBody Task task) {
		System.out.println("test");

		List<Task> task1 = new ArrayList<>();

		for (Task task2 : task1) {
			System.out.println("test :" + task2.toString());
		}
		// System.out.println("uid " + id + " "+rid );
		if (rid == 1 || rid == 4) {

			// System.out.println("start date: "+task.getStartDate());
			task1 = taskRepo.findfordro1(task.getStartDate(), task.getEndDate());
		}

		else if (rid == 2) {
			task1 = taskRepo.findByStartDates1(id, task.getStartDate(), task.getEndDate());
		}

		else {
			task1 = taskRepo.findByemployeeid1(id, task.getStartDate(),task.getEndDate());
		}

		return task1;
	}

	/*
	 * @RequestMapping(value = "/showtask1/{id}/{rid}") public List<Task>
	 * gettaskreport(@PathVariable Date id, @PathVariable Date rid) { List<Task>
	 * task = (List<Task>) taskRepo.findAll(); List<Task> task = new ArrayList<>();
	 * 
	 * 
	 * return task; }
	 */

	@RequestMapping(value = "/showtask4/{id}/{rid}")
	public List<Task> gettask4(@PathVariable long id, @PathVariable long rid) {
		/* List<Task> task = (List<Task>) taskRepo.findAll(); */
		List<Task> task = new ArrayList<>();

		if (rid == 1) {
			// System.out.println("dro" +rid + " uid " +id);

			return taskRepo.findByAllEmployee();

		} else if (rid == 2) {
			// System.out.println("teamhead" +rid +" uid " +id);
			return taskRepo.findByprojectEmployee(id);
		} else {

			return taskRepo.findByEmployee1(id);
			// return task;
		}
		// return task;
	}

	@RequestMapping(value = "/showtaskdetails", method = RequestMethod.GET)
	public List<Task> gettask1() {
		List<Task> task = (List<Task>) taskRepo.findAll();

		return task;
	}

	@RequestMapping(value = "/showsearchresult/{text}", method = RequestMethod.GET)
	public List<Task> gettask11(@PathVariable String text) {
		List<Task> task = taskRepo.searchstoredcalled(text);
		for (Task task2 : task) {
			// System.out.println("task 2 :"+task2.getFilesid());
			// System.out.println("task 2 :"+task2.getTname());
		}
		return task;
	}

	@RequestMapping(value = "/showtaskbyid/{id}")
	public List<Task> gettaskid() {
		List<Task> task = (List<Task>) taskRepo.findAll();
		return task;
	}

	@RequestMapping(value = "/showtaskbyid1/{id}")
	public Task gettaskid1(@PathVariable long id) {
		// System.out.println(id +"task id...");
		Optional<Task> task = taskRepo.findById(id);

		Task t1 = new Task();
		if (task.isPresent()) {
			t1 = task.get();
		}
		// System.out.println(t1 +"taskk details.................");
		return t1;
	}

	@RequestMapping(value = "/showtaskdetails/{id}")
	public Task gettaskidemp(@PathVariable long id) {
		// System.out.println(id +"task id gettaskidemp...");
		Optional<Task> task = taskRepo.findById(id);
		Task t12 = new Task();
		if (task.isPresent()) {
			t12 = task.get();
		}
		// System.out.println(t12 +"taskk details.................");
		return t12;
	}

	@RequestMapping(value = "/showtask/{id}")
	public List<Task> getemptask(@PathVariable long id) {
		List<Task> task = (List<Task>) taskRepo.findByEmployee1(id);

		return task;
	}

	@RequestMapping("/getTaskCount")
	public long getTaskCount() {
		return taskRepo.count();
	}

	@RequestMapping(value = "/nextfinaltime/{id}", method = RequestMethod.POST)
	public ResponseEntity<Object> taskNextDate(@RequestBody Task task, @PathVariable long id) {
		Optional<Task> taskOptional = taskRepo.findById(id);
		if (!taskOptional.isPresent())
			return ResponseEntity.notFound().build();

		Task task1 = taskOptional.get();
		task1.setId(id);
		task1.setNextfinaldate(task.getNextfinaldate());
		// System.out.println(task.getNextfinaldate() + "task.getNextfinaldate()");
		taskRepo.save(task1);
		// System.out.println(task1.toString());

		/*
		 * Workflow w = new Workflow(); w.setTask(task);
		 * //w.setTask_to(task.getAssignto()); w.setTitle("Task Completed");
		 * w.setNstatus("1"); w.setTstatus("0"); workflowrepo.save(w);
		 */
		return ResponseEntity.noContent().build();
	}

	@RequestMapping(value = "/setenddate/{id}", method = RequestMethod.POST)
	public ResponseEntity<Object> taskEndDate(@RequestBody Task task, @PathVariable long id) {
		Optional<Task> taskOptional = taskRepo.findById(id);

		// to check method called only once for update value only once not every time
		/*
		 * if(check == false) {
		 */
		if (!taskOptional.isPresent())
			return ResponseEntity.notFound().build();

		Task task2 = taskOptional.get();
		// task2.setId(id);
		task2.setEndDate(task.getEndDate());

		// System.out.println(task.getendDate()+"find end date in setenddate url");

		// System.out.println(task2 +"all details");
		taskRepo.save(task2);
		check = true;
		// }

		return ResponseEntity.ok().build();
	}

	// get total count of send and received task
	@RequestMapping(value = "/gettaskslist/{id}/{rid}")
	public List<Object[]> getcountoftask(@PathVariable long id, @PathVariable long rid) {
		// System.out.println(taskfrom +"taskfrom");
		List<String> task = new ArrayList<>();
		List<Object[]> list = taskRepo.findBycountfrom();
		// String c1 = null;
		// System.out.println(rid + "role...graph" + id + "....userid");
		if (rid == 1 || rid == 4) {
			// System.out.println(task.toString()+"dro graph");
			return taskRepo.findBycountfrom();

		} else if (rid == 2) {
			// System.out.println(task.toString() +"teamhead graph");
			return taskRepo.findBycountprojecthead(id);
		} else {
			// System.out.println(task.toString() +"own task graph");
			return taskRepo.findBycountteam(id);
			// return task;
		}
		// return list;
	}

	@RequestMapping(value = "/updatetask/{id}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	// @PutMapping("/updatetask/{id}")
	public ResponseEntity<Object> updateTask(@RequestBody Task task, @PathVariable long id) {
		// System.out.println("in controller" + id + " " + task.getAssignto().getId());

		// System.out.println(task.toString() + "tostring");
		Optional<Task> taskOptional = taskRepo.findById(id);
		if (!taskOptional.isPresent()) {
			return ResponseEntity.notFound().build();
		}

		Task task3 = taskOptional.get();

		task3.setId(id);
		// task3.setTasktype(task.getTasktype());
		task3.setArrivedfrom(task.getArrivedfrom());
		task3.setTname(task.getTname());
		task3.setBranch(task.getBranch());
		task3.setCaseno(task.getCaseno());
		task3.setInwordno(task.getInwordno());
		task3.setPropertyid(task.getPropertyid());
		task3.setLetterdeliverytype(task.getLetterdeliverytype());
		task3.setLettersubject(task.getLettersubject());
		task3.setLettertype(task.getLettertype());

		task3.setFilesid(task.getFilesid());

		////////////////////////////////////////////////////////
		task3.setAssignto(task.getAssignto());

		task3.setLastassign(task.getAssignto());

		// project

		task3.setProject(task.getProject());

		taskRepo.save(task3);

		return ResponseEntity.ok().build();

	}

	@RequestMapping(value = "/completetask/{id}", method = RequestMethod.POST)
	public ResponseEntity<Object> taskComplete(@RequestBody Task task, @PathVariable long id) {

		System.out.println(id);

		Optional<Task> taskOptional = taskRepo.findById(id);
		if (!taskOptional.isPresent())
			return ResponseEntity.notFound().build();

		Task task1 = taskOptional.get();

		task1.setId(id);
		task1.setStatus(0);
		task1.setColor("#84F06E");
		taskRepo.save(task1);

		return ResponseEntity.noContent().build();
	}

	@RequestMapping(value = "/enddatetask/{id}/{rid}")
	public List<Task> getemptask1(@PathVariable long id, @PathVariable long rid) {
		// List<Task> task = (List<Task>) taskRepo.findenddate();

		List<Task> task = new ArrayList<>();

		if (rid == 1) {
			return taskRepo.findenddate();
		} else if (rid == 2) { //
			// System.out.println("teamhead" +rid +" uid " +id);
			return taskRepo.findenddate(id);
		} else { //

			return taskRepo.findenddatebyemp(id); // return task; }

		}

	}

	@RequestMapping(value = "/rejectedtask/{id}")
	public List<Task> getrejectedTask(@PathVariable long id) {
		// List<Task> task = (List<Task>) taskRepo.findenddate();

		// List<Task> task = new ArrayList<>();

		return taskRepo.findRejectedtask(id);

	}

	@RequestMapping(value = "/displaytaskbyid/{id}")
	public List<String> gettaskbyitsid(@PathVariable long id) {
		/// System.out.println(taskfrom +"taskfrom");
		List<String> task = new ArrayList<>();
		List<Object[]> list = taskRepo.findtaskbyid(Long.valueOf(id));
		String assignto = null;
		String lastassignto = null;
		String enddate = null;
		for (Object[] obj : list) {
			System.out.println(obj[0] + ":" + obj[1] + "in gettaskbyid");
			assignto = String.valueOf(obj[0]);
			lastassignto = String.valueOf(obj[1]);
			enddate = String.valueOf(obj[2]);
			task.add(assignto);
			task.add(lastassignto);
			task.add(enddate);
		}
		return task;

	}

	// Task send to the SR
	@RequestMapping(value = "/tasksendtosr/{id}/{uid}", method = RequestMethod.POST)
	public ResponseEntity<Object> sendtoSR(@RequestBody Workflow workflow, @PathVariable long id, @PathVariable long uid) {

		System.out.println(id);

		Task task1 = taskRepo.getOne(id);

		task1.setId(id);
		task1.setStatus(4);
		task1.setColor("#DEFF0A");
		taskRepo.save(task1);
		
		System.out.println(uid +"workflow:::  "+workflow.toString());
		System.out.println("task from " + workflow.getTask_from() +" and desc: " + workflow.getDescription() +" task to " +workflow.getTask_to() );

		//only for testing needs to change
	    Optional<Employee> taskoptional = emprepo.findById(uid);
		Employee e = taskoptional.get();
		Workflow w = new Workflow();
		w.setTask(task1);
		w.setTitle("Task Added In to Awaited");
		w.setNstatus("3");
		w.setTstatus("5");
		w.setTask_to(e);
		w.setTask_from(e);
		/*
		 * w.setTask_to(workflow.getTask_from());
		 * w.setTask_from(workflow.getTask_from());
		 */
		w.setDescription(workflow.getDescription());

		w.setNoticode(workflow.getNoticode());
		workflowrepo.save(w);

		return ResponseEntity.ok().build();
	}

	// Task send to the SR
	@RequestMapping(value = "/tasksendtoAwait/{id}", method = RequestMethod.POST)
	public ResponseEntity<Object> sendtoAwaited(@RequestBody Workflow workflow, @PathVariable long id) {


		//System.out.println("workflow details: " + workflow.toString());

		Task task1 = taskRepo.getOne(id);

		task1.setId(id);
		task1.setStatus(5);
		task1.setColor("#FF5733");
		taskRepo.save(task1);

		//System.out.println("task id " + task1);

		Workflow w = new Workflow();
		w.setTask(task1);
		w.setTitle("Task Added In to Awaited");
		w.setNstatus("3");
		w.setTstatus("5");
		w.setTask_to(workflow.getTask_from());
		w.setTask_from(workflow.getTask_from());
		w.setDescription(workflow.getDescription());

		w.setNoticode(workflow.getNoticode());
		workflowrepo.save(w);

		return ResponseEntity.noContent().build();
	}

	
	  @RequestMapping(value = "/sandrabhtaskDate/{id}/{rid}") 
	  public List<MyTask> sandrabhDetailsWithdate(@PathVariable long id, @PathVariable long rid, @RequestBody Task task)
	  {
	  
	  List<MyTask> task1 = new ArrayList<>();
	  task1 = taskRepo.findByStartDates2(id,task.getStartDate(),task.getEndDate());
	  return task1; 
	  }
	  
	  

	  @RequestMapping(value = "/tapalreports/{id}/{rid}") 
	  public List<Tapaltask> tapalDetailsWithdate(@PathVariable long id, @PathVariable long rid, @RequestBody Task task) {
	  
	  
	  List<Tapaltask> task1 = new ArrayList<>();
	  
	  task1 = taskRepo.findByTapal(id,task.getStartDate(),task.getEndDate());

	  return task1;
	  }

	/*
	 * @RequestMapping(value = "gettaskdisplay/{id}/{rid}") public List<String>
	 * getallTaskDetails(@PathVariable long id, @PathVariable long rid) { long
	 * taskid;
	 * 
	 * System.out.println("hello"); System.out.println("user id:" + id + " role.id:"
	 * + rid);
	 * 
	 * List<String> task = new ArrayList<>(); String c1 = null; String c2 = null;
	 * String c3 = null; String c4 = null; String tf1 = null; String tf2 = null;
	 * String maxdates = null;
	 * 
	 * // for dro and frontdesk if (rid == 1 || rid == 4) { List<Object[]> list =
	 * taskRepo.findbyrole(); for (Object[] obj : list) { c1 =
	 * String.valueOf(obj[0]); c2 = String.valueOf(obj[1]); c3 =
	 * String.valueOf(obj[2]); c4 = String.valueOf(obj[3]);
	 * 
	 * taskid = Long.parseLong(String.valueOf(obj[0]));
	 * 
	 * task.add(c1); task.add(c2); task.add(c3); task.add(c4);
	 * 
	 * List<String> workflow = new ArrayList<>(); List<Object[]> list1 =
	 * workflowrepo.findBylastassign(taskid);
	 * 
	 * tf1 = String.valueOf(list1.get(0)[0]); tf2 = String.valueOf(list1.get(0)[1]);
	 * maxdates = String.valueOf(list1.get(0)[2]);
	 * 
	 * System.out.println("date from database: " + maxdates); task.add(tf1);
	 * task.add(tf2); task.add(maxdates); }
	 * 
	 * }
	 * 
	 * // for project team head And clerks
	 * 
	 * if (rid == 2 || rid == 3)
	 * 
	 * { List<Object[]> list = taskRepo.findbyUser(id);
	 * 
	 * for (Object[] obj : list) { c1 = String.valueOf(obj[0]); c2 =
	 * String.valueOf(obj[1]); c3 = String.valueOf(obj[2]); c4 =
	 * String.valueOf(obj[3]);
	 * 
	 * 
	 * 
	 * task.add(c1); task.add(c2); task.add(c3); task.add(c4);
	 * 
	 * taskid = Long.parseLong(String.valueOf(obj[0]));
	 * 
	 * List<String> workflow = new ArrayList<>(); List<Object[]> list1 =
	 * workflowrepo.findBylastassign(taskid);
	 * 
	 * tf1 = String.valueOf(list1.get(0)[0]); tf2 = String.valueOf(list1.get(0)[1]);
	 * maxdates = String.valueOf(list1.get(0)[2]);
	 * 
	 * System.out.println("date from database: " + maxdates);
	 * 
	 * task.add(tf1); task.add(tf2); task.add(maxdates);
	 * 
	 * }
	 * 
	 * System.out.println("task:" + task.toString()); } return task;
	 * 
	 * }
	 * 
	 * @RequestMapping(value = "/getlisttask/{id}/{rid}") public List<Object[]>
	 * gettaskuser(@PathVariable long id, @PathVariable long rid) { //
	 * System.out.println(taskfrom +"taskfrom");
	 * 
	 * List<String> task = new ArrayList<>(); long taskid; List<Object[]> list =
	 * taskRepo.findBycountfrom();
	 * 
	 * String tf1 = null; String tf2 = null; String maxdates = null;
	 * 
	 * if (rid == 1 || rid == 4) {
	 * 
	 * return taskRepo.findbyrole(); }
	 * 
	 * else if (rid == 2) {
	 * 
	 * return taskRepo.findbyUser(id); } else {
	 * 
	 * return taskRepo.findbyUser(id);
	 * 
	 * } }
	 */
	  
	  @RequestMapping(value = "/getlisttask/{id}/{rid}")
	  public List<CalenderTask> taskDetails(@PathVariable long id, @PathVariable long rid)
	  {
		  
		  long taskid; 
		  List<Task> task = new ArrayList<>();
		  
		  List<CalenderTask> task1 = new ArrayList<>();
		  
		  //task1 = taskRepo.findByTapal(id,task.getStartDate(),task.getEndDate());
		  if(rid == 1 || rid == 4)
		  {
			  task1 = taskRepo.findbyrole();
			  
			//  System.out.println("task details: "+task1);
			  for (CalenderTask calenderTask : task1) 
			  {
			//	  System.out.println( "calenderTask.getMaxDate(); "+calenderTask.getMaxDate());
			
			  }
			  
		  }
		  
		  else if(rid == 2 || rid == 3)
		  {
			  task1 = taskRepo.findbyUser1(id);
		  }

		  return task1;
		  }

}
