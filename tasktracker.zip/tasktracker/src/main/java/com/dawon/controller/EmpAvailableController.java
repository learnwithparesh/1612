package com.dawon.controller;


import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.TimeZone;
import java.sql.Timestamp;    
import java.util.Date;    
import java.text.SimpleDateFormat; 

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.bind.annotation.RestController;

import com.dawon.model.Empavailable;
import com.dawon.model.Employee;
import com.dawon.repositories.AvailableEmpDisplay;
import com.dawon.repositories.EmpAvailableRepository;
import com.dawon.repositories.EmployeeRepository;


@RestController
public class EmpAvailableController<meetingstime> 
{
	private static final long serialVersionUID = 1L;
	
	@Autowired
	EmpAvailableRepository repo;
	
	@Autowired
	EmployeeRepository emprepo;
	
	
	@RequestMapping(value="/addEmpAvailable/{id}", method = RequestMethod.POST,produces = "application/json")
	public ResponseEntity<Object> saveEmpAvailable(@RequestBody Empavailable empavailable, @PathVariable long id)
	{ 
		
		
		/*System.out.println(empavailable.getMeetingstime() +"empavailable.getMeetingstime()");
		String testDateString2 = empavailable.getMeetingstime();
		 DateFormat df2 = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		 Date d2;
		  try {
			d2 = df2.parse(testDateString2);
			 System.out.println("Date: " + d2);
	         System.out.println("Date in dd-MM-yyyy HH:mm:ss format is: "+df2.format(d2));
		  } catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		 }*/
        
	
		Optional<Employee> employeeoptional = emprepo.findById(id);
		
		if (!employeeoptional.isPresent()) 
		{
			return ResponseEntity.notFound().build();
			
		}
		
		else
		{
			Employee emplyee = employeeoptional.get();
			Empavailable emp3;
			if(empavailable.getMeetingstime() == null ||empavailable.getMeetingstime()==" " || empavailable.getMeetingetime() == null||empavailable.getMeetingetime() == "")
			{
		     emp3 = new Empavailable(empavailable.getLeavefrom(), empavailable.getLeaveto(),empavailable.getDescription());
			}
			else
			{
			  emp3 = new Empavailable(empavailable.getLeavefrom(), empavailable.getLeaveto(),empavailable.getMeetingstime(), empavailable.getMeetingetime(),empavailable.getDescription());
			}
	     	//Empavailable emp3 = new Empavailable(leavefrom, leaveto,meetingetime,meetingetime,description);
	     	//emp3.setMeetingstime(empavailable.getMeetingstime().toGMTString());
			//emp3.getMeetingstime().toGMTString();
			//emp3.getMeetingetime().toGMTString();
			emp3.setEmployee(emplyee);
			repo.save(emp3);
			
			return ResponseEntity.noContent().build();
		}
		
	}
	
	
	/*System.out.println(emp.getLeave_from());
	Employee emp1 = emp.getEmployee();
	EmpAvailable emp3 = new EmpAvailable(emp.getLeave_from(), emp.getLeave_to(), emp.getMeeting_etime(), emp.getMeeting_stime());
	emp3.setEmployee(emp1);*/
	

	@RequestMapping(value = "/getEmpAvailable")
	public ArrayList<Empavailable> getEmpavailable() 
	{
		
		 return (ArrayList<Empavailable>) repo.findAll();
	}
	
	
	
	
	
	@RequestMapping(value = "/showEmpAvailable")
	public ArrayList<AvailableEmpDisplay> displayEmpAvail() 
	{
		 return (ArrayList<AvailableEmpDisplay>) repo.findavailableemployee();
	}
	
	
	

}
