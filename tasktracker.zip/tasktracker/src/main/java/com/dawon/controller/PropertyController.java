package com.dawon.controller;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dawon.model.Customer;
import com.dawon.model.Property;
import com.dawon.model.Task;
import com.dawon.model.Workflow;
import com.dawon.repositories.CustomerRegistrationRepository;
import com.dawon.repositories.PropertyRepository;

@RestController
public class PropertyController 
{
	@Autowired
	PropertyRepository prepo;
	@Autowired 
	CustomerRegistrationRepository custrepo;
	
	@RequestMapping(value="/addproperty/{id}",method = RequestMethod.POST,produces = "application/json")
	public ResponseEntity<Object> saveProperty(@RequestBody Property property,@PathVariable long id)
	{
		Date date = new Date();
		Optional<Customer> customeroptional = custrepo.findById(id);
		
		if (!customeroptional.isPresent()) 
		{
			return ResponseEntity.notFound().build();
			
		}
		
		else
		{
			Customer customer = customeroptional.get();
			
     		//task.setId(id);
     		// User foo = p1.get();
			/*String propid, String description, String village, String courtcaseno, String courtname,
			String address, String courtstatus, String otherowner, Date insertdate*/
     		//System.out.println("village " +property.getVillages());
			Property property1 = new Property(property.getPropid(),property.getDescription(),property.getCourtcaseno(),/*property.getDistricts(),*/property.getVillages(),
					property.getCourtname(),property.getAddress(),property.getCourtstatus(),property.getNexthearing(),property.getOtherowner(),date,property.getFilesid());
			property1.setCustomer(customer);
			//property1.setVillages(property.getVillages());
			prepo.save(property1);
			
			return ResponseEntity.ok().build();
		}
		
		
	}
	
	@RequestMapping(value = "/viewproperty")
	public List<Property> getProperty() 
	{

		List<Property> property = (List<Property>) prepo.findAll();
		return property;
	}
	
	@RequestMapping("/getPropCount")
	  public long getPropCount() {
	    return prepo.count();
	  }

}
