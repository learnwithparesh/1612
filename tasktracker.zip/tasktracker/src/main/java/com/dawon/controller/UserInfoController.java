package com.dawon.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dawon.model.User;
import com.dawon.repositories.UserRepository;

@RestController
public class UserInfoController {
	@Autowired
	UserRepository repository;

	@RequestMapping(value="/myLogin",method = RequestMethod.POST)
	 public  HashMap<String, Object> ProcessUsers(@RequestBody User user,HttpServletResponse response) throws IOException
	 {
		 Optional<User> p1 = repository.findByEmailAndPassword(user.getEmail(),user.getPassword());
		 HashMap<String, Object> map = new HashMap<>();
		    
		    if (p1.isPresent())
			{
				
				 User foo = p1.get();
				 //String name = foo.getName();
					map.put("rsd", "success");
					map.put("id", foo.getId());
					//map.put("id", foo.getOrgid());
					map.put("name", foo.getName());
					
					
				//	 response.sendRedirect("/#/u/"+foo.getName()+"/"+foo.getOrg_id());
			}
			else
			{
				
				map.put("rsd", "error");
			}
			return map;
	 }
}
