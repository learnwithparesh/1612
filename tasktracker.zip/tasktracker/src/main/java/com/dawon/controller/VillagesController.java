package com.dawon.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dawon.model.Villages;
import com.dawon.repositories.VillageRepository;

@RestController
public class VillagesController
{
	@Autowired
	VillageRepository villrepo;
	
	
	@RequestMapping(value = "/villagelist")
	public List<Villages> getvillage() 
	{
		List<Villages> villages = (List<Villages>) villrepo.findAll();
		return villages;
	}
	

}
