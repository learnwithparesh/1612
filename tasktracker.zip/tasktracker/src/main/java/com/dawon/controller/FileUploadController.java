package com.dawon.controller;

import java.util.Date;
import java.util.Optional;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.dawon.model.Employee;
import com.dawon.model.Project;
import com.dawon.model.Task;
import com.dawon.model.Workflow;
import com.dawon.repositories.EmployeeRepository;
import com.dawon.repositories.ProjectRepository;
import com.dawon.repositories.TaskRepository;
import com.dawon.repositories.TaskTypeRepository;
import com.dawon.repositories.WorkflowRepository;


@RestController
@RequestMapping("/api")
public class FileUploadController {

	@Autowired
	FileUploadService fileUploadService;
	
	@Autowired
	TaskRepository taskRepo;

	@Autowired
	WorkflowRepository workflowrepo;

	@Autowired
	ProjectRepository projectRepo;

	@Autowired
	EmployeeRepository emprepo;
	
	@Autowired
	TaskTypeRepository ttypeRepo;
	@PostMapping(value="/fileUpload", produces = MediaType.APPLICATION_JSON_VALUE)
    public String fileUpload(@RequestParam("uploadfile") MultipartFile file, @RequestParam("insertby") String insertby)  {
		String results = null;
		 String ltype = null;
    	try {
    		//fileUploadService.store(file);
    		System.out.println("file name :"+ file.getContentType() + " : "+ file.getName());
    		Date date = new Date();
    		//List<Test> tempStudentList = new ArrayList<Test>();
    	    XSSFWorkbook workbook = new XSSFWorkbook(file.getInputStream());
    	    XSSFSheet worksheet = workbook.getSheetAt(0);
    	   
    	    String sd = null;
    	    for(int i=2;i<worksheet.getPhysicalNumberOfRows() ;i++) {
    	       // Test tempStudent = new Test();
    	    	Task tasku = new Task();
    	    	
    	        XSSFRow row = worksheet.getRow(i);
    	        Project pr = projectRepo.findByPrnameEquals(row.getCell(11).getStringCellValue());
    	        //tempStudent.setId((int) row.getCell(0).getNumericCellValue());
    	        //tempStudent.setContent(row.getCell(1).getStringCellValue());
    	        //    tempStudentList.add(tempStudent);  
    	     //  System.out.println("tasku"+row.getCell(0).getStringCellValue()); 
    	     //  System.out.println("File Id"+row.getCell(1).getStringCellValue()); 
    	      // System.out.println("Project"+row.getCell(11).getStringCellValue()); 
    	      //  sd = row.getCell(0).getStringCellValue();
    	        
    	       
    	        //exact code for jpa
    	        tasku.setTtype(Long.valueOf(2));
    	        //GET CELL
                Cell cell1 = row.getCell(1);   
                //SET AS STRING TYPE
                cell1.setCellType(Cell.CELL_TYPE_STRING);
                if(cell1.getCellType() == Cell.CELL_TYPE_NUMERIC)
                {
                	cell1.setCellType(Cell.CELL_TYPE_STRING);
                }   
                System.out.println("before file id");
    	        tasku.setFilesid(row.getCell(1).getStringCellValue());
    	        System.out.println("after file id");
    	        
    	      //  tasku.setTasktype(ttypeRepo.findByTtypeEquals(row.getCell(0).getStringCellValue()));
    	      //  tasku.setLettertype(String.valueOf(ttypeRepo.findByTtypeEquals(row.getCell(2).getStringCellValue()).getId()));
    	        System.out.println(row.getCell(2).getStringCellValue());
    	        System.out.println("tasktype id"+ttypeRepo.findByTtypeEquals(row.getCell(2).getStringCellValue()).getId());
    	        System.out.println("tasktype ttype"+ttypeRepo.findByTtypeEquals(row.getCell(2).getStringCellValue()).getTtype());
    	         ltype = String.valueOf(ttypeRepo.findByTtypeEquals(row.getCell(2).getStringCellValue()).getId());
    	        System.out.println("ltype  :"+ltype);
    	        tasku.setLettertype(ltype);
    	        tasku.setArrivedfrom(row.getCell(3).getStringCellValue());
    	        tasku.setBranch(row.getCell(4).getStringCellValue());
    	        //GET CELL
                Cell cell5 = row.getCell(5);   
                //SET AS STRING TYPE
                if(cell5.getCellType() == Cell.CELL_TYPE_NUMERIC)
                {
                	cell5.setCellType(Cell.CELL_TYPE_STRING);
                }   
                System.out.println("before inward id");
    	        tasku.setInwordno(row.getCell(5).getStringCellValue());
    	        System.out.println("after file id");
    	        tasku.setInworddate(row.getCell(6).getDateCellValue());
    	        tasku.setLettersubject(row.getCell(7).getStringCellValue());
    	        tasku.setLetterdate(row.getCell(8).getDateCellValue());
    	        tasku.setLetterdeliverytype(row.getCell(9).getStringCellValue());
    	        tasku.setSender(row.getCell(10).getStringCellValue());
    	        
    	        System.out.println("all local");
    	        tasku.setProject(pr);
    	        System.out.println("befor Task Type");
    	        tasku.setTasktype(ttypeRepo.findByTtypeEquals(row.getCell(0).getStringCellValue()));
    	        System.out.println("befor Team head");
    	        System.out.println("Project name"+pr.getPrname());
    	        System.out.println("Project TeamHead Id"+pr.getTeamhead().getId());
    	        System.out.println("Project TeamHead Name"+pr.getTeamhead().getName());
    	        tasku.setAssignto(pr.getTeamhead());
    	        tasku.setStartDate(date);
    	        tasku.setColor("#007bffb8");
    	        tasku.setInsertby(insertby);
    	        tasku.setLastassign(pr.getTeamhead());
    	        tasku.setStatus(Long.valueOf(3));
    	       tasku.setNoticolor("2");
    			//tasku.setTname(row.getCell(11).getStringCellValue());
    			
    			tasku = taskRepo.save(tasku);
    			Employee e2 = tasku.getAssignto();
    			System.out.println("before set c1 :" + insertby);
    			long c1 = Long.valueOf(insertby);
    			System.out.println("after set c1");
    			Optional<Employee> taskoptional = emprepo.findById(c1);
    			Employee e = taskoptional.get();
    			Workflow w = new Workflow();
     			w.setTask(tasku);
     			w.setTitle("New Task Added");
    			w.setNstatus("1");
    			w.setTstatus("3");
    			w.setTask_to(e2);
    			w.setTask_from(e);
    			w.setNoticode(tasku.getNoticolor());
    			workflowrepo.save(w);
    			
    			
    			int thu = taskRepo.storedcalled1(tasku.getId(), tasku.getTtype());

    			tasku.setTapal(thu);
    			tasku = taskRepo.save(tasku);	
    	    }
    	    results = "File " + file.getName()+" uploaded successfully!!" + sd;
			//return "File " + file.getName()+" uploaded successfully!!" + sd;
		} catch (Exception e) {
			System.out.println("error"+e.getMessage());
			//throw new Exception(e.getMessage());
			//return "Error Occured ";
		}
    	return results;
    }
    
}
