package com.dawon.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dawon.model.Employee;
import com.dawon.model.Project;
import com.dawon.model.ProjectTeams;
import com.dawon.model.Task;
import com.dawon.repositories.EmployeeRepository;
import com.dawon.repositories.ProjectRepository;
import com.dawon.repositories.ProjectTeamRepository;

//controller to add the projectteam members and  get team
@RestController
public class ProjectTeamController
{
	//repository of ProjectTeams
	@Autowired
	ProjectTeamRepository teamRepo;
	
	//repository of Employee
	@Autowired
	EmployeeRepository employeerepo;
	
	//repository of Project
	@Autowired
	ProjectRepository projectrepo;

	
	//add projectteam method if customer is exist then add property to customer.
		@RequestMapping(value="/projectteam/{id}",method = RequestMethod.POST,produces = "application/json")
		public ResponseEntity<Object> saveProjectteam(@RequestBody ProjectTeams projectteams,@PathVariable long id)
		{
			Date date = new Date();
			Optional<Employee> empoptional = employeerepo.findById(id);
			Optional<Project> projectoptional = projectrepo.findById(id);
			if (!empoptional.isPresent()) 
			{
				return ResponseEntity.notFound().build();
			}
			
			else
			{
				Employee employee = empoptional.get();
				Project project = projectoptional.get();
				ProjectTeams projectteams1 = new ProjectTeams(projectteams.getEmployee(),projectteams.getProject());
				//projectteams1.setEmployee(employee);
				projectteams1.setProject(project);
				
				teamRepo.save(projectteams1);
				
				return ResponseEntity.ok().build();
			}
			
		}

    // get all list of team members.
	@RequestMapping(value = "/viewprojectteam")
	public List<ProjectTeams> getProject() 
	{
		
		List<ProjectTeams> projectteams = (List<ProjectTeams>) teamRepo.findAll();
		return projectteams;
	}

	@RequestMapping(value="/readprojectteamlist/{id}")
	public List<Project> findByProjectall(@PathVariable long id)
	{
		List<Project> ps = new ArrayList<Project>();
		Optional<Project> projectteams = projectrepo.findById(id);
		if(projectteams.isPresent())
		{
			ps.add(projectteams.get());
		}
		return ps;
		
	}
	
	@RequestMapping(value="/readprojectteam/{id}")
	public Project findByProject(@PathVariable long id)
	{
		Project ps = new Project();
		Optional<Project> projectteams = projectrepo.findById(id);
		if(projectteams.isPresent())
		{
			ps = projectteams.get();
		}
		return ps;
		
	}
	
	@RequestMapping(value="/readprojectteam1/{id}")
	public List<Project> findByProject1(@PathVariable long id)
	{
		List<Project> ps = new ArrayList<Project>();
		Optional<Project> projectteams = projectrepo.findById(id);
		if(projectteams.isPresent())
		{
			ps.add(projectteams.get());
		}
		return ps;
		
	}
	
	/*
	@RequestMapping(value="/readprojectteam1/{id}")
   public List<Project> findByProject1(@PathVariable long id)
	{
		
		List<Project> projectteams = teamRepo.findByProject(id);
		
		System.out.println(projectteams +"projectteams");
		
		return projectteams;
	}*/
	 
}
