package com.dawon.controller;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dawon.model.Employee;
import com.dawon.model.Project;
import com.dawon.model.ProjectTeams;
import com.dawon.model.Task;
import com.dawon.repositories.EmployeeRepository;
import com.dawon.repositories.ProjectRepository;
import com.dawon.repositories.ProjectTeamRepository;

//project controller to add and get the details of the projects
@RestController
public class ProjectController 
{
	//project repository object.
	@Autowired
	ProjectRepository prRepo;
    
	//employee repository object
	@Autowired
	EmployeeRepository emprepo;
	
	@Autowired
	ProjectTeamRepository teamrepo;
	
	//add project method with his team members  and team head. 
	@RequestMapping(value="/addproject",method = RequestMethod.POST,produces = "application/json")
	public void saveProject(@RequestBody Project project)
	{
		//System.out.println("in projectsave"+ project.getStart_date());
		
		
		Project project1 = new  Project(project.getPrname(),project.getDesc1(),project.getCode(),project.getstartDate(),project.getendDate(),project.getAddress(),project.getInsert_date(),project.getInsert_by(),
				project.getUpdate_by(),project.getUpdate_date(),project.getTeamhead(),project.getFilesid());
				
		
		Set<ProjectTeams> teams = new  HashSet<ProjectTeams>();
		
		
/*		Employee employee = new Employee();
*/		
		for(ProjectTeams pt : project.getProjectteams()) 
		{
			ProjectTeams proteam = pt;
			//System.out.println("test : "+pt.getEmployee());
			//proteam.setEmployee(pt.getEmployee());
			proteam.setProject(project1);
			//ProjectTeams pt1 = teamrepo.save(proteam);
			teams.add(proteam);
		}
		
		//project1.set
		project1.setProjectteams(teams);
		prRepo.save(project1);
		
	}

	//display all project list.
	@RequestMapping(value = "/viewproject")
	public List<Project> getProject() 
	{		
		List<Project> project = (List<Project>) prRepo.findAll();
		return project;
	}
	
	//display all project list.
		/*@RequestMapping(value = "/showproject/{id}")
		public List<Project> findByEmployee(@PathVariable long id) 
		{		
			//List<Project> project = (List<Project>) prRepo.findAll();
			List<Project> project = (List<Project>) prRepo.findByEmployee(id);
			return project;
		}*/
	
	//find the total no of count of the projects
	@RequestMapping("/getProjCount")
	  public long getProjCount() {
	    return prRepo.count();
	  }
	
	//find the total no of count of the projects
		@RequestMapping("/getProjCountbyid/{id}")
		  public long getProjCountbyid(@PathVariable long id) {
		    return prRepo.findByEmployee1(id);
		  }
		
		
		@RequestMapping(value="/updateproject/{id}",method = RequestMethod.POST,produces = "application/json")
		public ResponseEntity<Object>  updateProject(@RequestBody Project project,@PathVariable long id)
		{
			//System.out.println("in projectsave"+ project.getStart_date());

			Optional<Project> prOptional = prRepo.findById(id); 
			if (!prOptional.isPresent()) 
				return null;
			
			Project pr1 = prOptional.get();
			
			pr1.setPrname(project.getPrname());
			pr1.setAddress(project.getAddress());
			pr1.setCode(project.getCode());
			pr1.setendDate(project.getendDate());
			pr1.setstartDate(project.getstartDate());
			pr1.setFilesid(project.getFilesid());
			pr1.setTeamhead(project.getTeamhead());
			pr1.setProjectteams(project.getProjectteams());
	
			
			Set<ProjectTeams> teams = new  HashSet<ProjectTeams>();
			
			
	/*		Employee employee = new Employee();
	*/		
		
		  for(ProjectTeams pt : project.getProjectteams())
		  {
			  ProjectTeams proteam = pt;
		 // System.out.println("test : "+pt.getEmployee());
		  proteam.setEmployee(pt.getEmployee()); proteam.setProject(project);
		  //ProjectTeams pt1 = teamrepo.save(proteam);
		  teams.add(proteam); 
		  }
		 
			
			//project1.set
			pr1.setProjectteams(teams);
			prRepo.save(pr1);
			//System.out.println("success" + pr1.toString());
			return ResponseEntity.ok().build();		
			
		}
		

		@RequestMapping(value = "/getprojectbyd/{id}", method = RequestMethod.GET)
		public Project projectlist(@PathVariable long id) 
		{		
			
			Optional<Project> prOptional = prRepo.findById(id); 
			if (!prOptional.isPresent()) 
				return null;
			
			Project pr1 = prOptional.get();
			
			return pr1;		
		}
		
		
}
