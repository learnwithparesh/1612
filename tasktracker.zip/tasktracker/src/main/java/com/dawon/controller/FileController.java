package com.dawon.controller;


import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;

import java.util.HashSet;
import java.util.List;

import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.dawon.model.FilesModel;
import com.dawon.model.Fileslist;

import com.dawon.model.Task;
import com.dawon.repositories.FilesModelRepository;
import com.dawon.repositories.FileslistRepository;
import com.dawon.repositories.TaskRepository;
import com.dawon.service.FileStorage;

@RestController
public class FileController 
{
	@Value("${serviceURL}")
	private String UPLOADED_FOLDER;
	
	@Autowired
	FilesModelRepository filerepo;
	
	@Autowired
	FileslistRepository listrepo;
	
	@Autowired
	TaskRepository taskrepo;


	private final Logger logger = LoggerFactory.getLogger(FileController.class);
	@Autowired
	FileStorage fileStorage;
	
	
	
	
	
	//final String UPLOADED_FOLDER = "E:/dawon 9-14-2019/Projects/tasktracker project/uploadfile/";
	
	@PostMapping("/uploadMultiFiles")
    public List<FilesModel> uploadFileMulti(@ModelAttribute FilesModel form) throws Exception {
 
       // System.out.println("Description:" + form.getFilename());
        List<FilesModel> rlist = new ArrayList<FilesModel>();
		
        String result = null;
        try {
        	//System.out.println("task_id"+form.getTestid());
        	for (MultipartFile myfiles : form.getFiles()) {
				//System.out.println("name"+myfiles.getName() +"" +myfiles.getOriginalFilename());
				//System.out.println("type"+myfiles.getContentType());
				
				
			}
        	
        	   // String UPLOADED_FOLDER  = "/remote/dir/server/";
        	    String directoryName = UPLOADED_FOLDER.concat(String.valueOf(form.getTestid()));
        	   // String fileName = id + getTimeStamp() + ".txt";

        	    File directory = new File(directoryName);
        	    if (! directory.exists()){
        	        directory.mkdir();
        	        // If you require it to make the entire directory path including parents,
        	        // use directory.mkdirs(); here instead.
        	    }

 
        	List<String> fileNames = null;
	    	
	    		long c1 = Long.valueOf(form.getTestid());
	    		Optional<Task> taskoptional = taskrepo.findById(c1);
	    		Task filetask = taskoptional.get();
	    		
		        fileNames = Arrays.asList(form.getFiles())
		                .stream()
		                .map(file -> {
		                	fileStorage.store1(file,directoryName);
		                	
		                 //  System.out.println(file.getOriginalFilename() +"file name" + file);
		                   
		                 // final String UPLOADED_FOLDER = "E:/dawon 9-14-2019/Projects/tasktracker project/uploadfile"+file.getOriginalFilename();
		                   String UPLOADED_FOLDER1 = directoryName+"/"+file.getOriginalFilename();
		                   FilesModel fst = filerepo.save(new FilesModel(file.getOriginalFilename(), String.valueOf(file.getSize()), file.getContentType(), UPLOADED_FOLDER1 , filetask));
		                  rlist.add(fst);
		                	return file.getOriginalFilename();
		                })
		                .collect(Collectors.toList());
	
 
        }
        // Here Catch IOException only.
        // Other Exceptions catch by RestGlobalExceptionHandler class.
        catch (Exception e) {
            e.printStackTrace();
            return rlist;
  //          return new ResponseEntity<>("Error: " + e.getMessage(), HttpStatus.BAD_REQUEST);
        }
        int v = 0;
        for (FilesModel filesModel : rlist) {
        	v++;
		//System.out.println("test :"+ v+"-"+filesModel.getId()+"--"+filesModel.getFileurl());	
		}
 return rlist;
    //    return new ResponseEntity<String>("Uploaded to: " + result, HttpStatus.OK);
    }
	
	
	
	
	  @RequestMapping(value = "/getfileid/{id}", method = RequestMethod.POST)
	  public List<FilesModel> taskComplete(@PathVariable("id") long[] id,@RequestBody FilesModel filesmodel) 
	  {
		/*
		 * System.out.println("in file model update" + id.length +" "
		 * +filesmodel.getFilename() +" " +filesmodel.getFileurl());
		 */
		  for(int i = 0; i< id.length;i++)
		  {
			 // System.out.println("list of ids: "+id[i]);
			 
		  }
		  Set<Fileslist> flist = new HashSet<Fileslist>();
		/*
		 * for (Fileslist sp : filesmodel.getFilelist()) {
		 * 
		 * }
		 */
		
      return null;
	  }
	 
	  
	  @RequestMapping(value = "/setfileid", method = RequestMethod.POST)
	  public ResponseEntity<Resource> updatefiles(@RequestBody List<FilesModel> filesmodel) 
	  {

		  for (FilesModel filesModel2 : filesmodel) 
		  {
			  Optional<FilesModel> taskOptional = filerepo.findById(filesModel2.getId()); 
				if (!taskOptional.isPresent()) 
					return ResponseEntity.notFound().build();
				
				FilesModel fileslist1 = taskOptional.get();
				
				fileslist1.setFilelist(filesModel2.getFilelist());
				filerepo.save(fileslist1);
		  }
			
		
		  return ResponseEntity.ok().build();
	  }
	 
	
	
	
	  @RequestMapping("/getfilesList")
	  public List<Fileslist> getallfiles() 
    	{
	    return (List<Fileslist>) listrepo.findAll();
	   }
	  

	  //get all files
	    @GetMapping("/rest/getAllFiles/{task_id}")
	    public List<Object[]> getListFiles(@PathVariable long task_id) 
	    {
	    	
		/*
		 * String filelocation = UPLOADED_FOLDER+task_id;
		 * System.out.println("folder location: "+filelocation); File uploadDir = new
		 * File(filelocation);
		 */
	        
	        List<Object[]> fileslist = new ArrayList<>();
	       
		/*
		 * File[] files = uploadDir.listFiles();
		 */
	    	List<Object[]> list = filerepo.findbyObjects(Long.valueOf(task_id));
	    	
	     //   List<String> list = new ArrayList<String>();
	    	
	    	String c1 = null;
			String c2 = null;
			String c3 = null;
			String c4 = null;     

			for (Object[] obj : list) {
				System.out.println(obj[0]+":"+obj[1]);
				
			     c1 = String.valueOf(obj[0]);
			     c2 = String.valueOf(obj[1]);
			     
			     c3 = String.valueOf(obj[2]);
			     c4 = String.valueOf(obj[3]);
			      fileslist.add(obj); 
			    // fileslist.add(c2);
			}
			//System.out.println("files list: "+fileslist);
			return fileslist;
		/*
		 * for (Object[] file : files) { list.add(file.getName());
		 * list.add(filelocation); } return list;
		 */
	    }
	    
	    @GetMapping("/rest/files/{id}")
	    public ResponseEntity<Resource> getFile(@PathVariable long id) throws MalformedURLException {
	    	
	    	 Optional<FilesModel> taskOptional = filerepo.findById(Long.valueOf(id)); 
		/*
		 * if (!taskOptional.isPresent()) return ResponseEntity.notFound();
		 */
				FilesModel fileslist1 = taskOptional.get();
				
				String filename = fileslist1.getFileurl();
	    	
	    	System.out.println("name of the file is"+filename);
	        File file = new File(filename);
	        if (!file.exists()) {
	            throw new RuntimeException("File not found");
	        }
	        Resource resource = new UrlResource(file.toURI());
	        return ResponseEntity.ok()
	                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getName() + "\"")
	                .body(resource);
	    }
	 
	  
	  @RequestMapping("/getfilesdetails/{task_id}")
	  public List<FilesModel> filesdetails(@PathVariable long task_id) 
    	{
		  
	    return (List<FilesModel>) filerepo.findbytaskid(task_id);
	   }
	  
	  
	  

		
		
		
	/*
	 * @PostMapping("uploadfile") public ResponseEntity<?>
	 * uploadFileMulti(MultipartFile file) throws Exception {
	 * 
	 * // System.out.println("Description:" + form.getUid()+"file" + form.getFiles()
	 * + form.getFilename()); System.out.println(file.getName()); String result =
	 * null; return new ResponseEntity<String>("Uploaded to: " + result,
	 * HttpStatus.OK); }
	 */
	}

