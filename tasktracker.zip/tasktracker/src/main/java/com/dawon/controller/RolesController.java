package com.dawon.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dawon.model.Roles;
import com.dawon.repositories.RolesRepository;

@RestController
public class RolesController 
{
	@Autowired
	RolesRepository repo;
	
	/*@RequestMapping("/getroles")
	  public ArrayList<Roles> getAllroles() 
  	{
		System.out.println("getroles method..." +Roles.toString());
	    return (ArrayList<Roles>) repo.findAll();
	}
	*/

	@RequestMapping(value = "/getroles")
	public List<Roles> getworkflow() 
	{

		List<Roles> roless = (List<Roles>) repo.findAll();
	
		return roless;
	}


}
