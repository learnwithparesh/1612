package com.dawon.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dawon.model.Employee;
import com.dawon.model.Task;
import com.dawon.model.Workflow;
import com.dawon.repositories.EmployeeRepository;
import com.dawon.repositories.RolesRepository;
import com.dawon.repositories.TaskRepository;
import com.dawon.repositories.WorkflowRepository;

@RestController
public class EmployeeController
{
	@Autowired
	EmployeeRepository empRepo;
	
	@Autowired
	RolesRepository rolerepo;
	
	@Autowired
	TaskRepository taskrepo;
	
	@Autowired
	WorkflowRepository workflowrepo;
	
	long uid;
	Employee emp1;
	
	@RequestMapping(value="/myLogin1",method = RequestMethod.POST)
	 public  HashMap<String, Object> ProcessUsers(@RequestBody Employee empl,HttpServletResponse response) throws IOException
	 {
		 Optional<Employee> p1 = empRepo.findByEmailAndPassword(empl.getEmail(),empl.getPassword());
		 
		 HashMap<String, Object> map = new HashMap<>();
		   
		    if (p1.isPresent())
			{
				
				 Employee foo = p1.get();
				 //String name = foo.getName();
					map.put("rsd", "success");
					map.put("id", foo.getId());
					map.put("roles", foo.getRoles());
					//map.put("id", foo.getOrgid());
					map.put("name", foo.getName());
				     uid = foo.getId();
				     emp1 = foo;
					//System.out.println("userId ---" + foo.getId());
				//	 response.sendRedirect("/#/u/"+foo.getName()+"/"+foo.getOrg_id());
			}
			else
			{
				
				map.put("rsd", "error");
			}
			return map;
	 }
	
	@RequestMapping(value="/addemployee", method = RequestMethod.POST)
	public ResponseEntity<Object>  saveEmployee(@RequestBody Employee employee)
	{
		empRepo.save(employee);		
		return ResponseEntity.noContent().build();		
	}
	
	//update the profile of employee
	@RequestMapping(value="/updateemployee/{id}", method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> updateeployee(@RequestBody Employee employee,@PathVariable long id) 
	{
		//System.out.println("in controller" +id);
		
		Optional<Employee> employeeoptional = empRepo.findById(id);
		if(!employeeoptional.isPresent())
		{
			return ResponseEntity.notFound().build();
		}
			
			Employee emp1 = employeeoptional.get();
			
			//emp1.setId(id);
			emp1.setPassword(employee.getPassword());
			emp1.setEmail(employee.getEmail());
			emp1.setGender(employee.getGender());
			emp1.setName(employee.getName());
			emp1.setContactnumber(employee.getContactnumber());
			//emp1.setBdate(employee1.getBdate());
			emp1.setPaddress(employee.getPaddress());
			emp1.setCaddress(employee.getCaddress());
			//emp1.setPosts(emp1.getPosts());
		Employee eupdates =	empRepo.save(emp1);
			
	//System.out.println("employee"+ eupdates.toString());
			return ResponseEntity.noContent().build();
	
		
	}	
	
	
		

	@RequestMapping("/getempList")
	  public List<Employee> getAllRooms() 
    	{
	    return (List<Employee>) empRepo.findAll();
	   }
	
	
	@RequestMapping(value = "/getempbyid/{id}", method = RequestMethod.POST)
	public Employee updateemp(@PathVariable long id) 
	{		
		Optional<Employee> empOptional = empRepo.findById(id); 
		if (!empOptional.isPresent()) 
			return null;
		
		Employee emp1 = empOptional.get();
		
		return emp1;		
	}
	

	
	@RequestMapping(value = "/rejecttask/{id}", method = RequestMethod.POST)
	public ResponseEntity<Object> taskReject(@RequestBody Task task,@PathVariable long id) 
	{		
		Optional<Task> taskOptional = taskrepo.findById(id); 
		if (!taskOptional.isPresent()) 
			return ResponseEntity.notFound().build();
		
		
		Task task1 = taskOptional.get();
		task1.setId(id);
		task1.setStatus(1);
		task1.setColor("red");
		taskrepo.save(task1);
		
		//for notification(workflow table)
		/*Workflow w = new Workflow();
		long c2 = Long.valueOf(task.getAssignto());
		Optional<Employee> taskoptional2 = empRepo.findById(c2);
		Employee e2 = taskoptional2.get();

		long c1 = Long.valueOf(task.getInsert_by());
		Optional<Employee> taskoptional = empRepo.findById(c1);
		Employee e = taskoptional.get();
		
		w.setTask(task1);
		w.setTitle("New Task Added");
		w.setNstatus("1");
		w.setTstatus("1");
		w.setTask_to(e2);
		w.setTask_from(e);
		workflowrepo.save(w);*/
		
		return ResponseEntity.noContent().build();		
	}
	
	
/*	@RequestMapping(value = "/completeworkflow/{id}", method = RequestMethod.POST)
	public ResponseEntity<Object> workflowComplete(@RequestBody Workflow workflow, @PathVariable long id) 
	{		
		

		Date date=new Date();
		
		Optional<Task> taskoptional = taskrepo.findById(id);
		
		if (!taskoptional.isPresent()) 
			return ResponseEntity.notFound().build();
		
		else
		{
			Task task = taskoptional.get();
			workflow.setTask(task);	
			workflow.setTitle("New Task Assigned");
			workflow.setNstatus("1");
			workflow.setTstatus("0");
			
			System.out.println("task_to" +workflow.getTask_to());

			workflowrepo.save(workflow);
			return ResponseEntity.noContent().build();
		}
	}
*/
	
	@RequestMapping("/findByLeavefrom")
	  public ArrayList<Employee> findByLeavefrom(@RequestParam("leavefrom") Date leavefrom) 
  	{
		//List<Employee> employee = empRepo.findById(id);
	    return (ArrayList<Employee>) empRepo.findAll();
	}
	
	@RequestMapping("/getEmpCount")
	  public long getempCount() {
	    return empRepo.count();
	  }
	
	
	@RequestMapping(value = "/empbyid/{id}", method = RequestMethod.GET)
	public Employee emplo(@PathVariable long id) 
	{		
		Optional<Employee> empOptional = empRepo.findById(id); 
		if (!empOptional.isPresent()) 
			return null;
		
		Employee emp1 = empOptional.get();
		
		return emp1;		
	}
}
