package com.dawon.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dawon.model.Holidays;
import com.dawon.model.Project;
import com.dawon.repositories.HolidaysRepository;

@RestController
public class HolidaysController
{
	@Autowired
	HolidaysRepository repo;
	
	@RequestMapping(value="/addholidays", method=RequestMethod.POST)
	public Holidays saveholidays(@RequestBody Holidays holidays)
	{
	//	System.out.println(holidays.toString()+"holidays");
		Holidays h = repo.save(holidays);
		//repo.save(holidays);
		return h;
	}
	
	@RequestMapping(value = "/viewholidays")
	public List<Holidays> getHolidays() 
	{

		List<Holidays> holidays = (List<Holidays>) repo.findAll();
		//System.out.println(holidays+"holidays");;
		return holidays;
	}

}
