package com.dawon.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dawon.model.Employee;
import com.dawon.model.Task;
import com.dawon.model.Workflow;
import com.dawon.repositories.TaskRepository;
import com.dawon.repositories.WorkflowRepository;



@RestController
public class WorkFlowController
{
	@Autowired
	WorkflowRepository workflowrepo;
	
	@Autowired 
	TaskRepository taskrepo;
	
	@RequestMapping(value="/addworkflow/{id}",method = RequestMethod.POST,produces = "application/json")
	 public ResponseEntity<Object> saveWorkFlow(@RequestBody Workflow workflow, @PathVariable long id)
	{
		
		Date date=new Date();
		
		//System.out.println("last assign id in saveWorkFlow : "+workflow.getTask_from().getId());
		//System.out.println("task to: "+ workflow.getTask_to().getId());
		
		Optional<Task> taskoptional = taskrepo.findById(id);
		
		if (!taskoptional.isPresent()) 
			return ResponseEntity.notFound().build();
		
		else
		{
			Task task = taskoptional.get();
			workflow.setTask(task);	
			workflow.setTitle("New Task Assigned");
			workflow.setNstatus("1");
			workflow.setTstatus("2");
			
			workflow.setNoticode(workflow.getNoticode());
			
	 
	  //  workflowrepo.save(workflow);
			
			//System.out.println("after workflow");
			task.setId(id);
			task.setStatus(2);
			task.setColor("#d3d3d3");	
			task.setLastassign(workflow.getTask_to());
			task.getWorkflow().add(workflow);
			
			taskrepo.save(task);
			return ResponseEntity.ok().build();
		}
	}

	public Date addHoursToJavaUtilDate(Date date, int hours) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.HOUR_OF_DAY, hours);
		return calendar.getTime();
		}
	@SuppressWarnings("deprecation")
	@RequestMapping(value="/addworkflow/{id}/{dates}",method = RequestMethod.POST,produces = "application/json")
	 public ResponseEntity<Object> saveWorkFlowwithenddate(@RequestBody Workflow workflow, @PathVariable long id, @PathVariable String dates)
	{
		//System.out.println("last assign id in saveWorkFlowwithenddate : "+workflow.getTask_from());
		Date date=new Date();
		String replaceString=dates.replaceAll("-","/");
		date = new Date(replaceString);
		Date date1=null;
		try {
			 date1=new SimpleDateFormat("dd/MM/yyyy").parse(replaceString);
			 date1= addHoursToJavaUtilDate(date1, 12);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		
	//	System.out.println(date1 +"date1");
		Optional<Task> taskoptional = taskrepo.findById(id);
		
		if (!taskoptional.isPresent()) 
			return ResponseEntity.notFound().build();
		
		else
		{
			Task task = taskoptional.get();
			
			
			workflow.setTask(task);	
			workflow.setTitle("New Task Assigned");
			workflow.setNstatus("1");
			workflow.setTstatus("2");
		 
			
		//	System.out.println("task_to" +workflow.getTask_to());
			
			workflowrepo.save(workflow);
			task.setId(id);
			task.setStatus(2);
			task.setColor("#d3d3d3");	
			task.setLastassign(workflow.getTask_to());
			task.setEndDate(date1);
			//task.setendDate(date1);
			taskrepo.save(task);
			return ResponseEntity.ok().build();
		}
	}

/*@RequestMapping(value = "/getnoti/{id}/{status}")
	public List<Workflow> getNotification(@PathVariable long id,@PathVariable long status) 
	{
		//List<Workflow> workflow = (List<Workflow>) workflowrepo.findByEmp(id);
	System.out.println(status +"status");
	    if(status == 0)
	    {
	    	return workflowrepo.findByEmp2(id);
	    }
	    else if(status == 1)
	    {
	    	return workflowrepo.findByEmp3(id);
	    }
	    else 
	    {
	    	return workflowrepo.findByEmp1(id);
	    }
	}
*/
	@RequestMapping(value = "/getnoti/{id}")
	public List<Workflow> getNotification(@PathVariable long id) 
	{
		//List<Workflow> workflow = (List<Workflow>) workflowrepo.findByEmp(id);
	
	    	return workflowrepo.findByEmp(id);
	    
	}
	
	@RequestMapping(value = "/updateNoticode/{id}", method = RequestMethod.POST)
	public ResponseEntity<Object> saveTask(@PathVariable long id) 
	{	
		System.out.println("id: "+ id);
		Optional<Workflow>workflowOptional = workflowrepo.findById(id);
		if(!workflowOptional.isPresent()) {
			return ResponseEntity.notFound().build();
		}
		else {
			Workflow workflow = workflowOptional.get();
			workflow.setId(id);
			workflow.setNoticode("1");
			workflowrepo.save(workflow);
		}
	   
		return ResponseEntity.ok().build();
	}

	
	

	@RequestMapping(value = "/getworkflow")
	public List<Workflow> getworkflow() 
	{
		List<Workflow> workflow = (List<Workflow>) workflowrepo.findAll();
		/* System.out.println(workflow); */
		return workflow;
	}
	
	  //get total count of send and received task
		@RequestMapping(value="/gettaskscount/{taskfrom}")
		public List<String> getcountoftask(@PathVariable long taskfrom) 
		{
			///System.out.println(taskfrom +"taskfrom");
			List<String> task = new ArrayList<>();
			List<Object[]> list = workflowrepo.findBycount(Long.valueOf(taskfrom));
			String c1 = null;
			String c2 = null;
			
			for (Object[] obj : list) {
				System.out.println(obj[0]+":"+obj[1]);
			     c1 = String.valueOf(obj[0]);
			     c2 = String.valueOf(obj[1]);
			     task.add(c1);
			     task.add(c2);
			}
		//	System.out.println("hi hi : "+ c1 + ": "+ c2);
			return task;
		}	
		
		    //get total count of send and received task
				@RequestMapping(value="/gettasksbydate/{taskfrom}")
				public List<Object[]> getcountoftaskbydate(@PathVariable long taskfrom) 
				{
					//System.out.println(taskfrom +"taskfrom");
					List<String> task = new ArrayList<>();
					List<Object[]> list = workflowrepo.findBycountfrom(Long.valueOf(taskfrom));
			/*		
					String c1 = null;
					String c2 = null;
					
					for (Object[] obj : list) {
						System.out.println(obj[0]+":"+obj[1]);
					     c1 = String.valueOf(obj[0]);
					     c2 = String.valueOf(obj[1]);
					     task.add(c1);
					     task.add(c2);
					}
					System.out.println("hi hi : "+ c1 + ": "+ c2);*/
					return list;
				}	
				

		
	
}
