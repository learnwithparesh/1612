package com.dawon.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="roles")
public class Roles
{
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name="role_name")
	private String rolename;
	
	@Column(name="description")
	private String description;
	
	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getRole_name() {
		return rolename;
	}

	public void setRole_name(String role_name) {
		this.rolename = role_name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Roles() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Roles(long id, String rolename, String description) {
		super();
		this.id = id;
		this.rolename = rolename;
		this.description = description;
	}

	public Roles(String rolename, String description) {
		super();
		this.rolename = rolename;
		this.description = description;
	}

	@Override
	public String toString() {
		return "Roles [id=" + id + ", role_name=" + rolename + ", description=" + description + "]";
	}
	
	

}
