package com.dawon.model;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "employee")
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@Column(name = "email")
	private String email;

	@Column(name = "password")
	private String password;

	@Column(name = "name")
	private String name;

	@Column(name = "lastName")
	private String lastName;

	@Column(name = "active")
	private int active;

	@Column(name = "orgid")
	private int orgid;

	@Column(name = "mid")
	private String mid;

	@Column(name = "contactnumber")
	private String contactnumber;

	@Column(name = "gender")
	private String gender;

	@Column(name = "bdate")
	 @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd/MM/yyyy") 
	private Date bdate;

	@Column(name = "caddress")
	private String caddress;

	@Column(name = "paddress")
	private String paddress;
	
	@Column(name = "posts")
	private String posts;

	@OneToMany(mappedBy = "employee", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JsonIgnore
	private Set<Task> task;

	@OneToMany(mappedBy = "employee", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JsonIgnoreProperties("employee")
	private Set<Empavailable> empavailable;

	@OneToMany(mappedBy = "employee",cascade=CascadeType.ALL, fetch = FetchType.EAGER)
	//@JsonIgnoreProperties("employee")
	@JsonIgnore
	private Set<ProjectTeams> projectteams;

	
	/*@ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.ALL)
	@JsonIgnore
	private Project project;*/

	@OneToOne
	private Roles roles;

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getActive() {
		return active;
	}

	public void setActive(int active) {
		this.active = active;
	}

	public int getOrgid() {
		return orgid;
	}

	public void setOrgid(int orgid) {
		this.orgid = orgid;
	}

	public String getMid() {
		return mid;
	}

	public void setMid(String mid) {
		this.mid = mid;
	}

	public String getContactnumber() {
		return contactnumber;
	}

	public void setContactnumber(String contactnumber) {
		this.contactnumber = contactnumber;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getBdate() {
		return bdate;
	}

	public void setBdate(Date bdate) {
		this.bdate = bdate;
	}

	public String getCaddress() {
		return caddress;
	}

	public void setCaddress(String caddress) {
		this.caddress = caddress;
	}

	public String getPaddress() {
		return paddress;
	}

	public void setPaddress(String paddress) {
		this.paddress = paddress;
	}

	public Set<Task> getTask() {
		return task;
	}

	public void setTask(Set<Task> task) {
		this.task = task;
	}

	public Set<Empavailable> getEmpavailable() {
		return empavailable;
	}

	public void setEmpavailable(Set<Empavailable> empavailable) {
		this.empavailable = empavailable;
	}

	public Set<ProjectTeams> getProjectteams() {
		return projectteams;
	}

	public void setProjectteams(Set<ProjectTeams> projectteams) {
		this.projectteams = projectteams;
	}
	
	

	/*public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}*/

	public String getPosts() {
		return posts;
	}

	public void setPosts(String posts) {
		this.posts = posts;
	}

	public Roles getRoles() {
		return roles;
	}

	public void setRoles(Roles roles) {
		this.roles = roles;
	}

	



	public Employee(long id, String email, String password, String name, String lastName, int active, int orgid,
			String mid, String contactnumber, String gender, Date bdate, String caddress, String paddress,String post,
			Set<Task> task, Set<Empavailable> empavailable, Set<ProjectTeams> projectteams,/* Project project,*/
			Roles roles) {
		super();
		this.id = id;
		this.email = email;
		this.password = password;
		this.name = name;
		this.lastName = lastName;
		this.active = active;
		this.orgid = orgid;
		this.mid = mid;
		this.contactnumber = contactnumber;
		this.gender = gender;
		this.bdate = bdate;
		this.caddress = caddress;
		this.paddress = paddress;
		this.task = task;
		this.empavailable = empavailable;
		this.projectteams = projectteams;
		this.posts = post;
		/*this.project = project;*/
		this.roles = roles;
	}

	
	public Employee(String email, String password, String name, String lastName, int active, int orgid, String mid,
			String contactnumber, String gender, Date bdate, String caddress, String paddress,String post, Set<Task> task,
			Set<Empavailable> empavailable, Set<ProjectTeams> projectteams, /*Project project,*/ Roles roles) {
		super();
		this.email = email;
		this.password = password;
		this.name = name;
		this.lastName = lastName;
		this.active = active;
		this.orgid = orgid;
		this.mid = mid;
		this.contactnumber = contactnumber;
		this.gender = gender;
		this.bdate = bdate;
		this.caddress = caddress;
		this.paddress = paddress;
		this.task = task;
		this.empavailable = empavailable;
		this.projectteams = projectteams;
		this.posts = post;
		/*this.project = project;*/
		this.roles = roles;
	}

	
	public Employee(String email, String password, String name, String lastName, int active, int orgid, String mid,
			String contactnumber, String gender, Date bdate, String caddress, String paddress,String post, Set<Task> task) {
		super();
		this.email = email;
		this.password = password;
		this.name = name;
		this.lastName = lastName;
		this.active = active;
		this.orgid = orgid;
		this.mid = mid;
		this.contactnumber = contactnumber;
		this.gender = gender;
		this.bdate = bdate;
		this.caddress = caddress;
		this.paddress = paddress;
		this.posts = post;
		this.task = task;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", email=" + email + ", password=" + password + ", name=" + name + ", lastName="
				+ lastName + ", active=" + active + ", orgid=" + orgid + ", mid=" + mid + ", contactnumber="
				+ contactnumber + ", gender=" + gender + ", bdate=" + bdate + ", caddress=" + caddress + ", paddress="
				+ paddress + ", posts=" + posts + ", task=" + task + ", empavailable=" + empavailable
				+ ", projectteams=" + projectteams + ", roles=" + roles + "]";
	}

	/*@Override
	public String toString() {
		return "Employee [id=" + id + ", email=" + email + ", password=" + password + ", name=" + name + ", lastName="
				+ lastName + ", active=" + active + ", orgid=" + orgid + ", mid=" + mid + ", contactnumber="
				+ contactnumber + ", gender=" + gender + ", bdate=" + bdate + ", caddress=" + caddress + ", paddress="
				+ paddress + ", task=" + task + ", empavailable=" + empavailable + ", projectteams=" + projectteams
				+ ", project=" + project + ", roles=" + roles + "]";
	}
*/
	
	
	
	

}
