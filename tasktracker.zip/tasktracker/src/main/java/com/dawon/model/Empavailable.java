package com.dawon.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "empavailable")
public class Empavailable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	   @Temporal(TemporalType.TIMESTAMP)
	  // @JsonFormat(pattern="yyyy-MM-dd")
		@Column(name = "leavefrom")
		private Date leavefrom;

		@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	    @Temporal(TemporalType.TIMESTAMP)
	   // @JsonFormat(pattern="yyyy-MM-dd")
		@Column(name = "leaveto")
		private Date leaveto;

		@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
		@Column(name = "meetingstime",columnDefinition="DATETIME")
		private String meetingstime;
	     
		//@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy@HH:mm:ss.SSSZ")
		@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
		@Column(name = "meetingetime",columnDefinition="DATETIME")
		private String meetingetime;

	@Column(name = "description")
	private String description;

	/*
	 * @JsonIgnore
	 * 
	 * @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.ALL)
	 * 
	 * @JoinColumn(name = "employee_id", nullable = false)
	 */

	// @JsonIgnoreProperties("EmpAvailable")
	// @OneToMany(mappedBy = "employee", fetch = FetchType.EAGER)
	// @JsonIgnore
	@ManyToOne(fetch = FetchType.EAGER, optional = false)
	@JsonIgnoreProperties("empavailable")
	// @JoinColumn(name = "employee_id", nullable = false)
	private Employee employee;

	public Empavailable() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
	public Empavailable(long id, Date leavefrom, Date leaveto, String meetingstime, String meetingetime,
			String description, Employee employee) {
		super();
		this.id = id;
		this.leavefrom = leavefrom;
		this.leaveto = leaveto;
		this.meetingstime = meetingstime;
		this.meetingetime = meetingetime;
		this.description = description;
		this.employee = employee;
	}



	public Empavailable(Date leavefrom, Date leaveto, String meetingstime, String meetingetime, String description,
			Employee employee) {
		super();
		this.leavefrom = leavefrom;
		this.leaveto = leaveto;
		this.meetingstime = meetingstime;
		this.meetingetime = meetingetime;
		this.description = description;
		this.employee = employee;
	}



	public Empavailable(Date leavefrom, Date leaveto, String meetingstime, String meetingetime, String description) {
		super();
		this.leavefrom = leavefrom;
		this.leaveto = leaveto;
		this.meetingstime = meetingstime;
		this.meetingetime = meetingetime;
		this.description = description;
	}



	/*public Empavailable(long id, Date leavefrom, Date leaveto, Date meetingstime, Date meetingetime,
			String description, Employee employee) {
		super();
		this.id = id;
		this.leavefrom = leavefrom;
		this.leaveto = leaveto;
		this.meetingstime = meetingstime;
		this.meetingetime = meetingetime;
		this.description = description;
		this.employee = employee;
	}

	public Empavailable(Date leavefrom, Date leaveto, Date meetingstime, Date meetingetime, String description,
			Employee employee) {
		super();
		this.leavefrom = leavefrom;
		this.leaveto = leaveto;
		this.meetingstime = meetingstime;
		this.meetingetime = meetingetime;
		this.description = description;
		this.employee = employee;
	}

	public Empavailable(Date leavefrom, Date leaveto, Date meetingstime, Date meetingetime, String description) {
		super();
		this.leavefrom = leavefrom;
		this.leaveto = leaveto;
		this.meetingstime = meetingstime;
		this.meetingetime = meetingetime;
		this.description = description;
	}
	
	*/

	/*
	 * public Empavailable(Date leave_from, Date leave_to, Date meeting_stime, Date
	 * meeting_etime) { super();
	 * 
	 * this.leave_from = leave_from; this.leave_to = leave_to; this.meeting_stime =
	 * meeting_stime; this.meeting_etime = meeting_etime; }
	 * 
	 */

	/*
	 * public Empavailable(Date leave_from, Date leave_to) { super();
	 * 
	 * this.leave_from = leave_from; this.leave_to = leave_to; }
	 * 
	 * 
	 * 
	 * public Empavailable(Date leave_from, Date leave_to, Date meeting_stime, Date
	 * meeting_etime, Employee employee) { super(); this.leave_from = leave_from;
	 * this.leave_to = leave_to; this.meeting_stime = meeting_stime;
	 * this.meeting_etime = meeting_etime; this.employee = employee; }
	 */

	public Empavailable(Date leavefrom, Date leaveto, String description) {
		super();
		this.leavefrom = leavefrom;
		this.leaveto = leaveto;
		this.description = description;
		
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}



	public Date getLeavefrom() {
		return leavefrom;
	}

	public void setLeavefrom(Date leavefrom) {
		this.leavefrom = leavefrom;
	}

	public Date getLeaveto() {
		return leaveto;
	}

	public void setLeaveto(Date leaveto) {
		this.leaveto = leaveto;
	}

/*	public Date getMeetingstime() {
		return meetingstime;
	}
	
	public void setMeetingstime(Date meetingstime) {
		this.meetingstime = meetingstime;
	}

	public Date getMeetingetime() {
		return meetingetime;
	}

	public void setMeetingetime(Date meetingetime) {
		this.meetingetime = meetingetime;
	}*/

	public String getDescription() {
		return description;
	}

	public String getMeetingstime() {
		return meetingstime;
	}



	public void setMeetingstime(String meetingstime) {
		this.meetingstime = meetingstime;
	}



	public String getMeetingetime() {
		return meetingetime;
	}



	public void setMeetingetime(String meetingetime) {
		this.meetingetime = meetingetime;
	}



	public void setDescription(String description) {
		this.description = description;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	@Override
	public String toString() {
		return "Empavailable [id=" + id + ", leavefrom=" + leavefrom + ", leaveto=" + leaveto + ", meetingstime="
				+ meetingstime + ", meetingetime=" + meetingetime + ", description=" + description + ", employee="
				+ employee + "]";
	}


}
