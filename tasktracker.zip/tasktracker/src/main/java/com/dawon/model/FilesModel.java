package com.dawon.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="files")
public class FilesModel 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name="filename")
	private String filename;

	@Column(name="filesize")
	private String filesize;
	
	@Column(name="filetype")
    private String filetype;
 
	@Column(name="fileurl")
	private String fileurl;
	
	@Column(name="testid")
	private String testid;
	

	

    @JsonIgnore
    private MultipartFile[] files;
    
    @OneToOne
    private Task task;
    
    @OneToOne
    private Fileslist filelist;

	public FilesModel() {
		super();
		// TODO Auto-generated constructor stub
	}
	


	public FilesModel(long id, String filename, String filesize, String filetype, String fileurl, String testid,
			MultipartFile[] files, Task task, Fileslist filelist) {
		super();
		this.id = id;
		this.filename = filename;
		this.filesize = filesize;
		this.filetype = filetype;
		this.fileurl = fileurl;
		this.testid = testid;
		this.files = files;
		this.task = task;
		this.filelist = filelist;
	}




	public FilesModel(String filename, String filesize, String filetype, String fileurl, Task task) {
		super();
		this.filename = filename;
		this.filesize = filesize;
		this.filetype = filetype;
		this.fileurl = fileurl;
		this.task = task;
	}
	

	public FilesModel(String filename, String filesize, String filetype, String fileurl) {
		super();
		this.filename = filename;
		this.filesize = filesize;
		this.filetype = filetype;
		this.fileurl = fileurl;
	}
	

	public FilesModel(long id, Fileslist filelist) {
		super();
		this.id = id;
		this.filelist = filelist;
	}


	

	public String getTestid() {
		return testid;
	}
	


	public void setTestid(String testid) {
		this.testid = testid;
	}



	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public String getFilesize() {
		return filesize;
	}

	public void setFilesize(String filesize) {
		this.filesize = filesize;
	}

	public String getFiletype() {
		return filetype;
	}

	public void setFiletype(String filetype) {
		this.filetype = filetype;
	}

	public String getFileurl() {
		return fileurl;
	}

	public void setFileurl(String fileurl) {
		this.fileurl = fileurl;
	}



	public Task getTask() {
		return task;
	}

	public void setTask(Task task) {
		this.task = task;
	}

	public MultipartFile[] getFiles() {
		return files;
	}

	public void setFiles(MultipartFile[] files) {
		this.files = files;
	}




	public Fileslist getFilelist() {
		return filelist;
	}




	public void setFilelist(Fileslist filelist) {
		this.filelist = filelist;
	}



	
	
	
	
	

	

}


