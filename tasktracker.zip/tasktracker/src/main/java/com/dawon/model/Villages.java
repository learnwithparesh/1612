package com.dawon.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
@Table(name="villages")
public class Villages
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@Column(name="villagename")
	private String villagename;
/*
	@ManyToOne(optional = true,fetch = FetchType.LAZY,cascade=CascadeType.ALL)
	@JsonIgnoreProperties("villages")
	private Districts districts;
	*/
	
	
	//private Property property;
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getVillagename() {
		return villagename;
	}

	public void setVillagename(String villagename) {
		this.villagename = villagename;
	}
/*
	public Districts getDistricts() {
		return districts;
	}

	public void setDistricts(Districts districts) {
		this.districts = districts;
	}*/

	public Villages() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Villages(long id, String villagename/*, Districts districts*/) {
		super();
		this.id = id;
		this.villagename = villagename;
		/*this.districts = districts;*/
	}

	public Villages(String villagename/*, Districts districts*/) {
		super();
		this.villagename = villagename;
		/*this.districts = districts;*/
	}

	@Override
	public String toString() {
		return "Villages [id=" + id + ", villagename=" + villagename + "]";
	}

	

	
}
