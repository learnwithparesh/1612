package com.dawon.model;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.data.annotation.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "property")
public class Property {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@Column(name = "propid")
	private String propid;

	/*@Column(name = "pname")
	private String pname;*/

	@Column(name = "description")
	private String description;

	@Column(name = "courtcaseno")
	private String courtcaseno;

	@Column(name = "courtname")
	private String courtname;

	@Column(name = "address")
	private String address;

	/*@Column(name = "pincode")
	private String pincode;

	@Column(name = "cort_case")
	private String court_case;*/

	@Column(name = "courtstatus")
	private String courtstatus;

	/*@Column(name = "associate_user")
	private String associate_user;*/

	@Column(name = "nexthearing")
	private String nexthearing;

	@Column(name = "otherowner")
	private String otherowner;

/*	@Column(name = "insert_by")
	private int insert_by;
*/
	@Column(name = "insertdate")
	private Date insertdate;

	/*@Column(name = "update_by")
	private int update_by;*/
	
	//relationship with villages table
	    @OneToOne(fetch = FetchType.LAZY)
	    @JoinColumn(name = "villages_id")
		private Villages villages;
	 

	
	//relationship with districts table
	/*@OneToOne
	private Districts districts;*/
	
	
	@Column(name = "filesid")
	private String filesid;
	
	
	 
	
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.ALL)
	@JoinColumn(name = "customer_id", nullable = false)
	private Customer customer;

	public Property() {
		super();
		// TODO Auto-generated constructor stub
	}



	public Property(long id, String propid, String description, /*Districts districts,*/Villages villages,String courtcaseno, String courtname, String address,
			String courtstatus, String nexthearing, String otherowner, Date insertdate, 
			 String filesid, Customer customer) {
		super();
		this.id = id;
		this.propid = propid;
		this.description = description;
		this.courtcaseno = courtcaseno;
		/*this.districts = districts;*/
		this.villages = villages;
		this.courtname = courtname;
		this.address = address;
		this.courtstatus = courtstatus;
		this.nexthearing = nexthearing;
		this.otherowner = otherowner;
		this.insertdate = insertdate;
		this.filesid = filesid;
		this.customer = customer;
	}


	
	public Property(String propid, String description, String courtcaseno,/* Districts districts,*/ Villages villages,String courtname,
			String address, String courtstatus, String nexthearing, String otherowner, Date insertdate,String filesid,Customer customer) {
		super();
		this.propid = propid;
		this.description = description;
		this.courtcaseno = courtcaseno;
		/*this.districts = districts;*/
		this.villages = villages;
		this.courtname = courtname;
		this.address = address;
		this.courtstatus = courtstatus;
		this.nexthearing = nexthearing;
		this.otherowner = otherowner;
		this.insertdate = insertdate;
		this.filesid = filesid;
		this.customer = customer;
	}





	public Property(String propid, String description, String courtcaseno,/* Districts districts,*/Villages villages,String courtname,
			String address, String courtstatus, String nexthearing, String otherowner, Date insertdate,String filesid) {
		super();
		this.propid = propid;
		this.description = description;
		this.courtcaseno = courtcaseno;
		this.courtname = courtname;
		/*this.districts = districts;*/
		this.villages = villages;
		this.address = address;
		this.courtstatus = courtstatus;
		this.nexthearing = nexthearing;
		this.otherowner = otherowner;
		this.insertdate = insertdate;
		this.filesid = filesid;
	}




	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getPropid() {
		return propid;
	}

	public void setPropid(String propid) {
		this.propid = propid;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCourtcaseno() {
		return courtcaseno;
	}

	public void setCourtcaseno(String courtcaseno) {
		this.courtcaseno = courtcaseno;
	}

	public String getCourtname() {
		return courtname;
	}

	public void setCourtname(String courtname) {
		this.courtname = courtname;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCourtstatus() {
		return courtstatus;
	}

	public void setCourtstatus(String courtstatus) {
		this.courtstatus = courtstatus;
	}

	public String getOtherowner() {
		return otherowner;
	}

	public void setOtherowner(String otherowner) {
		this.otherowner = otherowner;
	}

	public Date getInsertdate() {
		return insertdate;
	}

	public void setInsertdate(Date insertdate) {
		this.insertdate = insertdate;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getNexthearing() {
		return nexthearing;
	}



	public void setNexthearing(String nexthearing) {
		this.nexthearing = nexthearing;
	}



	public String getFilesid() {
		return filesid;
	}


	public void setFilesid(String filesid) {
		this.filesid = filesid;
	}

	public Villages getVillages() {
		return villages;
	}



	public void setVillages(Villages villages) {
		this.villages = villages;
	}


/*
	public Districts getDistricts() {
		return districts;
	}



	public void setDistricts(Districts districts) {
		this.districts = districts;
	}
*/


	@Override
	public String toString() {
		return "Property [id=" + id + ", propid=" + propid + ", description=" + description + ", courtcaseno="
				+ courtcaseno + ", courtname=" + courtname + ", address=" + address + ", courtstatus=" + courtstatus
				+ ", nexthearing=" + nexthearing + ", otherowner=" + otherowner + ", insertdate=" + insertdate
				+ ", villages=" + villages + /*", districts=" + districts +*/ ", filesid=" + filesid + ", customer="
				+ customer + "]";
	}




}
