package com.dawon.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name="holidays")
public class Holidays
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	@Column(name="startdate")
	private Date startdate;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	@Column(name="endDate")
	private Date endDate;
	
	@Column(name="description")
	private String description;

	@Column(name="color")
	private String color;
	
	public Holidays() {
		super();
		// TODO Auto-generated constructor stub
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Date getStartdate() {
		return startdate;
	}

	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public Holidays(long id, Date startdate, Date endDate, String description, String color) {
		super();
		this.id = id;
		this.startdate = startdate;
		this.endDate = endDate;
		this.description = description;
		this.color = color;
	}

	public Holidays(Date startdate, Date endDate, String description, String color) {
		super();
		this.startdate = startdate;
		this.endDate = endDate;
		this.description = description;
		this.color = color;
	}

	@Override
	public String toString() {
		return "Holidays [id=" + id + ", startdate=" + startdate + ", endDate=" + endDate + ", description="
				+ description + ", color=" + color + "]";
	}

	

}
