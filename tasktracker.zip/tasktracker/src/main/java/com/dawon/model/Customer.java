package com.dawon.model;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "customer")
public class Customer implements Serializable  {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@Column(name = "name")
	private String name;

	@Column(name = "email")
	private String email;

	@Column(name = "contact_number")
	private String contactnumber;

	@Column(name = "gender")
	private String gender;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	//@Temporal(TemporalType.TIMESTAMP)
	//@CreationTimestamp
	@Column(name = "bdate")
	private Date bdate;

	@Column(name = "c_address")
	private String caddress;

	@Column(name = "p_address")
	private String paddress;

	@Column(name = "adhaar_card")
	private String adhaarCard;

	@Column(name = "update_date")
	private Date updatedate;
	
	/*@Column(name="file")
	private byte file[];*/
	
	@Column(name="pic")
	private byte[] pic;



	@OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	//@JsonIgnore
    private Set<Property> property ;

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
/*
	public Customer(long id, String name, String email, String contact_number, String gender, Date bdate,
			String c_address, String p_address, Date update_date, Set<Property> property) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.contact_number = contact_number;
		this.gender = gender;
		this.bdate = bdate;
		this.c_address = c_address;
		this.p_address = p_address;
		
		this.update_date = update_date;
		this.property = property;
	}
	*/

	

	/*public Customer(String name, String email, String contact_number, String gender, Date bdate, String c_address,
			String p_address, Date update_date, Set<Property> property) {
		super();
		this.name = name;
		this.email = email;
		this.contact_number = contact_number;
		this.gender = gender;
		this.bdate = bdate;
		this.c_address = c_address;
		this.p_address = p_address;
		
		this.update_date = update_date;
		this.property = property;
	}
	*/
	

	public Customer(long id,String name, String email, String contactnumber, String gender, Date bdate, String caddress,
			String paddress, String adhaarCard,byte[] pic/*byte[] file*/) {
		super();
		this.id= id;
		this.name = name;
		this.email = email;
		this.contactnumber = contactnumber;
		this.gender = gender;
		this.bdate = bdate;
		this.caddress = caddress;
		this.paddress = paddress;
		this.adhaarCard = adhaarCard;
		this.pic = pic;
		//this.file = file;
	}
	
	public Customer(long id,String name, String email, String contactnumber, String gender, Date bdate, String caddress,
			String paddress, String adhaarCard, Date updatedate,byte[] pic /*byte[] file*/) {
		super();
		this.id= id;
		this.name = name;
		this.email = email;
		this.contactnumber = contactnumber;
		this.gender = gender;
		this.bdate = bdate;
		this.caddress = caddress;
		this.paddress = paddress;
		this.adhaarCard = adhaarCard;
		this.updatedate = updatedate;
		this.pic = pic;
		//this.file = file;
	}



	public Customer(String name, String email, String contactnumber, String gender, Date bdate, String caddress,
		String paddress, String adhaarCard, Date updatedate, Set<Property> property,byte[] pic/*,byte[] file*/) {
	super();
	this.id= id;
	this.name = name;
	this.email = email;
	this.contactnumber = contactnumber;
	this.gender = gender;
	this.bdate = bdate;
	this.caddress = caddress;
	this.paddress = paddress;
	this.adhaarCard = adhaarCard;
	this.updatedate = updatedate;
	this.property = property;
	this.pic = pic;
	//this.file = file;
}
	public Customer(long id, String name, String email, String contactnumber, String gender, Date bdate,
			String caddress, String paddress, String adhaarCard, Date updatedate, Set<Property> property,byte[] pic/*byte[] file*/) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.contactnumber = contactnumber;
		this.gender = gender;
		this.bdate = bdate;
		this.caddress = caddress;
		this.paddress = paddress;
		this.adhaarCard = adhaarCard;
		this.updatedate = updatedate;
		this.property = property;
		this.pic = pic;
		//this.file = file;
	}



	
	

/*	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", email=" + email + ", contact_number=" + contact_number
				+ ", gender=" + gender + ", bdate=" + bdate + ", c_address=" + c_address + ", p_address=" + p_address
				+ ", adhaarCard=" + adhaarCard + ", update_date=" + update_date + ", file=" + Arrays.toString(file)
				+ ", property=" + property + "]";
	}
*/


	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContactnumber() {
		return contactnumber;
	}

	public void setContactnumber(String contactnumber) {
		this.contactnumber = contactnumber;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getBdate() {
		return bdate;
	}

	public void setBdate(Date bdate) {
		this.bdate = bdate;
	}

	public String getCaddress() {
		return caddress;
	}

	public void setCaddress(String caddress) {
		this.caddress = caddress;
	}

	public String getPaddress() {
		return paddress;
	}

	public void setP_address(String paddress) {
		this.paddress = paddress;
	}

	public Set<Property> getProperty() {
		return property;
	}

	public void setProperty(Set<Property> property) {
		this.property = property;
	}

	public Date getUpdatedate() {
		return updatedate;
	}

	public void setUpdate_date(Date updatedate) {
		this.updatedate = updatedate;
	}

	public String getadhaarCard() {
		return adhaarCard;
	}

	public void setadhaarCard(String adhaarCard) {
		this.adhaarCard = adhaarCard;
	}



	public byte[] getPic() {
		return pic;
	}



	public void setPic(byte[] pic) {
		this.pic = pic;
	}


	

	/*public byte[] getfile() {
		return file;
	}



	public void setfile(byte[] file) {
		this.file = file;
	}
	
	
*/
	
}
