package com.dawon.model;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "project")
public class Project {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@Column(name = "prname")
	private String prname;

	@Column(name = "desc1")
	private String desc1;

	@Column(name = "code")
	private String code;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	//@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd@HH:mm:ss.SSSZ", locale = "en_GB")
	//@Temporal(TemporalType.DATE)
	@Column(name = "start_date")
	private Date startDate;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	//@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd@HH:mm:ss.SSSZ", locale = "en_GB")
	//@Temporal(TemporalType.DATE)
	@Column(name = "end_date")
	private Date endDate;

	@Column(name = "address")
	private String address;

	@Column(name = "insert_date")
	private Date insert_date;

	@Column(name = "insert_by")
	private long insert_by;

	@Column(name = "update_by")
	private long update_by;

	@Column(name = "update_date")
	private Date update_date;

	/*@Column(name = "teamhead")
	private String teamhead;
*/
	
	@OneToOne
	private Employee teamhead;
	
	@Column(name = "filesid")
	private String filesid;

	@OneToMany(mappedBy = "project",cascade=CascadeType.ALL, fetch = FetchType.EAGER)
	//@JsonIgnoreProperties("project")
	private Set<ProjectTeams> projectteams;

	/*@OneToMany(mappedBy = "project",cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	@JsonIgnore
	private Set<Employee> employee;*/

	public Project() {
		super();
		// TODO Auto-generated constructor stub
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getPrname() {
		return prname;
	}

	public void setPrname(String prname) {
		this.prname = prname;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Date getstartDate() {
		return startDate;
	}

	public void setstartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getendDate() {
		return endDate;
	}

	public void setendDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Date getInsert_date() {
		return insert_date;
	}

	public void setInsert_date(Date insert_date) {
		this.insert_date = insert_date;
	}

	public long getInsert_by() {
		return insert_by;
	}

	public void setInsert_by(long insert_by) {
		this.insert_by = insert_by;
	}

	public long getUpdate_by() {
		return update_by;
	}

	public void setUpdate_by(long update_by) {
		this.update_by = update_by;
	}

	public Date getUpdate_date() {
		return update_date;
	}

	public void setUpdate_date(Date update_date) {
		this.update_date = update_date;
	}

	public String getDesc1() {
		return desc1;
	}

	public void setDesc1(String desc1) {
		this.desc1 = desc1;
	}

	

	public Employee getTeamhead() {
		return teamhead;
	}

	public void setTeamhead(Employee teamhead) {
		this.teamhead = teamhead;
	}

	public String getFilesid() {
		return filesid;
	}

	public void setFilesid(String filesid) {
		this.filesid = filesid;
	}

	public Set<ProjectTeams> getProjectteams() {
		return projectteams;
	}

	public void setProjectteams(Set<ProjectTeams> projectteams) {
		this.projectteams = projectteams;
	}

	/*public Set<Employee> getEmployee() {
		return employee;
	}

	public void setEmployee(Set<Employee> employee) {
		this.employee = employee;
	}*/

	public Project(long id, String prname, String desc1, String code, Date startDate, Date endDate, String address,
			Date insert_date, long insert_by, long update_by, Date update_date, Employee teamhead, String filesid,
			Set<ProjectTeams> projectteams/*, Set<Employee> employee*/) {
		super();
		this.id = id;
		this.prname = prname;
		this.desc1 = desc1;
		this.code = code;
		this.startDate = startDate;
		this.endDate = endDate;
		this.address = address;
		this.insert_date = insert_date;
		this.insert_by = insert_by;
		this.update_by = update_by;
		this.update_date = update_date;
		this.teamhead = teamhead;
		this.filesid = filesid;
		this.projectteams = projectteams;
		//this.employee = employee;
	}

	public Project(String prname, String desc1, String code, Date startDate, Date endDate, String address,
			Date insert_date, long insert_by, long update_by, Date update_date, Employee teamhead, String filesid,
			Set<ProjectTeams> projectteams/*, Set<Employee> employee*/) {
		super();
		this.prname = prname;
		this.desc1 = desc1;
		this.code = code;
		this.startDate = startDate;
		this.endDate = endDate;
		this.address = address;
		this.insert_date = insert_date;
		this.insert_by = insert_by;
		this.update_by = update_by;
		this.update_date = update_date;
		this.teamhead = teamhead;
		this.filesid = filesid;
		this.projectteams = projectteams;
		//this.employee = employee;
	}

	public Project(String prname, String desc1, String code, Date startDate, Date endDate, String address,
			Date insert_date, long insert_by, long update_by, Date update_date, Employee teamhead, String filesid) {
		super();
		this.prname = prname;
		this.desc1 = desc1;
		this.code = code;
		this.startDate = startDate;
		this.endDate = endDate;
		this.address = address;
		this.insert_date = insert_date;
		this.insert_by = insert_by;
		this.update_by = update_by;
		this.update_date = update_date;
		this.teamhead = teamhead;
		this.filesid = filesid;
	}
	
	

	@Override
	public String toString() {
		return "Project [id=" + id + ", prname=" + prname + ", desc1=" + desc1 + ", code=" + code + ", startDate="
				+ startDate + ", endDate=" + endDate + ", address=" + address + ", insert_date=" + insert_date
				+ ", insert_by=" + insert_by + ", update_by=" + update_by + ", update_date=" + update_date
				+ ", teamhead=" + teamhead + ", filesid=" + filesid + ", projectteams=" + projectteams /*+ ", employee="
				+ employee*/ + "]";
	}
	
	

}
