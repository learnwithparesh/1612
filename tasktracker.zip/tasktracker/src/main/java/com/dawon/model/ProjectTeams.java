package com.dawon.model;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@Entity
@Table(name="projectteams")
public class ProjectTeams 
{
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	/*
	@Column(name="employeeid")
	private long employeeid;*/
	
	@ManyToOne(optional = true,fetch = FetchType.LAZY)
	@JsonIgnoreProperties("projectteams")
    private  Employee employee; 
	
	@ManyToOne(optional = true,fetch = FetchType.LAZY,cascade=CascadeType.ALL)
	@JsonIgnoreProperties("projectteams")
	private Project project;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	



	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	public ProjectTeams() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public ProjectTeams(long id, Employee employee, Project project) {
		super();
		this.id = id;
		this.employee = employee;
		this.project = project;
	}
	

	public ProjectTeams(Employee employee, Project project) {
		super();
		this.employee = employee;
		this.project = project;
	}
	/*
	 * @Override public String toString() { return "ProjectTeams [id=" + id +
	 * ", employee=" + employee + ", project=" + project + "]"; }
	 */

	

}
