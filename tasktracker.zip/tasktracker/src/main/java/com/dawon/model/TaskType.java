package com.dawon.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="task_type")
public class TaskType 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name="ttype")
	private String ttype;
	
	@Column(name="description")
	private String description;
	
	/*@OneToOne
	private Task task;
*/

	public TaskType() {
		super();
		// TODO Auto-generated constructor stub
	}


	public TaskType(long id, String ttype, String description/*, Task task*/) {
		super();
		this.id = id;
		this.ttype = ttype;
		this.description = description;
		//this.task = task;
	}


	public TaskType(String ttype, String description/*, Task task*/) {
		super();
		this.ttype = ttype;
		this.description = description;
		//this.task = task;
	}


	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	public String getTtype() {
		return ttype;
	}


	public void setTtype(String ttype) {
		this.ttype = ttype;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	/*public Task getTask() {
		return task;
	}


	public void setTask(Task task) {
		this.task = task;
	}*/


	@Override
	public String toString() {
		return "TaskType [id=" + id + ", ttype=" + ttype + ", description=" + description + /*", task=" + task +*/ "]";
	}
	
	
	

}
