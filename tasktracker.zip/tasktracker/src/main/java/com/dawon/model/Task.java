package com.dawon.model;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;
import org.springframework.data.annotation.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@Entity
@Table(name="task")

/*@NamedStoredProcedureQueries({
	  @NamedStoredProcedureQuery(
	    name = "findByYearProcedure", 
	    procedureName = "taskdetails", 
	    resultClasses = {Task.class }, 
	    parameters = { 
	        @StoredProcedureParameter(
	          name = "p_year", 
	          type = Integer.class, 
	          mode = ParameterMode.IN) }) 
	})*/
public class Task 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	
	
	@Column(name = "tapal")
	private int tapal;
	
	@Column(name = "ttype")
	private Long ttype;
	
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
    @Temporal(TemporalType.TIMESTAMP)
	@CreationTimestamp
	@Column(name="start_date")
	private Date startDate;

    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	@Column(name="end_date")
	private Date endDate;
	
	@CreationTimestamp
	@Column(name="nextfinaldate")
	private Date nextfinaldate;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	@Column(name="final_date")
	private Date finaldate;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	@Column(name="complete_date")
	private Date completedate;
		
	@Column(name="status")
	private long status;
	
	@Column(name="insert_by")
	private String insertby;
	
	//@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")

	@Temporal(TemporalType.TIMESTAMP)
	@CreationTimestamp
	@Column(name="insert_date")
	private Date insertdate;
	
	@Column(name="update_by")
	private long updateby;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	@Temporal(TemporalType.TIMESTAMP)
	@CreationTimestamp
	@Column(name="update_date")
	private Date updatedate;
	
	@Column(name="tname")
	private String tname;	
	
	/* @Column(name="noticolor") */
	private String noticolor;
	
	/*@Column(name="task_type", nullable=true)
	private String task_type;*/
	
	/*@Column(name="assignto", nullable=true)
	private long assignto;*/
	
	@OneToOne
	private Employee assignto;
	
	@Column(name="color",nullable=true)
	private String color;
	
	@Column(name="caseno", nullable=true)
    private String caseno;
    
	@Temporal(TemporalType.TIMESTAMP)
	@CreationTimestamp
	@Column(name="casestartdate", nullable=true)
    private Date casestartdate;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	@Temporal(TemporalType.TIMESTAMP)
	@CreationTimestamp
	@Column(name="casesubmissiondate", nullable=true)
    private Date casesubmissiondate;
    
    @Column(name="casesubject", nullable=true)
    private String casesubject;
    
    @Column(name="curtnotification", nullable=true)
    private String curtnotification;
    
    @Column(name="inwordno", nullable=true)
    private String inwordno;
    
    @Column(name="property_id", nullable=true)
    private String propertyid;
    

	@Temporal(TemporalType.DATE) 
	@JsonFormat( pattern = "dd/MM/yyyy",timezone="IST")
    @Column(name="inworddate")
    private Date inworddate;
    
	@Temporal(TemporalType.DATE) 

	@JsonFormat(pattern = "dd/MM/yyyy",timezone="IST")
    @Column(name="letterdate")
    private Date letterdate;
    
    @Column(name="arrivedfrom")
    private String arrivedfrom;
    
    @Column(name="sender")
    private String sender;
    
    @Column(name="lettertype")
    private String lettertype;
    
    @Column(name="branch")
    private String branch;
    
    @Column(name="lettersubject")
    private String lettersubject;
    
    @Column(name="letterdeliverytype")
    private String letterdeliverytype;
    
	@Column(name = "filesid")
	private String filesid;
	@Column(name = "papchecked")
    private String papchecked;
	
	//@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	@Transient
	@JsonSerialize
	@JsonDeserialize
    private Date currentMaxDate;
	
	@OneToOne
	private Employee lastassign;
	
	/*
	 * @OneToOne private Villages villages;
	 * 
	 */
	/*@Lob
	@Column(name="files")
	private byte[] files;*/
	/*
	 @Column(name="files")
	 private MultipartFile[] files;*/
	
	//@JsonIgnore
	@OneToOne(optional = true)
	@JoinColumn(nullable=true)
    private Customer customer;
	
	@OneToOne
	private Project project;
	
	@OneToOne
	private TaskType tasktype;
	
	//@OneToOne(optional = true)
	//@JoinColumn(nullable = true)
	//private Property property;

	@ManyToOne(optional = true,fetch = FetchType.LAZY,cascade=CascadeType.ALL)
	@JsonIgnore
    private  Employee employee; 
	

	@OneToMany(mappedBy = "task", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JsonIgnoreProperties("task")
    private Set<Workflow> workflow;
	
	public Task() {
		super();
		// TODO Auto-generated constructor stub
	}

	


	public long getId() {
		return id;
	}




	public void setId(long id) {
		this.id = id;
	}




	public int getTapal() {
		return tapal;
	}




	public void setTapal(int tapal) {
		this.tapal = tapal;
	}






	public Long getTtype() {
		return ttype;
	}




	public void setTtype(Long ttype) {
		this.ttype = ttype;
	}




	public Date getStartDate() {
		return startDate;
	}




	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}




	public Date getEndDate() {
		return endDate;
	}




	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}




	public Date getNextfinaldate() {
		return nextfinaldate;
	}




	public void setNextfinaldate(Date nextfinaldate) {
		this.nextfinaldate = nextfinaldate;
	}




	public Date getFinaldate() {
		return finaldate;
	}




	public void setFinaldate(Date finaldate) {
		this.finaldate = finaldate;
	}




	public Date getCompletedate() {
		return completedate;
	}




	public void setCompletedate(Date completedate) {
		this.completedate = completedate;
	}




	public long getStatus() {
		return status;
	}




	public void setStatus(long status) {
		this.status = status;
	}




	public String getInsertby() {
		return insertby;
	}




	public void setInsertby(String insertby) {
		this.insertby = insertby;
	}




	public Date getInsertdate() {
		return insertdate;
	}




	public void setInsertdate(Date insertdate) {
		this.insertdate = insertdate;
	}




	public long getUpdateby() {
		return updateby;
	}




	public void setUpdateby(long updateby) {
		this.updateby = updateby;
	}




	public Date getUpdatedate() {
		return updatedate;
	}




	public void setUpdatedate(Date updatedate) {
		this.updatedate = updatedate;
	}




	public String getTname() {
		return tname;
	}




	public void setTname(String tname) {
		this.tname = tname;
	}




	public Employee getAssignto() {
		return assignto;
	}




	public void setAssignto(Employee assignto) {
		this.assignto = assignto;
	}




	public String getCaseno() {
		return caseno;
	}




	public void setCaseno(String caseno) {
		this.caseno = caseno;
	}




	public Date getCasestartdate() {
		return casestartdate;
	}




	public void setCasestartdate(Date casestartdate) {
		this.casestartdate = casestartdate;
	}




	public Date getCasesubmissiondate() {
		return casesubmissiondate;
	}




	public void setCasesubmissiondate(Date casesubmissiondate) {
		this.casesubmissiondate = casesubmissiondate;
	}




	public String getCasesubject() {
		return casesubject;
	}




	public void setCasesubject(String casesubject) {
		this.casesubject = casesubject;
	}




	public String getCurtnotification() {
		return curtnotification;
	}




	public void setCurtnotification(String curtnotification) {
		this.curtnotification = curtnotification;
	}




	public String getInwordno() {
		return inwordno;
	}




	public void setInwordno(String inwordno) {
		this.inwordno = inwordno;
	}




	public String getPropertyid() {
		return propertyid;
	}




	public void setPropertyid(String propertyid) {
		this.propertyid = propertyid;
	}




	public Date getInworddate() {
		return inworddate;
	}




	public void setInworddate(Date inworddate) {
		this.inworddate = inworddate;
	}




	public Date getLetterdate() {
		return letterdate;
	}




	public void setLetterdate(Date letterdate) {
		this.letterdate = letterdate;
	}




	public String getArrivedfrom() {
		return arrivedfrom;
	}




	public void setArrivedfrom(String arrivedfrom) {
		this.arrivedfrom = arrivedfrom;
	}




	public String getSender() {
		return sender;
	}




	public void setSender(String sender) {
		this.sender = sender;
	}




	public String getLettertype() {
		return lettertype;
	}




	public void setLettertype(String lettertype) {
		this.lettertype = lettertype;
	}




	public String getBranch() {
		return branch;
	}




	public void setBranch(String branch) {
		this.branch = branch;
	}




	public String getLettersubject() {
		return lettersubject;
	}




	public void setLettersubject(String lettersubject) {
		this.lettersubject = lettersubject;
	}




	public String getLetterdeliverytype() {
		return letterdeliverytype;
	}




	public void setLetterdeliverytype(String letterdeliverytype) {
		this.letterdeliverytype = letterdeliverytype;
	}




	public String getFilesid() {
		return filesid;
	}




	public void setFilesid(String filesid) {
		this.filesid = filesid;
	}




	public String getPapchecked() {
		return papchecked;
	}




	public void setPapchecked(String papchecked) {
		this.papchecked = papchecked;
	}




	public Date getCurrentMaxDate() {
		return currentMaxDate;
	}




	public void setCurrentMaxDate(Date currentMaxDate) {
		this.currentMaxDate = currentMaxDate;
	}




	public Employee getLastassign() {
		return lastassign;
	}




	public void setLastassign(Employee lastassign) {
		this.lastassign = lastassign;
	}




	public Customer getCustomer() {
		return customer;
	}




	public void setCustomer(Customer customer) {
		this.customer = customer;
	}




	public Project getProject() {
		return project;
	}




	public void setProject(Project project) {
		this.project = project;
	}




	public TaskType getTasktype() {
		return tasktype;
	}




	public void setTasktype(TaskType tasktype) {
		this.tasktype = tasktype;
	}




	public Employee getEmployee() {
		return employee;
	}




	public void setEmployee(Employee employee) {
		this.employee = employee;
	}




	public Set<Workflow> getWorkflow() {
		return workflow;
	}




	public void setWorkflow(Set<Workflow> workflow) {
		this.workflow = workflow;
	}




	public Task(long id, int tapal, Long ttype, Date startDate, Date endDate, Date nextfinaldate, Date final_date,
			Date complete_date, long status, String insert_by, Date insert_date, long update_by, Date update_date,
			String tname, String noticolor, Employee assignto, String color, String caseno, Date casestartdate,
			Date casesubmissiondate, String casesubject, String curtnotification, String inwordno, String property_id,
			Date inworddate, Date letterdate, String arrivedfrom, String sender, String lettertype, String branch,
			String lettersubject, String letterdeliverytype, String filesid, String papchecked, Employee lastassign,
			 Customer customer, Project project, TaskType tasktype, Employee employee,
			Set<Workflow> workflow) {
		super();
		this.id = id;
		this.tapal = tapal;
		this.ttype = ttype;
		this.startDate = startDate;
		this.endDate = endDate;
		this.nextfinaldate = nextfinaldate;
		this.finaldate = final_date;
		this.completedate = complete_date;
		this.status = status;
		this.insertby = insert_by;
		this.insertdate = insert_date;
		this.updateby = update_by;
		this.updatedate = update_date;
		this.tname = tname;
		this.noticolor = noticolor;
		this.assignto = assignto;
		this.color = color;
		this.caseno = caseno;
		this.casestartdate = casestartdate;
		this.casesubmissiondate = casesubmissiondate;
		this.casesubject = casesubject;
		this.curtnotification = curtnotification;
		this.inwordno = inwordno;
		this.propertyid = property_id;
		this.inworddate = inworddate;
		this.letterdate = letterdate;
		this.arrivedfrom = arrivedfrom;
		this.sender = sender;
		this.lettertype = lettertype;
		this.branch = branch;
		this.lettersubject = lettersubject;
		this.letterdeliverytype = letterdeliverytype;
		this.filesid = filesid;
		this.papchecked = papchecked;
		this.lastassign = lastassign;
		/* this.villages = villages; */
		this.customer = customer;
		this.project = project;
		this.tasktype = tasktype;
		this.employee = employee;
		this.workflow = workflow;
	}


	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public Task(long ttype,Date startDate, Date endDate, Date final_date, Date complete_date, long status, String insert_by,
			Date insert_date, long update_by, Date update_date, String tname,String noticolor, Employee assignto,
			String color, String caseno, Date casestartdate, Date casesubmissiondate, String casesubject,
			String curtnotification, String inwordno, Date inworddate, Date letterdate, String arrivedfrom,
			String sender, String lettertype, String branch, String lettersubject, String letterdeliverytype,	
			String filesid,String papchecked,Employee lastassign,Customer customer, Project project, TaskType tasktype, Employee employee,String property_id) {
		super();
		this.ttype = ttype;
		this.startDate = startDate;
		this.endDate = endDate;
		this.finaldate = final_date;
		this.completedate = complete_date;
		this.status = status;
		this.insertby = insert_by;
		this.insertdate = insert_date;
		this.updateby = update_by;
		this.updatedate = update_date;
		this.tname = tname;
		this.noticolor = noticolor;
	
		this.assignto = assignto;
		this.color = color;
		this.caseno = caseno;
		this.casestartdate = casestartdate;
		this.casesubmissiondate = casesubmissiondate;
		this.casesubject = casesubject;
		this.curtnotification = curtnotification;
		this.inwordno = inwordno;
		this.inworddate = inworddate;
		this.letterdate = letterdate;
		this.arrivedfrom = arrivedfrom;
		this.sender = sender;
		this.lettertype = lettertype;
		this.branch = branch;
		this.lettersubject = lettersubject;
		this.letterdeliverytype = letterdeliverytype;
		this.filesid = filesid;
		this.papchecked = papchecked;
		this.lastassign = lastassign;
		/* this.villages = villages; */
		this.customer = customer;
		this.project = project;
		this.tasktype = tasktype;
		this.employee = employee;
		this.propertyid = property_id;

	}
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public Task(long ttype,Date startDate, Date endDate, Date final_date, Date complete_date, long status, String insert_by,
			Date insert_date, long update_by, Date update_date, String tname,String noticolor, Employee assignto,
			String color, String caseno, Date casestartdate, Date casesubmissiondate, String casesubject,
			String curtnotification, String inwordno, Date inworddate, Date letterdate, String arrivedfrom,
			String sender, String lettertype, String branch, String lettersubject, String letterdeliverytype,
			String filesid, String papchecked, Employee lastassign, Project project, TaskType tasktype, Employee employee) {
		super();
		this.ttype = ttype;
		this.startDate = startDate;
		this.endDate = endDate;
		this.finaldate = final_date;
		this.completedate = complete_date;
		this.status = status;
		this.insertby = insert_by;
		this.insertdate = insert_date;
		this.updateby = update_by;
		this.updatedate = update_date;
		this.tname = tname;
		this.noticolor = noticolor;
		this.assignto = assignto;
		this.color = color;
		this.caseno = caseno;
		this.casestartdate = casestartdate;
		this.casesubmissiondate = casesubmissiondate;
		this.casesubject = casesubject;
		this.curtnotification = curtnotification;
		this.inwordno = inwordno;
		this.inworddate = inworddate;
		this.letterdate = letterdate;
		this.arrivedfrom = arrivedfrom;
		this.sender = sender;
		this.lettertype = lettertype;
		this.branch = branch;
		this.lettersubject = lettersubject;
		this.letterdeliverytype = letterdeliverytype;
		this.filesid = filesid;
		this.papchecked = papchecked;
		this.lastassign = lastassign;
		/* this.villages = villages; */
		this.project = project;
		this.tasktype = tasktype;
		this.employee = employee;
		
	}


	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}


	public String getNoticolor() {
		return noticolor;
	}


	public void setNoticolor(String noticolor) {
		this.noticolor = noticolor;
	}


	/*
	 * @Override public String toString() { return "Task [id=" + id + ", tapal=" +
	 * tapal + ", ttype=" + ttype + ", startDate=" + startDate + ", endDate=" +
	 * endDate + ", nextfinaldate=" + nextfinaldate + ", final_date=" + final_date +
	 * ", complete_date=" + complete_date + ", status=" + status + ", insert_by=" +
	 * insert_by + ", insert_date=" + insert_date + ", update_by=" + update_by +
	 * ", update_date=" + update_date + ", tname=" + tname + ", noticolor=" +
	 * noticolor + ", assignto=" + assignto + ", color=" + color + ", caseno=" +
	 * caseno + ", casestartdate=" + casestartdate + ", casesubmissiondate=" +
	 * casesubmissiondate + ", casesubject=" + casesubject + ", curtnotification=" +
	 * curtnotification + ", inwordno=" + inwordno + ", property_id=" + property_id
	 * + ", inworddate=" + inworddate + ", letterdate=" + letterdate +
	 * ", arrivedfrom=" + arrivedfrom + ", sender=" + sender + ", lettertype=" +
	 * lettertype + ", branch=" + branch + ", lettersubject=" + lettersubject +
	 * ", letterdeliverytype=" + letterdeliverytype + ", filesid=" + filesid +
	 * ", papchecked=" + papchecked + ", currentMaxDate=" + currentMaxDate +
	 * ", lastassign=" + lastassign + ", customer=" + customer + ", project=" +
	 * project + ", tasktype=" + tasktype + ", employee=" + employee + ", workflow="
	 * + workflow + "]"; }
	 */

}
