package com.dawon.model;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;
import org.springframework.data.annotation.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "workflow")
public class Workflow {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	/*
	 * @Column(name = "task_id") private long task_id;
	 */
	@OneToOne
	@JoinColumn(name = "task_from")
	private Employee task_from;

	@OneToOne
	@JoinColumn(name = "task_to")
	private Employee task_to;
	
	/*
	 * @OneToOne private Employee lastassign;
	 */

	@Column(name="noticode")
	private String noticode;

	@Temporal(TemporalType.TIMESTAMP)
	@CreationTimestamp
	@Column(name = "date_assigned",nullable = false, updatable = false)
	private Date date_assigned;

	@Column(name = "description")
	private String description;
	
	@CreationTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "update_date",nullable = false, updatable = false)
	private Date update_date;
	
	
	

	//@JsonIgnoreProperties("workflow")
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "task_id", nullable = false)
	private Task task;
	
	@Column(name = "nstatus")
	private String nstatus;
	
	@Column(name = "tstatus")
	private String tstatus;
	
	@Column(name = "title")
	private String title;
	
	
	
	public String getNoticode() {
		return noticode;
	}

	public void setNoticode(String noticode) {
		this.noticode = noticode;
	}

	public Workflow() {
		super();
		// TODO Auto-generated constructor stub
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Date getDate_assigned() {
		return date_assigned;
	}

	public void setDate_assigned(Date date_assigned) {
		this.date_assigned = date_assigned;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Task getTask() {
		return task;
	}

	public void setTask(Task task) {
		this.task = task;
	}

	public Employee getTask_from() {
		return task_from;
	}

	public void setTask_from(Employee task_from) {
		this.task_from = task_from;
	}

	public Employee getTask_to() {
		return task_to;
	}

	public void setTask_to(Employee task_to) {
		this.task_to = task_to;
	}
	
	

	/*
	 * public Employee getLastassign() { return lastassign; }
	 * 
	 * public void setLastassign(Employee lastassign) { this.lastassign =
	 * lastassign; }
	 */

	public String getNstatus() {
		return nstatus;
	}

	public void setNstatus(String nstatus) {
		this.nstatus = nstatus;
	}

	public String getTstatus() {
		return tstatus;
	}

	public void setTstatus(String tstatus) {
		this.tstatus = tstatus;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
	
	

	public Date getUpdate_date() {
		return update_date;
	}

	public void setUpdate_date(Date update_date) {
		this.update_date = update_date;
	}

	
	


	public Workflow(long id, Employee task_from, Employee task_to,  String noticode,
			Date date_assigned, String description, Date update_date, Task task, String nstatus, String tstatus,
			String title) {
		super();
		this.id = id;
		this.task_from = task_from;
		this.task_to = task_to;
		
		this.noticode = noticode;
		this.date_assigned = date_assigned;
		this.description = description;
		this.update_date = update_date;
		this.task = task;
		this.nstatus = nstatus;
		this.tstatus = tstatus;
		this.title = title;
	}

	public Workflow(Employee task_from, Employee task_to,String noticode, Date date_assigned, String description, Date update_date,
			Task task, String nstatus, String tstatus, String title) {
		super();
		this.task_from = task_from;
		this.task_to = task_to;
		
		this.noticode = noticode;
		this.date_assigned = date_assigned;
		this.description = description;
		this.update_date = update_date;
		this.task = task;
		this.nstatus = nstatus;
		this.tstatus = tstatus;
		this.title = title;
	}

	
	/*
	 * @Override public String toString() { return "Workflow [id=" + id +
	 * ", task_from=" + task_from + ", task_to=" + task_to + ", noticode=" +
	 * noticode + ", date_assigned=" + date_assigned + ", description=" +
	 * description + ", update_date=" + update_date + ", task=" + task +
	 * ", nstatus=" + nstatus + ", tstatus=" + tstatus + ", title=" + title + "]"; }
	 */
	


	

	
}
