package com.dawon.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dawon.model.Customer;
import com.dawon.model.Fileslist;

@Repository
public interface FileslistRepository extends JpaRepository<Fileslist,Long>
{
	Optional<Fileslist> findById(Long id);

}
