package com.dawon.repositories;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.transaction.annotation.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;

import com.dawon.model.Project;
import com.dawon.model.Task;

@Repository
public interface TaskRepository extends JpaRepository<Task,Long> 
{	
	@Modifying
	@Query(value = "update task set status = 0 where id = ?1", nativeQuery = true)
      void taskComplete(@RequestParam("id") Long id);

      Optional<Task> findById(Long id);
	
	/*@Modifying
	@Query(value = "SELECT * FROM task t WHERE t.id=?1", nativeQuery = true)
	List<Task> paptask(@RequestParam("id") Long id);
	
	*/
	
	@Modifying
	//@Query(value = "select distinct * from task t left join workflow w on t.id =w.task_id where t.assignto_id = ?1 or t.insert_by = ?1 or w.task_to = ?1 (NOW() + INTERVAL 7 DAY) group by t.id order by end_date", nativeQuery = true)
	//select distinct * from task t left join workflow w on t.id =w.task_id where (t.assignto_id = ?1 or t.insert_by = ?1 or w.task_to = ?1) and start_date < (NOW() + INTERVAL 8 DAY) group by t.id order by end_date
	@Query(value = "select distinct * from task t left join workflow w on t.id =w.task_id where (t.assignto_id = ?1 or t.insert_by = ?1 or w.task_to = ?1) and (start_date > (NOW() - INTERVAL 20 DAY)) group by t.id order by end_date", nativeQuery = true)
	List<Task> findByEmployee11(@RequestParam("id") long id);
	
	@Modifying
	@Query(value = "select distinct * from task where start_date > (NOW() - INTERVAL 20 DAY) order by end_date ", nativeQuery = true)
	List<Task> findByAllEmployee1();
	
	@Modifying
	@Query(value = "select * from task where project_id IN (SELECT id from project WHERE (teamhead_id = ?1)) and (start_date > (NOW() - INTERVAL 30 DAY))", nativeQuery = true)
	List<Task> findByprojectEmployee1(@RequestParam("id") long id);
	
	
	@Query(value = "select distinct * from task t left join workflow w on t.id =w.task_id where t.assignto_id = ?1 or t.insert_by = ?1 or w.task_to = ?1 group by t.id order by end_date", nativeQuery = true)
	List<Task> findByEmployee1(@RequestParam("id") long id);
	
	@Modifying
	@Query(value = "select distinct * from task order by end_date ", nativeQuery = true)
	List<Task> findByAllEmployee();
	
	
	@Modifying
	@Query(value = "select * from task where project_id IN (SELECT id from project WHERE (teamhead_id = ?1))", nativeQuery = true)
	List<Task> findByprojectEmployee(@RequestParam("id") long id);
	
	
	
	@Modifying
	@Query(value = "update task set nextfinaldate = ?1 where id = ?1", nativeQuery = true)
    void taskNextDate(@RequestParam("id") Long id);
	
	
	@Modifying
	@Query(value = "update task set end_date = ?1 where id = ?1", nativeQuery = true)
    void taskEndDate(@RequestParam("id") Long id);
	
	@Modifying
	@Query(value = "SELECT * FROM task WHERE start_date >= ?1  AND end <= ?2", nativeQuery = true)
	List<Task> findBydate(Date sdate,Date tdate );
	

	//@Query(value = "SELECT date_assigned,(SELECT count(task_from) from workflow where task_from = ?1 and (DATE_FORMAT(date_assigned, \"%M %d %Y\") = DATE_FORMAT(w.date_assigned, \"%M %d %Y\"))) as c1,(SELECT count(task_to) from workflow where task_to = ?1 and (DATE_FORMAT(date_assigned, \"%M %d %Y\") = DATE_FORMAT(w.date_assigned, \"%M %d %Y\"))) as c2 from workflow w where task_from = ?1 group by (SELECT DATE_FORMAT(date_assigned, \"%M %d %Y\"));" , nativeQuery = true)
	//@Query(value ="SELECT start_date,count(id),(SELECT p.prname from project p where project_id = p.id) as c2 from task where  status = '3' group by project_id", nativeQuery = true)
	//@Query(value="SELECT start_date,COALESCE((SELECT count(t1.id) from task t1 where t1.project_id = t.project_id and t1.`status` = '0'),0) as completed,COALESCE((SELECT count(t1.id) from task t1 where t1.project_id = t.project_id and t1.`status` != '0'),0) as inprogress ,COALESCE((SELECT count(t1.id) from task t1 where t1.project_id = t.project_id),0) as alls , (SELECT p.prname from project p where t.project_id = p.id) as project from task t  where start_date >= (DATE(NOW()) - INTERVAL 7 DAY) group by project_id", nativeQuery = true)

	@Query(value="SELECT start_date,COALESCE((SELECT count(t1.id) from task t1 where t1.project_id = t.project_id and t1.`status` = '0'),0) as completed,COALESCE((SELECT count(t1.id) from task t1 where t1.project_id = t.project_id and t1.`status` != '0'),0) as inprogress ,COALESCE((SELECT count(t1.id) from task t1 where t1.project_id = t.project_id),0) as alls , (SELECT p.prname from project p where t.project_id = p.id) as project from task t  group by project_id", nativeQuery = true)
	List<Object[]> findBycountfrom();
	
	@Query(value="SELECT start_date,COALESCE((SELECT count(t1.id) from task t1 where t1.project_id = t.project_id and t1.`status` = '0'),0) as completed,COALESCE((SELECT count(t1.id) from task t1 where t1.project_id = t.project_id and t1.`status` != '0'),0) as inprogress ,COALESCE((SELECT count(t1.id) from task t1 where t1.project_id = t.project_id),0) as alls , (SELECT p.prname from project p where t.project_id = p.id) as project from task t  where project_id IN (SELECT id from project WHERE teamhead_id = ?1)  group by project_id", nativeQuery = true)
	List<Object[]> findBycountprojecthead(@RequestParam("id") Long id);

	@Query(value="SELECT start_date,COALESCE((SELECT count(t1.id) from task t1 where t1.project_id = t.project_id and t1.`status` = '0'),0) as completed,COALESCE((SELECT count(t1.id) from task t1 where t1.project_id = t.project_id and t1.`status` != '0'),0) as inprogress ,COALESCE((SELECT count(t1.id) from task t1 where t1.project_id = t.project_id),0) as alls ,(SELECT p.prname from project p where t.project_id = p.id) as project from task t  where project_id IN (SELECT  project_id from projectteams WHERE employee_id = ?1)  group by project_id", nativeQuery = true)
	List<Object[]> findBycountteam(@RequestParam("id") Long id);
	
	
	
	
	 @Query(nativeQuery = true,value = "call taskdetails(?1, ?2)")  // call store procedure 
	 Task storedcalled(@RequestParam("id") Long id,@RequestParam("ids") Long ids);
	 
	 
	  @Transactional
	  @Procedure(procedureName = "taskdetails1")
	  int storedcalled1(@Param("id") Long id,@Param("ids") Long ids);
	//  int storedcalled1(@RequestParam("id") Long id,@RequestParam("ids") Long ids);
	 
	 
	 @Query(nativeQuery = true,value = "SELECT * FROM task Where end_date < (NOW() + INTERVAL 7 DAY) and  status != 0")
      List<Task>findenddate();
	 
	 
	 @Query(nativeQuery = true,value = "SELECT * FROM task Where end_date < (NOW() + INTERVAL 7 DAY) and  status != 0 AND project_id IN (SELECT id from project WHERE teamhead_id = ?1)")
	 List<Task>findenddate(@RequestParam("id") Long id);
	 
	 
	 
	 @Query(nativeQuery = true,value = "select distinct * from task t left join workflow w on t.id =w.task_id where t.assignto_id = ?1 or t.insert_by = ?1 or w.task_to = ?1 AND end_date < (NOW() + INTERVAL 3 DAY) and  status != 0 group by t.id order by end_date  ") 
	 List<Task>findenddatebyemp(@RequestParam("id") Long id);
	 
	 
	// call searching store procedure 	 
	 @Query(nativeQuery = true,value = "call searching(?1)")  
	 List<Task> searchstoredcalled(@RequestParam("text") String text);
	 
	 @Query(nativeQuery = true, value="SELECT assignto_id,lastassign_id,end_date FROM task WHERE id = ?1")
	 List<Object[]> findtaskbyid(@RequestParam("id") Long id);
	 
	 
	 @Query(nativeQuery = true,value = "SELECT * FROM task Where status = 0  AND  lastassign_id = ?1")
     List<Task>findRejectedtask(@RequestParam("id") Long id);
	 
	//tapal reports...................
	 List<Task> findByStartDateBetweenAndProjectIn(Date startDate, Date endDate, List<Project> project);
	 
	 @Query(nativeQuery = true,value = "\r\n" + 
	 		"select * from task t where (project_id IN  (SELECT id from project p WHERE (p.teamhead_id = ?1))) and ttype = 2 and ( DATE(start_date) BETWEEN ?2 and ?3)")
	 List<Task> findByStartDates(long id,Date startDate, Date endDate);
	// void refresh(Task t);
	 
	 @Query(nativeQuery = true,value = "\r\n" + 
		 		"select * from task t where (t.id IN (SELECT task_id FROM workflow WHERE (task_to = ?1)))  and ttype = 2 and (DATE(start_date) BETWEEN ?2 and ?3)")
		 List<Task> findByemployeeid(long id,Date startDate, Date endDate);
	 
	 @Query(nativeQuery = true,value = "select * from task  where (DATE(start_date) BETWEEN ?1 and ?2) and ttype = 2")
		 List<Task> findfordro(Date startDate, Date endDate);
	 
	 
	 
	 //for sandrabh details................
	 @Query(nativeQuery = true,value = "\r\n" + 
		 		"select * from task t where (project_id IN  (SELECT id from project p WHERE (p.teamhead_id = ?1))) and (ttype = 1) and ( DATE(start_date) BETWEEN ?2 and ?3)")
		 List<Task> findByStartDates1(long id,Date startDate, Date endDate);
		// void refresh(Task t);
		 
		 @Query(nativeQuery = true,value = "\r\n" + 
			 		"select * from task t where (t.id IN (SELECT task_id FROM workflow WHERE (task_to = ?1))) and (ttype = 1) and ( DATE(start_date) BETWEEN ?2 and ?3)")
			 List<Task> findByemployeeid1(long id,Date startDate, Date endDate);
		 
		 @Query(nativeQuery = true,value = "\r\n" + 
			 		"select * from task  where (DATE(start_date) BETWEEN ?1 and ?2) and (ttype = 1)")
		List<Task> findfordro1(Date startDate, Date endDate);
		 
		 
		 
		//for sandrabh details With max date................
		/*@Query(nativeQuery = true,value = "select * from task t right join workflow w ON t.id = w.task_id  where (t.ttype = 1) AND w.task_to = ?1 \r\n" + 
				"and ((select max(DATE(w1.date_assigned)) from workflow w1 where w1.task_id = t.id and w1.task_to = ?1)  BETWEEN ?1 and ?2)")
			 List<MyTask> findByStartDates2(long id,Date startDate, Date endDate);*/
			// void refresh(Task t);
		

    @Query(nativeQuery = true,value = "SELECT t.id,t.tname,t.start_date as startDate,t.end_date as endDate,t.status,t.ttype, w.date_assigned as date_assigned,(SELECT c.name from customer c WHERE c.id = t.customer_id) as cname,(SELECT tp.ttype FROM task_type tp WHERE tp.id = t.tasktype_id) as ttypename,(SELECT p.prname FROM project p WHERE p.id = t.project_id) as prname,(SELECT e.name FROM employee e WHERE e.id = w.task_to) as ename,(SELECT pr.propid FROM property pr WHERE pr.id = t.property_id) as propid FROM task t JOIN workflow w ON t.id = w.task_id where (t.ttype = 1) AND (w.task_to = ?1) and (DATE(w.date_assigned) = (select max(DATE(w1.date_assigned)) from workflow w1 where w1.task_id = t.id ))AND (DATE(start_date) BETWEEN ?2 and ?3)")
    List<MyTask> findByStartDates2(long id,Date startDate, Date endDate);
    
    
    @Query(nativeQuery = true,value = "SELECT t.id,t.tname,t.inwordno,t.start_date as startDate,t.end_date as endDate,(SELECT tt.ttype FROM task_type tt WHERE tt.id = t.lettertype) as lettertype,t.status,t.tapal,t.ttype,t.arrivedfrom,t.branch,t.inworddate,t.letterdate,t.lettersubject,t.letterdeliverytype,t.sender,w.date_assigned as date_assigned,(SELECT tp.ttype FROM task_type tp WHERE tp.id = t.tasktype_id) as ttypename,(SELECT p.prname FROM project p WHERE p.id = t.project_id) as prname,(SELECT e.name FROM employee e WHERE e.id = w.task_to) as ename FROM task t JOIN workflow w ON t.id = w.task_id where (t.ttype = 2) AND (w.task_to = ?1) and (DATE(w.date_assigned) = (select max(DATE(w1.date_assigned)) from workflow w1 where w1.task_id = t.id))AND (DATE(start_date) BETWEEN ?2 and ?3);")
    List<Tapaltask> findByTapal(long id,Date startDate, Date endDate);


	
    //for calendar display task.
    //for tashildar ANd employee
    @Query(nativeQuery = true,value = "select t.id,t.tname,t.ttype,t.tapal,t.start_date,t.status from task t WHERE t.assignto_id = ?1 OR lastassign_id = ?1")
    List<Object[]> findbyUser(long id);
    
    
   // @Query(nativeQuery = true,value = "SELECT t.id,t.tname,t.ttype,t.tapal,t.lettersubject,t.status,t.current_max_date as currentMaxDate,t.assignto_id as aid,t.lastassign_id lid,t.color,(SELECT DATE_ADD(DATE(max(w.date_assigned)),INTERVAL 1 DAY) FROM workflow w) as maxdate FROM task t")
    @Query(nativeQuery = true,value = "SELECT t.id,t.tname,t.ttype,t.tapal,t.lettersubject,(SELECT tt.ttype FROM task_type tt WHERE tt.id = t.lettertype) as lettertype,t.status,t.assignto_id as aid,t.lastassign_id lid,t.color,(SELECT (DATE(max(w.date_assigned))) FROM workflow w WHERE w.task_id = t.id) as maxdate FROM task t group by t.id ORDER BY t.id DESC LIMIT 100")
    List<CalenderTask> findbyrole();
    

  //  @Query(nativeQuery = true,value = "select t.id,t.tname,t.ttype,t.tapal,t.lettersubject,t.status,t.current_max_date as currentMaxDate,t.assignto_id as aid,t.lastassign_id lid,t.color,(SELECT (DATE(max(w.date_assigned))) FROM workflow w WHERE w.task_id = t.id) as maxdate from task t WHERE t.assignto_id = ?1 OR lastassign_id = ?1")
    @Query(nativeQuery = true,value = "select t.id,t.tname,t.ttype,t.tapal,t.lettersubject,(SELECT tt.ttype FROM task_type tt WHERE tt.id = t.lettertype) as lettertype,t.status,t.assignto_id as aid,t.lastassign_id lid,t.color,(SELECT (DATE(max(w.date_assigned))) FROM workflow w WHERE w.task_id = t.id AND w.task_to = ?1) as maxdate from task t JOIN workflow w ON w.task_id = t.id WHERE w.task_to = ?1 OR w.task_from = ?1 group by t.id ORDER BY t.id DESC LIMIT 100 ")
    List<CalenderTask> findbyUser1(long id);
    
    
    
}
