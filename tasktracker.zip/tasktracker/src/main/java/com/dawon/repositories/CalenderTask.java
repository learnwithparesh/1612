package com.dawon.repositories;

import java.util.Date;

public interface CalenderTask
{
	long getId();
	int getTapal();
	Long getTtype();
	//Date getStartDate();
	long getStatus();
	String getLettersubject();
	//String getInsertby();
	String getColor();
	String getTname();
	long getAid();
	long getLid();
	Date getMaxDate();
	
	
	

}
