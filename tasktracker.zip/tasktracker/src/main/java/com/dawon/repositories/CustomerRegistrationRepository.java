package com.dawon.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;

import com.dawon.model.Customer;
import com.dawon.model.Task;


@Repository
public interface CustomerRegistrationRepository extends JpaRepository<Customer, Long> 
{
	Optional<Customer> findById(Long id);
	
	@Modifying
	@Query(value = "select * from customer where adhaarCard = ?1", nativeQuery = true)
	List<Customer> findByCustomer(String adhaar);
	
	List<Customer> findByAdhaarCard(String adhaar);
	
	/*
	@Modifying
	@Query(value = "update customer set name = ?1,gender=?1,bdate=?1,email=?1,contact_number=?1,adhaarCard=?1,c_address=?1,p_address=?1,file=?1 where id = ?1", nativeQuery = true)
    void customerupdate(@RequestParam("id") Long id);*/
	
	/*@Modifying
	@Query(value = "SELECT *, (SELECT vill.villagename FROM villages vill WHERE vill.id = (SELECT pr.villages_id FROM property pr WHERE pr.customer_id = cust.id )) as villagename from customer cust WHERE cust.id=?1", nativeQuery = true)
	List<Customer> findBypap(Long id);*/
}
