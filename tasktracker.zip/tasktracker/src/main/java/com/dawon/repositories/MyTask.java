package com.dawon.repositories;

import java.util.Date;


public interface MyTask {
	long getId();
	long getTtype();
	 Date getendDate();
	 long getStatus();
	 Date getStartDate();
	 String getTname();
	 String getCname();
	 String getPrname();
	 String getPropid();
	 String getEname();
	 String getTtypename();
	 Date getDate_assigned();
	

	 
	 
}
