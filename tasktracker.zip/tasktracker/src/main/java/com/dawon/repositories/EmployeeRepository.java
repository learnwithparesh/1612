package com.dawon.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dawon.model.Employee;
import com.dawon.model.Task;
import com.dawon.model.User;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee,Long>
{
	Optional<Employee> findByEmailAndPassword(String email, String password);

	List<User> findByOrgid(int i);
	
	Optional<Employee> findById(Long id);
	
	


}
