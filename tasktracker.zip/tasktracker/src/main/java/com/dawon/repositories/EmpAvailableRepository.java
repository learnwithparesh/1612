package com.dawon.repositories;



import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.dawon.model.Empavailable;



@Repository
public interface EmpAvailableRepository extends JpaRepository<Empavailable, Long>
{
	//Optional<EmpAvailable> findById(Long id);
	
	List<Empavailable> findByLeavefrom(Date dates);
	
	
	
	@Modifying
	@Query(value = "SELECT e.id,MAX(e.leavefrom) AS leavefrom ,MAX(e.leaveto) as leaveto , e.meetingetime ,e.meetingstime,(SELECT emp.name FROM employee emp WHERE emp.id =  e.employee_id) as empName FROM empavailable e GROUP BY  e.employee_id", nativeQuery = true)
	List<AvailableEmpDisplay> findavailableemployee();
	
	
	
	
	
}
