package com.dawon.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.dawon.model.Employee;
import com.dawon.model.Project;

@Repository
public interface ProjectRepository extends JpaRepository<Project, Long> 
{

	/*
	@Modifying
	@Query(value = "select distinct * from project Where teamhead = ?1", nativeQuery = true)
	List<Project> findByEmployee1(long uid);*/
	
	Optional<Project> findById(Long id);
	
	@Query(value = "select count(prname) from project Where teamhead_id = ?1", nativeQuery = true)
	long findByEmployee1(long uid);
	
	List<Project> findByTeamhead(Employee employee);
	
	
	Project findByPrnameEquals(String prname);

}
