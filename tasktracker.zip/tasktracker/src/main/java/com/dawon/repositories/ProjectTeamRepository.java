package com.dawon.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.dawon.model.Project;
import com.dawon.model.ProjectTeams;

@Repository
public interface ProjectTeamRepository extends JpaRepository<ProjectTeams, Long> 
{
	
	/*@Modifying
	@Query(value = "select distinct * from projectteams Where  project_id = ?1", nativeQuery = true)
	List<ProjectTeams> findByProject(long id);*/
	
	

	/*@Query(value = "SELECT * , (SELECT e.name from employee e WHERE e.id = teamhead) as emp from project Where id = ?1", nativeQuery = true)
	List<Project> findByProject(long id);*/
}
