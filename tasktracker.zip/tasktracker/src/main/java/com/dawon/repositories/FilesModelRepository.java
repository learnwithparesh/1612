package com.dawon.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;

import com.dawon.model.FilesModel;


@Repository
public interface FilesModelRepository extends JpaRepository<FilesModel, Long>
{
	
	@Modifying
	@Query(value = "select distinct * from files WHERE task_id = ?1", nativeQuery = true)
	List<FilesModel> findbytaskid(long task_id);

	
	@Query(value = "select filename as c1,fileurl as c2, id as c3,filetype as c4 from files WHERE task_id = ?1", nativeQuery = true)
	List<Object[]> findbyObjects(long task_id);

}
