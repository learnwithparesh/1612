package com.dawon.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;

import com.dawon.model.Customer;
import com.dawon.model.Task;
import com.dawon.model.Workflow;

@Repository
public interface WorkflowRepository extends JpaRepository<Workflow, Long>
{
	
	Optional<Workflow> findById(Long id);
	

	
	@Modifying
	@Query(value = "update workflow set status = 0 where task_id = ?1 ORDER BY id DESC LIMIT 1", nativeQuery = true)
    void taskComplete(@RequestParam("id") Long id);
	
	
	@Modifying
	@Query(value = "update workflow set noticode = '1' where task_id = ?1", nativeQuery = true)
	Workflow updatecode(@RequestParam("id") Long id);
	
	
	@Modifying
	@Query(value = "select * from workflow where task_to = ?1 order by date_assigned DESC LIMIT 30", nativeQuery = true)
	List<Workflow> findByEmp(@RequestParam("id") long id);
	
	@Modifying
	@Query(value = "select * from workflow where task_id = ?1 order by date_assigned DESC LIMIT 30", nativeQuery = true)
	List<Workflow> findBytask(@RequestParam("id") long id);
	
	
	
	@Modifying
	//@Query(value = "SELECT count(task_from) as c1 ,count(task_to) as c2 from workflow where task_from = ?1 AND task_to = 1?", nativeQuery = true) 
	@Query(value = "SELECT distinct (SELECT count(task_from) from workflow where task_from = ?1 AND date_assigned >= (DATE(NOW()) - INTERVAL 7 DAY)) as c1,(SELECT count(task_to) from workflow where task_to = ?1 AND date_assigned >= (DATE(NOW()) - INTERVAL 7 DAY)) as c2 from workflow where task_from = ?1  and date_assigned >= (DATE(NOW()) - INTERVAL 7 DAY)", nativeQuery = true) 
	List<Object[]> findBycount(@RequestParam("taskfrom") Long taskfrom);
	
	//@Query(value = "SELECT date_assigned,(SELECT count(task_from) from workflow where task_from = ?1 and date_assigned >= (DATE(NOW()) - INTERVAL 7 DAY) and (DATE_FORMAT(date_assigned, \"%M %d %Y\")) = DATE_FORMAT(w.date_assigned,  \"%M %d %Y\")))  as c1,(SELECT count(task_to) from workflow where task_to = ?1 and date_assigned >= (DATE(NOW()) - INTERVAL 7 DAY) and (DATE_FORMAT(date_assigned,  \"%M %d %Y\")  = DATE_FORMAT(w.date_assigned, \"%M %d %Y\"))) as c2 from workflow w where task_from = ?1 AND date_assigned >= (DATE(NOW()) - INTERVAL 7 DAY)group by (SELECT DATE_FORMAT(date_assigned, \"%M %d %Y\")))" , nativeQuery = true) 

	//@Modifying
	//@Query(value = "SELECT date_assigned,(SELECT count(task_from) from workflow where task_from = ?1 and (DATE_FORMAT(date_assigned, \"%M %d %Y\") = DATE_FORMAT(w.date_assigned, \"%M %d %Y\"))) as c1,(SELECT count(task_to) from workflow where task_to = ?1 and (DATE_FORMAT(date_assigned, \"%M %d %Y\") = DATE_FORMAT(w.date_assigned, \"%M %d %Y\"))) as c2 from workflow w where task_from = ?1 group by (SELECT DATE_FORMAT(date_assigned, \"%M %d %Y\"));" , nativeQuery = true)
	/*@Query(value = "SELECT date_assigned,(SELECT count(task_from) from workflow where tstatus = 3 AND task_from = ?1 and date_assigned >= (DATE(NOW()) - INTERVAL 7 DAY) and (DATE_FORMAT(date_assigned, \"%M %d %Y\") = DATE_FORMAT(w.date_assigned, \"%M %d %Y\"))) as c1,(SELECT  count(task_to) from workflow where tstatus = 2 AND task_to = ?1 and date_assigned >= (DATE(NOW()) - INTERVAL 7 DAY) and (DATE_FORMAT(date_assigned,  \"%M %d %Y\")  = DATE_FORMAT(w.date_assigned, \"%M %d %Y\"))) as c2 from workflow w where task_from = ?1 AND date_assigned >= (DATE(NOW()) - INTERVAL 7 DAY)group by (SELECT DATE_FORMAT(date_assigned, \"%M %d %Y\"))" , nativeQuery = true) 
	List<Object[]> findBycountfrom(@RequestParam("taskfrom") Long taskfrom);*/
	

//SELECT date_assigned,(SELECT count(task_to) from workflow where (tstatus = 2 OR  tstatus = 3) AND task_to = 3 and date_assigned >= (DATE(NOW()) - INTERVAL 7 DAY) and (DATE_FORMAT(date_assigned, "%M %d %Y") = DATE_FORMAT(w.date_assigned, "%M %d %Y"))) as c1,(SELECT count(task_from) from workflow where tstatus = 3 AND task_from = 3 and date_assigned >= (DATE(NOW()) - INTERVAL 7 DAY)and (DATE_FORMAT(date_assigned,  "%M %d %Y")  = DATE_FORMAT(w.date_assigned, "%M %d %Y"))) as c2 from workflow w where date_assigned >= (DATE(NOW()) - INTERVAL 7 DAY)group by (SELECT DATE_FORMAT(date_assigned, "%M %d %Y"));
 
	@Query(value = "SELECT date_assigned,(SELECT count(task_to) from workflow where (tstatus = '2' OR  tstatus = '3') AND task_to = ?1 and date_assigned >= (DATE(NOW()) - INTERVAL 31 DAY) and (DATE_FORMAT(date_assigned, \"%M %d %Y\") = DATE_FORMAT(w.date_assigned, \"%M %d %Y\"))) as c1,(SELECT  count(task_from) from workflow WHERE (tstatus = '2' OR  tstatus = '3') AND task_from = ?1 and date_assigned >= (DATE(NOW()) - INTERVAL 31 DAY) and (DATE_FORMAT(date_assigned,  \"%M %d %Y\")  = DATE_FORMAT(w.date_assigned, \"%M %d %Y\"))) as c2 from workflow w where  date_assigned >= (DATE(NOW()) - INTERVAL 31 DAY)group by (SELECT DATE_FORMAT(date_assigned, \"%M %d %Y\"))" , nativeQuery = true) 
	List<Object[]> findBycountfrom(@RequestParam("taskfrom") Long taskfrom);
	
	
	
	//@Modifying
	@Query(value = "SELECT date_assigned,count(task_from) from workflow where task_from = ?1 AND", nativeQuery = true) 
	int findBycount1(Long taskfrom);
	
	//@Modifying
	@Query(value = "SELECT date_assigned,count(task_to) from workflow where task_to = ?1 AND", nativeQuery = true) 
	int findBycount2(Long task_to);
	
	
	//set color on deashboard calander if task assign to anyone then change the color
	
	/*
	 * @Modifying
	 * 
	 * @Query(value =
	 * "SELECT task_from as tf1,task_to as tf2, DATE(max(date_assigned)) as maxdates  FROM workflow  WHERE task_id = ?1 ORDER BY id DESC LIMIT 1"
	 * , nativeQuery = true) List<Object[]> findBylastassign(@RequestParam("id")
	 * long id);
	 */
	
	@Modifying
	@Query(value = "SELECT task_from as tf1,task_to as tf2, DATE_ADD(DATE(max(date_assigned)),INTERVAL 1 DAY)  FROM workflow  WHERE task_id = ?1 AND (DATE(date_assigned) = (select max(DATE(w1.date_assigned)) from workflow w1 where w1.task_id = ?1)) ORDER BY id DESC LIMIT 1", nativeQuery = true)
	List<Object[]> findBylastassign(@RequestParam("id") long id);
	
	@Modifying
	@Query(value = "select * from workflow where task_from = ?1 AND task_id = ?1", nativeQuery = true)
	List<Workflow> findBycurrentassign(@RequestParam("id") long id);

	//List<Workflow> findBytask();

}
