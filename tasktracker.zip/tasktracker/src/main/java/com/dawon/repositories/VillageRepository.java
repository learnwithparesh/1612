package com.dawon.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dawon.model.Villages;

public interface VillageRepository extends JpaRepository<Villages,Long>{

}
