package com.dawon.repositories;

import java.util.Date;

public interface AvailableEmpDisplay 
{
	long getId();
	Date getLeavefrom();
	Date getLeaveto();
	String getMeetingstime();
	String getMeetingetime();
	String getEmpName();

}
