myapp.controller("mySidebarController", function($scope, $http, $window,
	$localStorage, $filter, $compile, ServiceTaskTracker, $routeParams, $timeout,$translate,$rootScope) {
	
	
	
	/*var myEl = angular.element(document.querySelector('body'));
	myEl.removeClass('login');
	var myEl1 = angular.element(document.querySelector('.wrapper'));
	myEl1.removeClass('wrapper-login');

	var myEl3 = angular.element(document.querySelector('.main-header'));
	myEl3.css('display', 'block');

	var myEl4 = angular.element(document.querySelector('.sidebar'));
	myEl4.css('display', 'block');*/
	$scope.todaydate = new Date();

	
	$scope.roleid = $localStorage.roleid;
	
	/* $scope.dirOptions = {};
	  $scope.callDirFunc = function(){
	    $scope.dirOptions.directiveFunction(1);
	  };
	  $scope.callDirFunc(); 
	*/
	
	$rootScope.$on('childEmit', function(event, data) {
	 //  console.log(data + ' Inside Sibling one' + $scope.roleid);
	    $scope.roleid = data;
	    employeeList();
	 //   fetchNoti();
	  });
	  $rootScope.$on('siblingAndParent', function(event, data) {
	   // console.log('broadcast from child in parent' + $scope.roleid);
	 //   employeeList();
	 //   fetchNoti();
	  });
	
   function employeeList() {
			$scope.allempList = [];
			var url = 'getempList';
			var config = {
				headers : {
					'Content-Type' : 'application/json;charset=utf-8;'
				}
			}
			$http.get(url).then(function(response) {
				// $scope.getDivAvailable = true;
				// console.log('empList : '+JSON.stringify(response.data));
				$scope.allempList = response.data;
			
				//console.log(JSON.stringify($scope.empList));
			}, function error(response) {
				$scope.postResultMessage = "Error Status: " + response.statusText;
			});

		}
	//	employeeList();
		
/////////////////////// employee Available check //////////////////////////////////		
		   function empavailable1()
		   {
				  
				   $scope.todayempavailable = [];
				   
				   var url = '/showEmpAvailable';
					
					var config = {
			               headers : {
			                   'Content-Type': 'application/json;charset=utf-8;'
			               }
			       }
					$http.get(url).then(function (response) {
						//$scope.getDivAvailable = true;
						$scope.todayempavailable = response.data;
					// console.log("employee Availlable:" + JSON.stringify($scope.todayempavailable));
					}, function error(response) {
						$scope.postResultMessage = "Error Status: " +  response.statusText;
					});
				  
				  }
		   empavailable1();
		
	
//	 $scope.dirOptions = {};
//	  $scope.callDirFunc = function(){
//	    $scope.dirOptions.directiveFunction();
//	  };
//	  
//	  $scope.callDirFunc();

});
