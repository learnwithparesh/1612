myapp.controller("search1Controller",function($scope, $http, $window,
		$localStorage, $filter, $compile, ServiceTaskTracker, $routeParams,
		$timeout, $translate, $rootScope) {

	$scope.uid = $localStorage.message;
	$scope.roleid = $localStorage.roleid;
   $scope.startd ="";
   $scope.endd="";
   $scope.ttype=''; 
	
	//for pagination
   $(document).ready(function () {
	   $('#dtBasicExample').DataTable();
	   $('.dataTables_length').addClass('bs-select');
	 });
 ///////////////////////////////////////////////////////////////////////////////  
   $scope.test = " ";

     $scope.tasklist = []; 
         $scope.searching = function()
        	   {
        		 console.log($scope.test);
        		 
        		
        		var url = '/showsearchresult/'+ $scope.test;
        		var config = {
        			headers : {
        				'Content-Type' : 'application/json;charset=utf-8;'
        			}
        		}
        		$http.get(url).then(function(response) {
        			$scope.tasklist = response.data;
        		
        		}, function error(response) {
        			$scope.postResultMessage = "Error Status: " + response.statusText;
        		});
        	};
        	//fetchtask();
            	    
            //$window.location.href = '#!searching/'+ resultSet;
       
         //for pagination
         $scope.viewby = 10;
         $scope.totalItems =  $scope.tasklist.length;
         $scope.currentPage = 4;
         $scope.itemsPerPage = $scope.viewby;
         $scope.maxSize = 5; //Number of pager buttons to show

         $scope.setPage = function (pageNo) {
           $scope.currentPage = pageNo;
         };

         $scope.pageChanged = function() {
           console.log('Page changed to: ' + $scope.currentPage);
         };

       $scope.setItemsPerPage = function(num) {
         $scope.itemsPerPage = num;
         $scope.currentPage = 1; //reset to first page
       }
        	
      /////////////////////// pagination end////////////////////  	
        	
        	
        	//in body controller
        	$scope.clickview = function(nid) {
        		//alert("hi"+nid);
        		//	$scope.getEvents();		
        		
        		$rootScope.$emit('upempmodel', nid);
        		//$scope.clickUpload(nid);		
        	}

        	 
        	 $scope.printtask = function()
        	 { 
        		 //alert("hello");
        	 $window.location.href = '#!printdetails';
        	 }

        })
