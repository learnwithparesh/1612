myapp.controller("addpropertyController",function($scope, $http, $window,$localStorage, $route, $routeParams, ServiceTaskTracker) 
{

	var myEl = angular.element( document.querySelector( 'body' ) );
	myEl.removeClass('login');
	var myEl1 = angular.element( document.querySelector( '.wrapper' ) );
	myEl1.removeClass('wrapper-login');
	
	var myEl3 = angular.element( document.querySelector( '.main-header' ) );
	myEl3.css('display','block');

	var myEl4 = angular.element( document.querySelector( '.sidebar' ) );
	myEl4.css('display','block');
	
	  $scope.dates = $routeParams.dates;
	  $scope.uid = $localStorage.message;
		$scope.customer_id=$routeParams.ids;
		
		 $scope.property = {
				 propid:"",
					pname:"",
					description:"",
					village:"",
					courtcaseno: "",
					address: "",
					address:"",
					courtstatus:"",
					cort_case: "",
					court_status:"",
					nexthearing: "",
					otherowner: "",
					fileid:"",
					insertdate: $scope.dates,
				   
				  customer:{
					  id:0
					  
				  }
			  };

	var myEl = angular.element( document.querySelector( 'body' ) );
	myEl.removeClass('login');
	
	   $scope.success = false;
	   $scope.error = false;
	   
	   $http({
		    method: 'get', 
		    url: '/getallcustomers'
		}).then(function (response, status, headers, config) {		   
		    $scope.listcustomers = response.data;
		    $scope.customer_id = $scope.listcustomers[0].id;
		    
		  
		},function (error){
		    
		});	
	   
	   $scope.addProperty = function(){ 
		  
			  var url = "/addproperty/"+$scope.customer_id;
			  
			  console.log( $scope.customer_id +" ++>>>>$scope.customer_id");
				var config = {
		                headers : {
		                    'Content-Type': 'application/json;charset=utf-8;'
		                }
		        }
				var data = JSON.stringify($scope.property);
				$http.post(url, data, config).then(function (response) {
					$scope.success = true;
				    $scope.error = false;
				    $scope.successMessage = 'successful';
				    console.log('done');
				    contMSG('Success', 'Property Added Successfully', 'fa fa-check','success','right');

				}, function (response) {
					contMSG('Error', 'Some Error Occured. Try Again..!', 'fa fa-remove','danger','center');
				});		
				
		  }
	 //Success msg
		function contMSG(title, msg, icon,state,align) {
			var placementFrom = 'top';
			var placementAlign = align;
			var state = state;
			var content = {};
			content.message = msg;
			content.title = title;
			content.url = '#';
			content.icon = icon;
			$.notify(content, {
				type : state,
				placement : {
					from : placementFrom,
					align : placementAlign
				},
				time : 1000,
				delay : 2000,
			});
		}
	  
});