myapp.controller("indexController", function($scope, $http, $window,
		$localStorage, $filter, $compile, ServiceTaskTracker, $routeParams,
		$timeout, $translate, $rootScope) {

	/*var myEl = angular.element(document.querySelector('body'));
	myEl.removeClass('login');
	var myEl1 = angular.element(document.querySelector('.wrapper'));
	myEl1.removeClass('wrapper-login');

	var myEl3 = angular.element(document.querySelector('.main-header'));
	myEl3.css('display', 'block');

	var myEl4 = angular.element(document.querySelector('.sidebar'));
	myEl4.css('display', 'block');
	
	 */
	$scope.uid = $localStorage.message;
	$scope.roleid = $localStorage.roleid;
	
	$scope.todaydate = new Date();

	/* $scope.dirOptions = {};
	  $scope.callDirFunc = function(){
	    $scope.dirOptions.directiveFunction(1);
	  };
	  $scope.callDirFunc(); 
	 */
	
	//searching droupdawon
	  $("#selUser").select2();
	  
	  



	function alltaskdetails() {
		$scope.alltask = [];
		//$scope.fetchNoti = [];
		var url = 'showtaskdetails';
		var config = {
			headers : {
				'Content-Type' : 'application/json;charset=utf-8;'
			}
		}
		$http.get(url).then(function(response) {

			$scope.alltask = response.data;
			
			//console.log(JSON.stringify(response.data) +"tasklist ");
		}, function error(response) {
			$scope.postResultMessage = "Error Status: " + response.statusText;
		});

	}
	
	if($scope.uid != null && $scope.uid != '')
	{
	//gettask by userid and roleid
		$http({
			method : 'get',
			url : "getlisttask/" + $scope.uid + "/" + $scope.roleid

		}).then(function(response, status, headers, config) {
			// console.log("ui "+ $scope.uid+"roleid"+$scope.roleid);
			$scope.taskEvents = response.data;
			
			//console.log(JSON.stringify(response.data));
			//$scope.task_id = $scope.taskEvents[0].id; 
		}, function(error) {
		});
		alltaskdetails();
	}

	// jQuery
	$('.dropdown-menu').find('input').click(function(e) {
		e.stopPropagation();
	});

	$scope.clickNoti = function(nid) {
		//alert("hi"+nid);
		//	$scope.getEvents();		
		$rootScope.$emit('upempmodel', nid);
		//$scope.clickUpload(nid);		
	}
	

	$scope.selectitems = function() {
		//	$scope.getEvents();		
		//alert("hihi"+$scope.searchtextid45);
		$rootScope.$emit('selectSearchEmit1', $scope.searchtextid45);
		//$scope.clickUpload(nid);		
	}

	$rootScope.$on('childEmit', function(event, data) {
		//  console.log(data + ' Inside Sibling one');

		fetchNoti();
	});
	$rootScope.$on('siblingAndParent', function(event, data) {
		// console.log('broadcast from child in parent' + $scope.roleid);
		fetchNoti();
	});
	$scope.noticode1 ='';
	$scope.fetchNoti = [];
	function fetchNoti() {
		console.log("hi in fetch noti"+ $localStorage.message);
		$scope.notiCount = 0;
		//$scope.fetchNoti = [];
		var url = '/getnoti/' + $localStorage.message;
		var config = {
			headers : {
				'Content-Type' : 'application/json;charset=utf-8;'
			}
		}
		$http.get(url).then(function(response) {
			//alert("hi");
			$scope.fetchNoti = response.data;
			
			//get notification count
			//console.log("lenght:"+response.data.length);
			$scope.notiCount = response.data.length;
			$scope.noticode1= response.data.noticode;
			
			
			
			//$scope.noticode1 = $scope.fetchNoti[0].noticode;
		//console.log(JSON.stringify($scope.fetchNoti) +"Notification ");
			//console.log("$scope.noticode1:: "+$scope.noticode1 +"$scope.noticode::" +$scope.noticode);
			/*angular.forEach(response.data, function() {
				
			});*/

			//console.log(JSON.stringify(response.data) +"Notification ");
		}, function error(response) {
			$scope.postResultMessage = "Error Status: " + response.statusText;
		});
	}

	
	if($scope.uid != null && $scope.uid != '')
	{
		fetchNoti();
	}
		

	//
	$scope.employee = {
		password : '',
		email : '',
		name : '',
		contactnumber : '',
		gender : '',
		paddress : '',
		posts : '',
		caddress : '',
		bdate : ''
	}

	$scope.editableForms = function() {
		//$scope.uid
		if(!$scope.uid)
		{
			if(sessionStorage.getItem('uid'))
			{
				$scope.uid = sessionStorage.getItem('uid');
				console.log("session"+$scope.uid);
				$rootScope.$emit('editformemit', $scope.uid);
			}
			
		}
		else
		{
			console.log("edit"+$scope.uid);
			$rootScope.$emit('editformemit', $scope.uid);
		}
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////
	$scope.fetchMessg= [];
	function fetchMessage() {
		
		$scope.messgCount = 0;
		//$scope.fetchNoti = [];
		console.log(sessionStorage.getItem('uid') +"uid " +sessionStorage.getItem('rid')+"rid");
		
		var url = '/enddatetask/' + sessionStorage.getItem('uid') + "/" + sessionStorage.getItem('rid')
		var config = {
			headers : {
				'Content-Type' : 'application/json;charset=utf-8;'
			}
		}
		$http.get(url).then(function(response) {
			//alert("hi");
			$scope.fetchMessg = response.data;
			//get notification count
			//console.log("lenght:"+response.data.length);
			$scope.messgCount = response.data.length;
			/*angular.forEach(response.data, function() {
				
			});*/

//     	console.log("message:"+JSON.stringify($scope.fetchMessg) +"Notification ");
		}, function error(response) {
			$scope.postResultMessage = "Error Status: " + response.statusText;
		});
	}

	
	
	
	//find rejected task........
	function rejecttasklist()
	{
		var url = '/rejectedtask/' + sessionStorage.getItem('uid') 
		var config = {
			headers : {
				'Content-Type' : 'application/json;charset=utf-8;'
			}
		}
		$http.get(url).then(function(response) {
			//alert("hi");
			$scope.rejecttasklist = response.data;
		
			$scope.listCount = response.data.length;
			$scope.status =  response.data.status;
			
		}, function error(response) {
			$scope.postResultMessage = "Error Status: " + response.statusText;
		});
	}
	if($scope.uid != null && $scope.uid != '')
	{
	fetchMessage();
	rejecttasklist();
	}
	//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	$scope.searchdetails={};
	function searchable() {

		var url = 'showtaskdetails';
		var config = {
			headers : {
				'Content-Type' : 'application/json;charset=utf-8;'
			}
		}
		$http.get(url).then(function(response) {
			
			$scope.searchlist = response.data;
			//console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+JSON.stringify($scope.searchlist));
			$scope.searchdetails = response.data;
			//console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+JSON.stringify(response.data));
		}, function error(response) {
			$scope.postResultMessage = "Error Status: " + response.statusText;
		});
	}
	if($scope.uid != null && $scope.uid != '')
	{
	searchable();
	}
	
	 $scope.complete=function(){
			console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+JSON.stringify($scope.searchdetails));

		    $( "#tags" ).autocomplete({
		      source: $scope.searchdetails
		    });
		    } 
	 
	
	 
	/* $scope.printtask = function() {
		 alert("hello");
			$rootScope.$emit('print', $scope.uid);
		}
	  */
	 
	 $scope.printtask = function()
	 { 
		// alert("hello");
		  $window.location.href = '#!printdetails';
	 }
	 
	 

	
	
});
