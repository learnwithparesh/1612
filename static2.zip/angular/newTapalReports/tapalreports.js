myapp.controller("tapalreportsnew",function($scope, $http, $window,$localStorage, $filter,$rootScope,$compile,$routeParams,ServiceTaskTracker, $routeParams, DTOptionsBuilder, DTColumnBuilder,DTColumnDefBuilder ) {
	

	var myEl = angular.element( document.querySelector( 'body' ) );
	myEl.removeClass('login');
	var myEl1 = angular.element( document.querySelector( '.wrapper' ) );
	myEl1.removeClass('wrapper-login');
	
	var myEl3 = angular.element( document.querySelector( '.main-header' ) );
	myEl3.css('display','block');

	var myEl4 = angular.element( document.querySelector( '.sidebar' ) );
	myEl4.css('display','block');
	$scope.uid = $localStorage.message;
	$scope.roleid =$localStorage.roleid;
   $scope.startd ="";
   $scope.endd="";
   var date = new Date(), y = date.getFullYear(), m = date.getMonth();
   var firstDay = new Date(y, m, 1);
   var lastDay = new Date(y, m + 1, 0);

/*   firstDay = moment(firstDay).format('dd/mm/yyyy');
   lastDay = moment(lastDay).format('dd/mm/yyyy');*/
   
     $scope.date3 = firstDay;
       $scope.date4 = lastDay;
    	$scope.tasklist = [];
	 console.log("$scope.date3"+$scope.date3);
	   console.log("$scope.date4"+$scope.date4);

	/* $scope.date3 = "07/07/2019";
	 $scope.date4 = "12/07/2019";
	*/
	$scope.test = function()
	{
		//alert($("#start").val() + ":" +$("#end").val());
		$scope.date3 = $("#start").val().formate(dd/mm/yyyy);
		$scope.date4 = $("#end1").val().formate(dd/mm/yyyy);
		console.log($scope.date3 +" " +$scope.date3);
	}
	$scope.fetchtaskg = function()
	{
		//alert("hi");
		//$scope.tasklist = [];
		var url = "tapalreports/" + $scope.uid + "/" + $scope.roleid;
		var config = {
			headers : {
				'Content-Type' : 'application/json;charset=utf-8;'
			}
		}
		
		var data = JSON.stringify($scope.task);
		$http.post(url, data, config).then(function(response) {
			$scope.tasklist = response.data;
		console.log("$scope.tasklist tapal: "+JSON.stringify(response.data));
			
			
		}, function error(response) {
			$scope.postResultMessage = "Error Status: " + response.statusText;
		});
	};
	//fetchtaskg();
	
	
	$scope.vm = {};
	$scope.vm.dtInstance = {};   
	$scope.vm.dtColumnDefs = [DTColumnDefBuilder.newColumnDef(2).notSortable()];
	$scope.vm.dtOptions = DTOptionsBuilder.newOptions()
					  .withOption('paging', true)
					  .withOption('searching', true)
					  .withOption('info', true)
					   .withDOM('Bfrtip')/*Bfrtip*/
					  .withColumnFilter({				
						  aoColumns: [{
				                type: 'number'
				            }, {
				                type: 'text',
				                bRegex: true,
				                bSmart: true
				            },
				            {
				            	type: 'select',
				            	bRegex: false,
				            	values: ['पर्यायी जमीन', 'भूखंड वाटप', 'प्रकल्प दाखला', 'इतर अधिकारामध्ये शेरा कमी करणे','इतर','लोकशाही दिन संदर्भ','शासन संदर्भ','लक्षवेधी व कपात सुचना संदर्भ','न्यायालयीन संदर्भ',
				            		 'तारांकित प्रश्‍न','अतारांकित प्रश्‍न','लोकायुक्‍त संदर्भ','उपलोकायुक्त संदर्भ','जिल्हाधिकारी संदर्भ','अर्ध शासन,आयुक्त संदर्भ','अर्धशासकीय संदर्भ','आमदार संदर्भ','खासदार संदर्भ','आयुक्त संदर्भ',
				            		 'मंत्री संदर्भ','पालकमंत्री संदर्भ','इतर संदर्भ']
				            },
				           
				          {
				            type: 'select',
			                bRegex: false,
			                values: 
                           	 ['पानशेत ','चासकामान ',
                           		 'वीर बाजी पासलकर प्रकल्प ',
                           		'थेटेवाडी', 'आस्थापना ', 
                           		'प्रशासन ',
                           		'वडीवले',
                           		'पवना',
                           		'वीर',
                           		'गुंजवणी',
                           		'मलवंडी ठुले',
                           		'निरा देवधर',
                           		'आंध्र',
                           		'नाझरे',
                           		'टाटा धरण',
                           		'अभिलेख कक्ष',
                           		 'भामा आसखेड',
                           		'कुकडी',
                           		'बोपगाव रायता',
                           		'कासरसाई',
                           		'आरळा कलमोडी',
                           		'डिंभे',
                           		'जाधववाडी',
                           		'आवक जावक',
                           		'टेमघर',
                           		'दाखले'
                           		]

			            },
			            {
			                type: 'text',
			                bRegex: true,
			                bSmart: true
			            },
			            {
			                type: 'text',
			                bRegex: true,
			                bSmart: true
			            },
				            {
				                type: 'text',
				                bRegex: true,
				                bSmart: true
				            },
				            {
				                type: 'text',
				                bRegex: true,
				                bSmart: true
				            },
				            {
				                type: 'text',
				                bRegex: true,
				                bSmart: true
				            },
				            {
				                type: 'text',
				                bRegex: true,
				                bSmart: true
				            },
				            {
				                type: 'text',
				                bRegex: true,
				                bSmart: true
				            },
				            {
				                type: 'text',
				                bRegex: true,
				                bSmart: true
				            },
				            {
				                type: 'text',
				                bRegex: true,
				                bSmart: true
				            },
				            {
				                type: 'text',
				                bRegex: true,
				                bSmart: true
				            },
				              {
				            	type: 'select',
				                bRegex: false,
				                values: ['Complete', 'reject', 'assign', 'pending']
				            },
				            {
				                type: 'text',
				                bRegex: true,
				                bSmart: true
				            },
				            
				            ],
			           	
        })
					   .withButtons([
            /*'columnsToggle',*/
            'colvis',
            'copy',
            'print',
           /* {
            	orientation: 'landscape'
            },*/
            'excel',
           /* {
                text: 'Some button',
                key: '1',
                action: function (e, dt, node, config) {
                    alert('Button activated');
                }
            }*/
        ]);
	


	$scope.openmodel = function(nid)
	{
		$rootScope.$emit('upempmodel', nid);
		
	//	$("#notification").modal("show");
	}
	
	  
	$('.datepicker-default').datepicker();
});