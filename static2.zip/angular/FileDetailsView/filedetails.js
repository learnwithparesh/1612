myapp.controller("filesdetailsctrl", function($scope, $http, $window, $route,
		$localStorage, $filter, $compile, ServiceTaskTracker, $routeParams,
		$timeout, $translate, $rootScope) {

	var myEl = angular.element(document.querySelector('body'));
	myEl.removeClass('login');
	var myEl1 = angular.element(document.querySelector('.wrapper'));
	myEl1.removeClass('wrapper-login');

	var myEl3 = angular.element(document.querySelector('.main-header'));
	myEl3.css('display', 'block');

	var myEl4 = angular.element(document.querySelector('.sidebar'));
	myEl4.css('display', 'block');

	$rootScope.$emit('childEmit', $localStorage.roleid);
	$rootScope.$broadcast('siblingAndParent');

	//task details for edit...
	$scope.files1 = [ {
		id : 0,
		filename : '',
		filesize : '',
		filetype : '',
		fileurl : '',
		filelist : {
			id : 0
		},
		task : {
			id : 0,

			tasktype : {
				id : 0
			},

		},

	//	employee:{}
	} ];

	/* $scope.pdf = {
		        src: 'example.pdf',
		    };*/
	//https://localhost:9021/
	// $scope.pdfsrc = "/rest/files/143";
	$scope.taskwithfile = function() {
		//console.log("task id : " + sessionStorage.getItem('filetaskid'));
		///  $scope.files1 = [];

		var url = 'getfilesdetails/' + sessionStorage.getItem('filetaskid');

		var config = {
			headers : {
				'Content-Type' : 'application/json;charset=utf-8;'
			}
		}
		$http.get(url).then(function(response) {
			// $scope.getDivAvailable = true;

			$scope.files1 = response.data;
			
			/* angular.forEach($scope.files1, function (value, key) { 
	                $scope.names.push(value.name); 
	            });   */
		
		//	console.log(JSON.stringify($scope.files1));

		}, function error(response) {
			$scope.postResultMessage = "Error Status: " + response.statusText;
		});

	}
	$scope.taskwithfile();

	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Get all file from file manager

	$scope.allFiles = [];
	$scope.getAllFiles = function() {

		// REST URL:
		//var url = "/download/"+ sessionStorage.getItem('filetaskid');
	     var url = "/rest/getAllFiles/"+ sessionStorage.getItem('filetaskid');
	    
		$http.get(url).then(
		// Success
		function(response) {
		//	alert("OK");
			$scope.allFiles = response.data;
			
		
			});

		},
		// Error
		function(response) {
			//alert("Error: " + response.data);
		};

		//////////////// files previews /////////////////////////////////////
		
		$scope.filevalue='';
		$scope.getfilepreview = function(id,event,filetype) {
			event.preventDefault();
			//alert("test"+id);
            console.log("filetype" +filetype);
			//$scope.pdfsrc = "/rest/files/"+id;
            if(filetype =='application/pdf')
            {
            $scope.filevalue = '1';
			$scope.pdfsrc1 = "/web/viewer.html?file=/rest/files/"+id;
			}
            else 
            {
            	$scope.filevalue = '2';
            	console.log("in else block");
            	$scope.pdfsrc1 = "/rest/files/"+id;
            }
			//$scope.pdfsrc1 = "/rest/files/"+id;
					     
			//
					};
		
	
	
});