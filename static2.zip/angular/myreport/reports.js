myapp.controller("myreportsController",function($scope, $http, $window,$localStorage, $filter,$compile,$routeParams,ServiceTaskTracker, $routeParams, DTOptionsBuilder, DTColumnBuilder,DTColumnDefBuilder ) {
	

	var myEl = angular.element( document.querySelector( 'body' ) );
	myEl.removeClass('login');
	var myEl1 = angular.element( document.querySelector( '.wrapper' ) );
	myEl1.removeClass('wrapper-login');
	
	var myEl3 = angular.element( document.querySelector( '.main-header' ) );
	myEl3.css('display','block');

	var myEl4 = angular.element( document.querySelector( '.sidebar' ) );
	myEl4.css('display','block');
	$scope.uid = $localStorage.message;
	
   $scope.startd ="";
   $scope.endd="";
   var date = new Date(), y = date.getFullYear(), m = date.getMonth();
   var firstDay = new Date(y, m, 1);
   var lastDay = new Date(y, m + 1, 0);

/*   firstDay = moment(firstDay).format('dd/mm/yyyy');
   lastDay = moment(lastDay).format('dd/mm/yyyy');*/
   
     $scope.date3 = firstDay;
   $scope.date4 = lastDay;
	$scope.tasklist = [];
	// console.log("$scope.date3"+$scope.date3);
	//   console.log("$scope.date4"+$scope.date4);

	/* $scope.date3 = "07/07/2019";
	 $scope.date4 = "12/07/2019";
	*/
	$scope.test = function()
	{
		//alert($("#start").val() + ":" +$("#end").val());
		$scope.date3 = $("#start").val().formate(dd/mm/yyyy);
		$scope.date4 = $("#end1").val().formate(dd/mm/yyyy);
	//s	console.log($scope.date3 +" " +$scope.date3);
	}
	function fetchtaskg()
	{
		//$scope.tasklist = [];
		var url = "showtask4/" + $scope.uid + "/" + $scope.roleid;
		var config = {
			headers : {
				'Content-Type' : 'application/json;charset=utf-8;'
			}
		}
		$http.get(url).then(function(response) {
			$scope.tasklist = response.data;
			//console.log("$scope.tasklist"+JSON.stringify($scope.tasklist));
			//$scope.startDate = 
			//console.log("hi"+JSON.stringify($scope.tasklist));
			// $scope.startDate = $scope.tasklist[0].startDate;
			// $scope.endDate = $scope.tasklist[0].endDate;
			// console.log( $scope.startDate +" $scope.startDate");
		}, function error(response) {
			$scope.postResultMessage = "Error Status: " + response.statusText;
		});
	}
	fetchtaskg();
	
	
	
	$scope.vm = {};
	$scope.vm.dtInstance = {};   
	$scope.vm.dtColumnDefs = [DTColumnDefBuilder.newColumnDef(2).notSortable()];
	$scope.vm.dtOptions = DTOptionsBuilder.newOptions()
					  .withOption('paging', true)
					  .withOption('searching', true)
					  .withOption('info', true)
					   .withDOM('Bfrtip')/*Bfrtip*/
					  .withColumnFilter({		
            aoColumns: [{
                type: 'number'
            }, {
                type: 'text',
                bRegex: true,
                bSmart: true
            },
            {
                type: 'text',
                bRegex: true,
                bSmart: true
            },
            {
                type: 'text',
                bRegex: true,
                bSmart: true
            },
            {
                type: 'text',
                bRegex: true,
                bSmart: true
            },
            {
                type: 'text',
                bRegex: true,
                bSmart: true
            },
            {
                type: 'text',
                bRegex: true,
                bSmart: true
            },
            {
                type: 'text',
                bRegex: true,
                bSmart: true
            },
            {
                type: 'text',
                bRegex: true,
                bSmart: true
            },
            {
                type: 'select',
                bRegex: false,
                values: ['Complete', 'reject', 'assign', 'pending']
            }]
        })
					
            /*'columnsToggle',*/
						   .withButtons([
					            /*'columnsToggle',*/
					            'colvis',
					            'copy',
					            'print',
					            'excel',
					  /*          {
					                text: 'Some button',
					                key: '1',
					                action: function (e, dt, node, config) {
					                    alert('Button activated');
					   }*/
		         //}
           
        ]);
	
	$scope.openmodel = function()
	{
		//alert("hello");
		$("#eventDetails").modal("show");
	}
	  
	$('.datepicker-default').datepicker();
});