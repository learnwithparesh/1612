myapp.controller("addholidays", function($scope, $http, $localStorage, $window,
		$compile, ServiceTaskTracker, $routeParams,$filter) {
	$scope.dates = $routeParams.dates;
	$scope.showval = false;
	$scope.hideval = true;
	$scope.todaydate = new Date();
	$scope.startdate = "";
	$scope.endDate = "";
  //  $scope.sdate ="";
    $scope.edate="";
	var myEl = angular.element(document.querySelector('body'));
	myEl.removeClass('login');

	//	alert(ServiceTaskTracker.getId() + ':'+ServiceTaskTracker.getName());
	$scope.alertOnClick = function(holidays) {
		//alert("hi");
		console.log('Clicked event ' + event.title);
	}

	$scope.holidays1 = [];
	$http({
		method : 'get',
		url : 'viewholidays'
	}).then(function(response, status, headers, cell, config) {
		$scope.holidays1 = response.data;
		$scope.startdate = $scope.holidays1[0].startdate;
		$scope.endDate = $scope.holidays1[0].endDate;
		$scope.color= $scope.holidays1[0].color;
		angular.forEach(response.data, function(value, key) {
			$scope.holidays1.push({
				startdate : value.startdate,
				endDate : value.endDate,
				description : value.description,
				color : value.color

			});
		});

	}, function(error) {
		console.log(error, 'can not get data.');
	});

	$scope.calendarOptions = {
		defaultView: "month",
		header : {
			left : 'prev,next today',
			center : 'title',
			right : 'listDay,month,listWeek,listMonth'
		},
		views : {
			listDay : {
				buttonText : 'list day'
			},
			listWeek : {
				buttonText : 'list week'
			},
			listMonth : {
				buttonText : 'list month'
			},
		/* listYear: {
		  buttonText: 'list year'
		} */
		},

		nowIndicator : true,
		locale : "en",
		titleFormat : "DD MM, YYYY",
		eventClick : function(holidays1) {

			$scope.startdate = holidays1.startdate;
			$scope.endDate = holidays1.endDate;
			$scope.description = holidays1.description;
			$scope.color = holidays1.color;
		},

		//for give color in  cellsfor holidays.
		dayRender : function(date, cell, start, end) {
			var check = moment(start).format("MM/DD/YYYY");
			$scope.startdate;
			$scope.endDate;

			//for find the all dates between two dates and colors them.
			var between = [];

			
			
			var currentDate = new Date($scope.startdate);
			 end = new Date($scope.endDate);
			 
			
			 
			// console.log(currentDate +"currentDate" +end +"end");
			var d1 = $scope.startdate;
			var d2= $scope.endDate;
			console.log($scope.endDate +"$scope.endDate" +$scope.startdate +"$scope.startdate");
			
			 if( d1 <= d2)
				 {
				 console.log(d1 +"d1" +d2 +"d2");
						cell.css("background-color", "yellow");
				// alert("in if");
				 
				 }
			while (currentDate <= end) {
				if (date.isSame(currentDate))
					cell.css("background-color", "yellow");

				between.push(new Date(currentDate));
				currentDate.setDate(currentDate.getDate() + 1);
			}
			
			 
		},

		selectable:true,
		eventOverlap : false,
		selectHelper : true,

		select : function(start, end, cell) {

			var check = moment(start).format("DD/MM/YYYY");
			var todaydate = moment(new Date()).format('DD/MM/YYYY');
			$scope.startDate = moment(start);
			
			$scope.todaydate =  moment(start);
			//alert("start date" +$scope.startDate);
			$scope.endDate = moment(end).format("DD/MM/YYYY");
			$scope.startdate = moment(start).format("DD/MM/YYYY");

			//alert();
			var datesss = new Date(check).getDay();
			var today = (new Date()).getDay();
			$scope.$apply();

			if (start.isBefore(moment())) {
				contMSG('Warning', 'Cannot Add Holidays in Past',
						'fa fa-exclamation-triangle', 'warning', 'center');
			} else {
				if (datesss == 0) {
					contMSG('Warning', 'Cannot  Add Holidays on Sunday',
							'fa fa-exclamation-triangle', 'warning', 'center');
				} else {
					$("#holidaysdate").modal("show");
				}

			}

		}

	};

	$scope.addHolidays = function() {
		var url = "/addholidays";
        //alert("in addholidays");
		var config = {
			headers : {
				'Content-Type' : 'application/json;charset=utf-8;'
			}
		}

		var data = {
			//task_id: $scope.task_id,
			startdate : $scope.startdate,
			endDate : $scope.endDate,
			description : $scope.description,
			color : "yellow"
		};

		$http.post(url, data, config).then(function(response) {
			$scope.success = true;
			$scope.error = false;
			$scope.successMessage = 'successful';
			$scope.form_data = {};
			contMSG('Success', 'Holiday/s Added Successfully', 'fa fa-check','success','right');			
		}, function(response) {
			$scope.success = false;
			$scope.error = true;
			contMSG('Danger', 'Some Error Occured. Try Again..!', 'fa fa-remove','danger','center');
		});

	}
	//Success msg
	function contMSG(title, msg, icon, state, align) {
		var placementFrom = 'top';
		var placementAlign = align;
		var state = state;
		var content = {};
		content.message = msg;
		content.title = title;
		content.url = '#';
		content.icon = icon;
		$.notify(content, {
			type : state,
			placement : {
				from : placementFrom,
				align : placementAlign
			},
			time : 1000,
			delay : 2000,
		});
	}
});
