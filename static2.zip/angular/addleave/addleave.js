myapp.controller("addleave", function($scope, $http, $window,$localStorage, $compile,$routeParams,ServiceTaskTracker, $routeParams) {
	

	var myEl = angular.element( document.querySelector( 'body' ) );
	myEl.removeClass('login');
	var myEl1 = angular.element( document.querySelector( '.wrapper' ) );
	myEl1.removeClass('wrapper-login');
	
	var myEl3 = angular.element( document.querySelector( '.main-header' ) );
	myEl3.css('display','block');

	var myEl4 = angular.element( document.querySelector( '.sidebar' ) );
	myEl4.css('display','block');
	$scope.uid = $localStorage.message;
	
  
	$scope.dates = $routeParams.dates;
	console.log("$scope.employee.id : "+$scope.uid);
	$scope.showval = false;
	$scope.hideval = true;
	
	$scope.empavailable={
			leavefrom:'',
			leaveto:'',
			meetingstime:'',
			meetingetime:'',
			description:'',
			 employee:{
				 id: 0
			 }
	};
	
	/*$scope.addItem=function(){
		  $scope.empavailable.employee.push({
			  id : $localStorage.message
		});
	}
	*/
	
	$scope.addleave = function() 
	{
		console.log($scope.uid +"=$scope.uid");
		
		var url = "addEmpAvailable/"+$scope.uid;

		 var config = {
					headers : {
						'Content-Type' : 'application/json'
					}
				}
		console.log("start date "+$('#leavefrom').val() + 'end date :'+ $('#leaveto').val());	

		//$scope.empavailable.leavefrom =$('#leavefrom').val();
		//$scope.empavailable.leaveto =$('#leaveto').val();
		 
		
		var data = JSON.stringify($scope.empavailable);
		
//		 console.log("selected employee :"+$scope.leavefrom +":"+$scope.leaveto+":"+$scope.meetingstime +""+$scope.meetingetime);
		/*var data = {
				leavefrom: $scope.leavefrom,
				leaveto: $scope.leaveto,
				meetingstime: $scope.meetingstime,
				meetingetime: $scope.meetingetime,
				description: $scope.description
				employee:{
						id : $scope.uid
						}
			
		}*/
		
		//var data =  $scope.empavailable;
          console.log("data"+JSON.stringify(data));
		$http.post(url, data, config).then(function (response) {
			  console.log("success"+response.data);
			 $scope.success = true;
			    $scope.error = false;
			    $scope.successMessage = 'successful';
			    contMSG('', 'Leave Addded', 'fa fa-check','success','right');
		}, function (response) {
			  console.log("error"+JSON.stringify(response.data));
			contMSG('Error', 'Some Error Occured. Try Again..!', 'fa fa-remove','danger','center');
		});
 }

	 //Success msg
		function contMSG(title, msg, icon,state,align) {
			var placementFrom = 'top';
			var placementAlign = align;
			var state = state;
			var content = {};
			content.message = msg;
			content.title = title;
			content.url = '#';
			content.icon = icon;
			$.notify(content, {
				type : state,
				placement : {
					from : placementFrom,
					align : placementAlign
				},
				time : 1000,
				delay : 2000,
			});
		}
	
		  $('.datepicker-default').datepicker();

		
});