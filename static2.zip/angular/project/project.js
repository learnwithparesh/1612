myapp.controller("addprojectController",function($scope, $http,$filter, $window,$localStorage, $route, $routeParams, ServiceTaskTracker) 
{
	 

	var myEl = angular.element( document.querySelector( 'body' ) );
	myEl.removeClass('login');
	var myEl1 = angular.element( document.querySelector( '.wrapper' ) );
	myEl1.removeClass('wrapper-login');
	
	var myEl3 = angular.element( document.querySelector( '.main-header' ) );
	myEl3.css('display','block');

	var myEl4 = angular.element( document.querySelector( '.sidebar' ) );
	myEl4.css('display','block');
	
	  $scope.dates = $routeParams.dates;
	  $scope.uid = $localStorage.message;
	  $scope.customer_id=$routeParams.ids;
	  $scope.todaydate = new Date();
	  
	  $scope.today=   $filter('date')($scope.todaydate, 'dd/MM/yyyy');
	  
	  
	 
		
	 $scope.project = {
			  id:0,
			  prname:'',
			  desc1:'',
			  code:',',
			  startDate:'01/01/2019',
			  endDate:'01/01/2019',
			  address: '',		  
			  insert_date:'',
			  insert_by:'',
			  update_by:'',
			  update_date:'',
			  filesid:'',
			  teamhead:{
				  id:0
			  },
			  projectteams:[{
				  employee : {
					id:0  
				  }				  
				}]  
	};
	  
	 
	// $scope.pid ='';
	//alert($scope.today +"$scope.today");
	//get project list with id  
	  $scope.projectdetails = function(id)
		 {
		  //alert(id+"project id");
		  
		  $scope.pid = id;
		  
			$scope.prList = {};
			var url = 'getprojectbyd/'+id;
			var config = {
				headers : {
					'Content-Type' : 'application/json;charset=utf-8;'
				}
			}
			$http.get(url).then(function(response) {
			
				//$scope.project = response.data;
			//	console.log(JSON.stringify($scope.project)+"56");
				//$scope.id = response.data.id;
				$scope.code=response.data.code;
				$scope.fileid = response.data.filesid;
				$scope.prname = response.data.prname;
				$scope.address= response.data.address;
				$scope.teamhead = response.data.teamhead;
				$scope.teamhead.id = response.data.teamhead.id;
				$scope.projectteams = response.data.projectteams;
				$scope.startDate= response.data.startDate;
				$scope.endDate= response.data.endDate;
				///console.log(JSON.stringify($scope.projectteams) +"projects" +$scope.teamhead.id);
			//	$scope.userid = response.data.id;
				//console.log($scope.pid +" $scope.userid");
			}, function error(response) {
				$scope.postResultMessage = "Error Status: " + response.statusText;
			});

		};
	
	  
	 

	var myEl = angular.element( document.querySelector( 'body' ) );
	myEl.removeClass('login');
	
	   $scope.success = false;
	   $scope.error = false;
	   
	   $http({
		    method: 'get', 
		    url: '/getempList'
		}).then(function (response, status, headers, config) {
	//	   console.log("emplist : "+JSON.stringify(response.data));
		    $scope.empList = response.data;
		  //  $scope.customer_id = $scope.listcustomers[0].id;
		    
		  
		},function (error){
		    console.log(error, 'can not get data.');
		});	

	   
	   $scope.addItem=function(){
		 //  alert("hi");
			  $scope.project.projectteams.push({
					 employee: {
						  id:0
					  }
			});
		}
	   
		 $scope.removeItem = function(m){
			// alert(m +"index");
			  $scope.project.projectteams.splice($scope.project.projectteams.indexOf(m),1);
				  }
		 
		 //save New  projects
	   $scope.addproject = function()
	   { 
		 alert( $scope.pid +"pid");
		   
		   var url=''; 
		   if($scope.project.prname != null)
			   {
			   
			
			   }
		   else{
			   url = "/addproject";
		   }
     		  

     		   var config = {
		                headers : {
		                    'Content-Type': 'application/json;charset=utf-8;'
		                }
		        }
			console.log("start date "+$('#startDate').val() + 'end date :'+ $('#endDate').val());	
				
				$scope.project.startDate =$('#startDate').val();
				$scope.project.endDate =$('#endDate').val();
				
				var data = JSON.stringify($scope.project);
				
			     console.log("data" +JSON.stringify($scope.project));
				$http.post(url, data, config).then(function (response) {
					$scope.success = true;
				    $scope.error = false;
				    $scope.successMessage = 'successful';
				    console.log('done');
				    var placementFrom = 'top';
					var placementAlign = 'right';
					var state = 'primary';
					var style = 'withicon';
					
				    var content = {};

					content.message = 'Project  Added Successfully';
					content.title = 'Success';
					content.url = '#';
					//content.target = '_blank';
					if (style == "withicon") {
						content.icon = 'fa fa-bell';
					} else {
						content.icon = 'none';
					}
				    $.notify(content,{
						type: state,
						placement: {
							from: placementFrom,
							align: placementAlign
						},
						time: 1000,
						delay: 0,
					});

				}, function (response) {
					 console.log('error');
					 var placementFrom = 'top';
						var placementAlign = 'right';
						var state = 'primary';
						var style = 'withicon';
						
					    var content = {};

						content.message = 'Error';
						content.title = 'Error';
						content.url = '#';
						//content.target = '_blank';
						if (style == "withicon") {
							content.icon = 'fa fa-bell';
						} else {
							content.icon = 'none';
						}
					    $.notify(content,{
							type: state,
							placement: {
								from: placementFrom,
								align: placementAlign
							},
							time: 1000,
							delay: 0,
						});
				});
		  };
		  
		  $scope.removeItem1 = function(m){
			//  alert(m +"index");
			  $scope.projectteams.splice($scope.projectteams.indexOf(m),1);
				  }

			//find all projects
			 $scope.projectlist = function()
			 {
				 //alert(id +"userid");
				$scope.prList1 = {};
				var url = 'viewproject';
				var config = {
					headers : {
						'Content-Type' : 'application/json;charset=utf-8;'
					}
				}
				$http.get(url).then(function(response) {
				
					$scope.prList1 = response.data;
				
					
				}, function error(response) {
					$scope.postResultMessage = "Error Status: " + response.statusText;
				});

			};
			$scope.projectlist();
			
			
			$scope.updateproject= function()
			{
			//	alert( $scope.pid  +"$scope.pid");
				
				var url="/updateproject/"+ $scope.pid;
				
				var config = {
					headers : {
						'Content-Type' : 'application/json;charset=utf-8;'
					}
				}
				var data = {
					//task_id: $scope.task_id,
					prname : $scope.prname,
					filesid : $scope.filesid,
					startDate : $scope.startDate,
					code : $scope.code,
					endDate:'01/01/2019',
					address: $scope.address,		  
					update_by: $scope.update_by,
					update_date: $scope.update_date,
				    teamhead:$scope.teamhead,
				    projectteams:[{
						  employee : {
							id:0  
						  }				  
						}]  
						 
				};

				$http.post(url, data, config).then(
						function(response) {
							$scope.success = true;
							$scope.error = false;
							$scope.successMessage = 'successful';
							contMSG('Success', 'Project Update Successful',
									'fa fa-bell', 'primary', 'right');

						},
						function(response) {
							contMSG('Danger', 'Some Error Occured. Try Again..!',
									'fa fa-remove', 'danger', 'center');
						});
			}
			
			
	   
	   
	   
	   //datepicker
		 $('.datepicker-default').datepicker();

		/*$('.datepicker').datetimepicker({
			format: 'DD/MM/YYYY',
		});*/
});