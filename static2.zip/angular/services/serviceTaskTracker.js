myapp.service('ServiceTaskTracker', function () {

    var name;
    var id;
    var roleid;
   
    this.getName = function () {
        return name;
    };
    
    this.setName = function (value) {
    	name = value;
    };

    this.getId = function () {
        return id;
    };
    
    this.setId = function (value) {
    	id = value;
    };
    
    this.getRoleid = function () {
        return roleid;
    };

    this.setRoleid = function (value) {
    	roleid = value;
    };

});
