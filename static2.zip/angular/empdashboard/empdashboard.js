myapp.controller("empdashboardCtrl", function($scope, $http, $window,$route,
	$localStorage, $filter, $compile, ServiceTaskTracker, $routeParams, $timeout,$translate,$rootScope) {
	
	
	
	var myEl = angular.element(document.querySelector('body'));
	myEl.removeClass('login');
	var myEl1 = angular.element(document.querySelector('.wrapper'));
	myEl1.removeClass('wrapper-login');

	var myEl3 = angular.element(document.querySelector('.main-header'));
	myEl3.css('display', 'block');

	var myEl4 = angular.element(document.querySelector('.sidebar'));
	myEl4.css('display', 'block');
	
	$rootScope.$emit('childEmit', $localStorage.roleid);
    $rootScope.$broadcast('siblingAndParent');
 
    
    $scope.searchtextid = sessionStorage.getItem('mysel');
  //  $scope.project.id = 0;
 // save userid
	$scope.uid = $localStorage.message;
	$scope.roleid = $localStorage.roleid;
	 $scope.required = true;
	// for today date.
	$scope.todaydate = new Date();
	
	//$scope.ttid;
	
	$scope.notiCount = 0;
	$scope.fetchNoti = [];
	$scope.custCount = 0;
	$scope.propCount = 0;
	$scope.projCount = 0;
	$scope.empCount = 0;
	$scope.taskCount = 0;
	$scope.myworkflows = {};
	$scope.tasktypes ={};
	$scope.task_id='';
	//task details for edit...
	 $scope.task ={
	    		//customer:$scope.customer,
				
				startDate:'',
				endDate:'',
				final_date:'',
				complete_date:'',
				filesid:'',
				color: '#007bffb8',
				status: 3,
				insert_by:'',
				insert_date:'',
				update_by:'',
				update_date:'',
				tname:'',
				task_type:1,
				assignto:{},
				
				arrivedfrom:'',
				branch:'',
				caseno:'',
				
				//संदर्भ
				inwordno:'',
				inworddate:'',
				letterdate:'',
				arrivedfrom:'',
				branch:'',
				sender:'',
				lettertype:'',
			
				lettersubject:'',
				letterdeliverytype:'',
				project:{
					id:0,
					prname:''
				},
				
				//workflow: '',
				//property_id : $scope.property.id,
				tasktype:{
					id : 0
				},
				
					
			//	employee:{}
	    }
	
	 
	 if($scope.uid != null && $scope.uid != '')
	{
		//get All task completed and assigned
			$http({
				method : 'GET',
				//url : 'gettaskslist'
			     url:'gettaskslist/' + $scope.uid + "/" + $scope.roleid 
			}).then(function(response) {
				$scope.tasklistbydate = response.data;
				
			//	console.log(JSON.stringify($scope.tasklistbydate) +"response.gettasklist..");

			    $scope.labels=[];
			    $scope.data=[];
				$scope.vc = [];
				$scope.vi = [];
				$scope.project = [];
				$scope.va=[];
			angular.forEach(response.data, function(value, key) {
				//console.log("jjjjj : + "+value);
				$scope.labels.push(value[4]);//moment().format('dddd');
				$scope.vc.push(value[1]);
				$scope.vi.push(value[2]);
				$scope.va.push(value[3]);
				
				$scope.project.push(value[1]);
				
				//console.log($scope.va+"  ist graph list  "+$scope.vc);
				
			});
			$scope.data.push(
					$scope.va,$scope.vc
				);
			
			    /*console.log(JSON.stringify($scope.labels) +" $scope.tlabels");
				console.log(JSON.stringify($scope.data) +" $scope.data");
				console.log(JSON.stringify($scope.project) +" $scope.project");*/
				});
				
		 
	}
		
	  
		
	  
	//for chart 1 task
	// $scope.labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July'];
	    $scope.series = ['संदर्भ','पूर्ण '];
	   /* $scope.data = [
	      [75, 63, 59, 79, 13, 91, 113]
	    ];
	 */
	   // $scope.ColorBar = ['#333'];    
	    
	  /*  $scope.ColorBar =[{
	        backgroundColor:"#1d7af3",
	        hoverBackgroundColor:"#716aca",
	        borderColor:"#1d7af3",
	        hoverBorderColor:"#716aca"
	  }];*/
	   
	    
	    
	    $scope.ColorBar =[{
	        backgroundColor:"#1d7af3",
	        hoverBackgroundColor:"#716aca",
	        borderColor:"#1d7af3",
	        hoverBorderColor:"#716aca"
	  },
	  {
	        backgroundColor:" #f3545d",
	        hoverBackgroundColor:"#bf5813",
	        borderColor:" #f3545d",
	        hoverBorderColor:"#bf5813"
	  }
	    
	    ];
	    
	    $scope.DataSetOverride = [{ yAxisID: 'y-axis-1' }]; //y-axis-1 is the ID defined in scales under options.
	 
	    $scope.options = {
	        legend: { display: true },
	        responsive: true,  // set to false to remove responsiveness. Default responsive value is true.
	        scales: {
	            yAxes: [
	                {
	                    id: 'y-axis-1',
	                    type: 'linear',
	                    display: true,
	                    position: 'left',
	                    ticks: {
	                        beginAtZero: true
	                    }
	                }]
	        }
	    }
	 
	    $scope.clickme = function($event){
	       // alert("You've clicked upon "+$event[0]._view.label);
	    }
	 
	    $scope.hoverme = function ($event) {
	        //alert("You hovered over " + $event[0]._view.label);
	    }

	    $scope.tdata = [];
	    $scope.tlabels = [];
	    $scope.tasklistbydate =[];
	    if($scope.uid != null && $scope.uid != '')
		{
	    	//get received and send task Count by date
			$http({
				method : 'GET',
				url : 'gettasksbydate/' + $scope.uid
			}).then(function(response) {
				$scope.tasklistbydate = response.data;
				
				//console.log(JSON.stringify(response.data) +"response.hkddata");
		
			
				$scope.v1 = [];
				$scope.v2 = [];
			angular.forEach(response.data, function(value, key) {
				/*console.log("sd :"+ key + "-value 0- "+ value[0]);
				console.log("sd :"+ key + "-value 1- "+ value[1]);
				console.log("sd :"+ key + "-value 2- "+ value[2]);*/
				$scope.tlabels.push(moment(value[0]).format('dddd'));//moment().format('dddd');
				
			//	console.log(response.data +"  , ");
			
				
				$scope.v1.push(value[1]);
				$scope.v2.push(value[2]);
				
				
				
				
					/*angular.forEach(value, function(value1, key1) {
					$scope.tdata3.push([
						//date_assigned : value.$scope.tasklistbydate[0].date_assigned
						date_assigned :value.$scope.tasklistbydate[0].date_assigned;
					    tassk_from :value.$scope.tasklistbydate[0].task_from;
					    task_to : value.$scope.tasklistbydate[0].task_to;
						]);
					});*/
				//console.log($scope.v1+"  $scope.v1  " +$scope.v2+"  $scope.v2  ");
				});
			$scope.tdata.push(
					
					$scope.v1,$scope.v2
					
				);
			
			   /* console.log(JSON.stringify($scope.tlabels) +" $scope.tlabels");
				console.log(JSON.stringify($scope.tdata) +" $scope.tdata");*/
				});
			/*});*/
		}
			
	    
		
		
	  //for chart 2 multi tapal
	  //  $scope.tlabels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July'];
		/*$scope.tlabels = $scope.g1;*/
	    $scope.tseries = ['Tapal In', 'Tapal Out'];
	 
	
	   /* $scope.tdata = [
	      [75, 63, 59, 79, 13, 91, 113],
	      [27, 48, 54, 70, 89, 35, 53]
	    ];*/
	  //  $scope.tdata = $scope.tdata3;
	 
	   // $scope.tColorBar = ['#90EE90', '#FF6600'];  
	    
	    $scope.tColorBar =[{
	        backgroundColor:"#90EE90",
	        hoverBackgroundColor:"#6bbb38",
	        borderColor:"#90EE90",
	        hoverBorderColor:"#6bbb38"
	  },
	  {
	        backgroundColor:"#FF6600",
	        hoverBackgroundColor:"#bf5813",
	        borderColor:"#FF6600",
	        hoverBorderColor:"#bf5813"
	  }
	    
	    ];
	    $scope.tDataSetOverride = [{ yAxisID: 'y-axis-1' }]; //y-axis-1 is the ID defined in scales under options.
	 
	    $scope.toptions = {
	        legend: { display: true },
	        responsive: true,  // set to false to remove responsiveness. Default responsive value is true.
	        scales: {
	            yAxes: [
	                {
	                    id: 'y-axis-1',
	                    type: 'linear',
	                    display: true,
	                    position: 'left'
	                }]
	        }
	    }
			 
		   //ends
	
	
	
	
	// $scope.task_id ="";

	

	$scope.showval = false;
	$scope.hideval = true;
	
	$scope.workflow = {
		description : "",
		noticode:'2',
		task_from : {
			id : $scope.uid
		},
		task_to : {
		   id:''
		},
		
		task : {
			id : 0,
			status : 2,
			update_by : $scope.uid,
			update_date : ""
		}
	};

	$scope.addItem = function() {
		$scope.workflow.task.push({
			task_id : value.task.task_id
		});
	}
	$scope.alertOnClick = function(event) {
		//console.log('Clicked event ' + event.title);
	}

	// $scope.events[id];

	
	
	$scope.endDate="";
	$scope.events = [];
	$scope.task_id;
	
	$scope.displaytask = function()
	{

     //alert( $scope.uid + "/" + $scope.roleid);
		$scope.events = [];
		
		$http({
			method : 'get',
			url : "getlisttask/" + $scope.uid + "/" + $scope.roleid
 
		}).then(function(response, status, headers, config) {
	 
			$scope.taskEvents = response.data;
			$scope.taskTitle;
			//$scope.task_id = $scope.taskEvents[0].id;
	        
		//	console.log("$scope.task_id"+$scope.task_id);
		
        //	console.log("task with name before split : "+JSON.stringify($scope.taskEvents));
        	
        	
			angular.forEach($scope.taskEvents, function(value, key)
					{
				$scope.ttaskid = value.id;
				//console.log(value.aid+"value of uid: " +$scope.uid);
				
				if(value.status == 2 && value.aid == $scope.uid && value.lid != value.aid )
					{
					 value.color = "gray";
					}
				 else if(value.status == 3 && value.lid == $scope.uid)
					 value.color = "#007bffb8";
				
				 else if(value.status == 1)
					 value.color = "red";
				
				 else if(value.status == 4)
					 value.color="#F88017";
				
				 else if(value.status == 5 && value.status != 4)
					 value.color ="#7D6608";
				
				 else
					value.color = "#007bffb8";
				
				if(value.ttype == 1)
				{
					$scope.taskTitle = "PAP संदर्भ क्रं-"+value.tname + "-" + value.tapal
				}
				else if(value.ttype == 2)
					{
					$scope.taskTitle = "टपाल-"+value.lettersubject+ "-" +value.tapal
					}
				
				$scope.events.push({
					
					title : $scope.taskTitle,
				    start:value.maxDate,
				    color:value.color,
				    task_id : value.id
				   
			
				});
				//console.log("task id:" + $scope.events.task_id);
//				console.log("task events data: "+JSON.stringify($scope.events));
			});

			
		}, function(error) {
		});
	};
	
	if($scope.uid != null && $scope.uid != '')
	{
		//alert($scope.uid);
		$scope.displaytask();
	}
	
	
	
	$scope.calendarOptions = {
		defaultView: "listWeek",
		header : {
			left : 'prev,next today',
			center : 'title',
			right : 'listDay,month,listWeek,listMonth'
		},
		displayEventTime : false,
		views : {
			listDay : {
				buttonText : 'list day'
			},
			listWeek : {
				buttonText : 'list week'
			},
			listMonth : {
				buttonText : 'list month'
			},
	
		},
		
		nowIndicator : true,
		locale : "en",
		titleFormat : "D MMM, YYYY",
		eventClick : function(event)
		{
			$scope.tid;
			$scope.task_id = event.task_id;
			
		
			$rootScope.$emit('upempmodel',$scope.task_id);
	

				
			//	$("#notification").modal("show");
			
			// console.log('test data 2: '+JSON.stringify(event.workflow));
		/*	if (uid = $scope.assignto.id) {
				$("#eventDetails").modal("show");
				$scope.$apply();
			}*/
		},
		selectable : true,
		eventOverlap : false,
		selectHelper : true,
		select : function(start, end) {

			var check = moment(start).format("YYYY-MM-DD");
			var today = moment(new Date()).format('YYYY-MM-DD');

			$scope.todaydate = check;
			var datesss = new Date(check).getDay();

			var today = (new Date()).getDay();
			
			if (start.isBefore(moment())) {
				contMSG('Warning', 'Cannot Assign Task in Past',
						'fa fa-exclamation-triangle', 'warning', 'center');
			} else {
				if (datesss == 0) {
					contMSG('Warning', 'Cannot Assign Task on Sunday',
							'fa fa-exclamation-triangle', 'warning', 'center');

				} else {
					$window.location.href = '#!addtasks/' + check;
				}
			}
		},
	};

	/*$rootScope.$on('childEmit1', function(event, data) {
	  //  console.log(data + ' Inside emp dashboard click');
	    $scope.clickUpload(data);
	    
	  });
	*/
	//notification on click
	$scope.clickNoti = function(nid) {	
	//	$scope.getEvents();		
		$scope.clickUpload(nid);		
	}
	  
	$scope.clickUpload = function(ttid) {
		//alert("hi"+ttid+"eve"+$scope.event);
		$scope.event = $scope.events.find(function(obj) {
			return obj.task_id == ttid;
		});
		// Event details
		$scope.task_id = $scope.event.task_id;
		$scope.getDate = moment($scope.event.start).format("YYYY-MM-DD");
		$scope.gettitle = $scope.event.title;
		$scope.insert_date = $scope.event.insert_date;
		$scope.description = $scope.event.description;
		$scope.assignto = $scope.event.assignto;
		$scope.task.tname = $scope.event.tname;
		$scope.status = $scope.event.status;
		$scope.task.endDate=$scope.event.endDate;
		
	
		// Customer details
		if($scope.event.customer)
		{
			$scope.task.property_id23 = $scope.event.property_id;
			$scope.customer_id = $scope.event.customer.id;
			$scope.name = $scope.event.customer.name;
			$scope.contact_number = $scope.event.customer.contact_number;
			$scope.task.filesid = event.filesid;
			
			// Project Details
			$scope.startDate = $scope.event.project.startDate;
			$scope.desc1 = $scope.event.project.desc1;
			$scope.endDate = $scope.event.project.endDate;
			$scope.update_date = $scope.event.project.update_date;
			
			//empty fields 
			$scope.lettertype = '';
			$scope.sender = '';
			$scope.letterdate = '';
			$scope.arrivedfrom = '';
			$scope.branch = '';
			$scope.lettersubject = '';
			$scope.filesid = '';
			$scope.inwordno = '';
			$scope.inworddate = '';
			$scope.task.endDate='';
		}
		else
		{
			
			//संदर्भ
			$scope.task.lettertype = $scope.event.lettertype;
			$scope.task.sender = $scope.event.sender;
			$scope.task.letterdate = $scope.event.letterdate;
			$scope.arrivedfrom = $scope.event.arrivedfrom;
			$scope.task.branch = $scope.event.branch;
			$scope.task.lettersubject = $scope.event.lettersubject;
			$scope.task.filesid = $scope.event.filesid;
			$scope.task.inwordno = $scope.event.inwordno;
			$scope.task.inworddate = $scope.event.inworddate;
			$scope.endDate = $scope.event.project.endDate;
		
			//empty fields
			
			$scope.property_id23 	= '';
			$scope.customer_id 	    = '';
			$scope.name             = '';
			$scope.contact_number   = '';
			
			// Project Details	 = '';
			$scope.startDate 	 = '';
			$scope.desc1 	     = '';
			$scope.endDate  = '';
			$scope.update_date 	 = '';
			$scope.startDate	 = '';
			$scope.desc1	     = '';
			$scope.endDate	     = '';
			$scope.update_date	 = '';

		}
		//workflow
		$scope.myworkflows = $scope.event.workflow;
      
		//open modal
		// console.log('test data 2: '+JSON.stringify(event.workflow));
		if (uid = $scope.assignto.id) {
			$("#eventDetails").modal("show");
		}
	};

	function getSelecteIndex(ids) {
		for (var i = 0; i < $scope.events.length; i++)
			if ($scope.events.length[i].id == ids)
				return i;
		return -1;
	}
	
	

	//find all employee
	 function employeeList() {
		$scope.empList = {};
		var url = 'getempList';
		var config = {
			headers : {
				'Content-Type' : 'application/json;charset=utf-8;'
			}
		}
		$http.get(url).then(function(response) {
			// $scope.getDivAvailable = true;
			// console.log('empList : '+JSON.stringify(response.data));
			$scope.empList = response.data;
		}, function error(response) {
			$scope.postResultMessage = "Error Status: " + response.statusText;
		});

	}
	employeeList();
	
	$rootScope.$on('empEmit', function(event, data) {
		//  console.log(data + ' Inside Sibling one');

		employeeList();
	});
	
	

	//property details
	 function fetchProperty() {
		$scope.property = [];
		var url = '/viewproperty';
		var config = {
			headers : {
				'Content-Type' : 'application/json;charset=utf-8;'
			}
		}
		$http.get(url).then(function(response) {
			$scope.property = response.data;
		}, function error(response) {
			$scope.postResultMessage = "Error Status: " + response.statusText;
		});
	}
	fetchProperty();
    
	//hide and show div
	$scope.isShowHide = function(param,$event) {
		$event.preventDefault();
		if (param == "show") {
			$scope.showval = true;
			$scope.hideval = true;
			$scope.showFirstButton = !$scope.showFirstButton
		}
	}
	
	$scope.isShowHide12 = function(param,$event) {
		$event.preventDefault();
		if (param == "show") {
			$scope.showval = true;
			$scope.hideval = true;
			$scope.showFirstButton = !$scope.showFirstButton
		}
	}
    
	var i = 0;
	//work flow assign
	$scope.assigntask = function(tid) {
//		$event.preventDefault();
		//console.log("task: "+tid+"id: value:");
		var url

		$scope.showFirstButton = !$scope.showFirstButton;
	
		if($scope.assignto.id == $scope.lastassign.id && $scope.assignto.id == uid && $scope.task.endDate  == null)
		//if($scope.assignto == $scope.lastassign && $scope.assignto ==  $scope.uid && $scope.endDate  == null)
		{
			//alert("in first");
			var v = '';
			v = $scope.endDate;
			url = "addworkflow/"+tid+"/"+v.toString().split('/').join('-');
		}
		else
		{
			//alert("in else");
			url = "addworkflow/" + tid;
		}

		var config = {
			headers : {
				'Content-Type' : 'application/json;charset=utf-8;'
			}
		}
		
	
			var data = JSON.stringify($scope.workflow);
		
		//console.log("workflow::" +data);
		
		$http.post(url, data, config).then(
				function(response) {
					$scope.success = true;
					$scope.error = false;
					$scope.successMessage = 'successful';
					$("#eventDetails").modal("hide");
					$("#notification").modal("hide");
					contMSG('Success', 'Task Assigned Successfully',
							'fa fa-check', 'success', 'right');
					//$scope.displaytask();
					//$route.reload();
				},
				function(response) {
					contMSG('Danger', 'Some Error Occured. Try Again..!',
							'fa fa-remove', 'danger', 'center');
				});
	}
	 i++;
	 
	 
		//in bodyController
		$rootScope.$on('taskassign', function(event, data) {
			//  console.log(data + ' Inside Sibling one');
	       //console.log("task id : "+data);
	       $scope.assigntask(data);
		});
		
	 
	//task complete //also use in mybodyctrl for notification model.
	$scope.taskcomplete = function(tid,$event) {
	//	$event.preventDefault();
		//alert("task id : " +tid);
		var url = "/completetask/" + tid;
		var config = {
			headers : {
				'Content-Type' : 'application/json;charset=utf-8;'
			}
		}

		var data = {
			id : $scope.events[0].id,
			//assignto : $scope.events[0].insert_by,
		    // insert_by:$scope.uid
			
		};

		$http.post(url, data, config).then(
				function(response) {
				//	console.log(JSON.stringify(data));
					$scope.success = true;
					$scope.error = false;
					$scope.successMessage = 'successful';
					$scope.form_data = {};
					$("#eventDetails").modal("hide");
					$("#notification").modal("hide");
					contMSG('Success', 'Task Completed', 'fa fa-check',
							'success', 'right');
				//	$scope.closeModal();
					//fetchData();
				},
				function(response) {
					console.log(JSON.stringify(data) +"error");
					$scope.success = false;
					$scope.error = true;
					$scope.errorMessage = 'error...!';
					contMSG('Error', 'Some Error Occured. Try Again..!',
							'fa fa-remove', 'danger', 'center');
				});
	}
	
	//in bodyController
	$rootScope.$on('taskcomp', function(event, data) {
		//  console.log(data + ' Inside Sibling one');
    //   console.log("task id : "+data);
		$scope.taskcomplete(data);
	});
	
	
	//task complete
	$scope.updateworkflow = function() 
	{
		var url = "/completeworkflow/" + $scope.task_id;
		var config = {
			headers : {
				'Content-Type' : 'application/json;charset=utf-8;'
			}
		}

		var config = {
				headers : {
					'Content-Type' : 'application/json;charset=utf-8;'
				}
			}
			var data = JSON.stringify($scope.workflow);
			$http.post(url, data, config).then(
					function(response) {
						$scope.success = true;
						$scope.error = false;
						$scope.successMessage = 'successful';
						//$("#eventDetails").modal("hide");
						//contMSG('Success', 'Task Assigned Successfully',
						//		'fa fa-check', 'success', 'right');
						fetchData();
					},
					function(response) {
						//contMSG('Danger', 'Some Error Occured. Try Again..!',
							//	'fa fa-remove', 'danger', 'center');
					});
	}

	//task reject function
	$scope.taskReject = function(tid,$event) {
		//$event.preventDefault();
		var url = "/rejecttask/" + tid;
		var config = {
			headers : {
				'Content-Type' : 'application/json;charset=utf-8;'
			}
		}

		var data = {
			id : $scope.events[0].id,
		};

		$http.post(url, data, config).then(
				function(response) {
					$scope.success = true;
					$scope.error = false;
					$scope.successMessage = 'successful';
					$scope.form_data = {};
					$("#eventDetails").modal("hide");
					//$scope.closeModal();
					contMSG('Rejected', 'Task Rejected',
							'fa fa-exclamation-triangle', 'success', 'center');
					//fetchData();
				},
				function(response) {
					$scope.success = false;
					$scope.error = true;
					$scope.errorMessage = 'error...!';
					contMSG('Error', 'Some Error Occured. Try Again..!',
							'fa fa-check', 'danger', 'right');
				});
	}
	
	

	
	//get notification
	//$timeout( , 1000);
	function fetchNoti() {
		$scope.notiCount = 0;
		$scope.fetchNoti = [];
		var url = '/getnoti/' + $localStorage.message;
		var config = {
			headers : {
				'Content-Type' : 'application/json;charset=utf-8;'
			}
		}
		$http.get(url).then(function(response) {		
			//alert("hi");
			$scope.fetchNoti = response.data;
			//get notification count
			angular.forEach(response.data, function() {
				$scope.notiCount +=1;
			});
		}, function error(response) {
			$scope.postResultMessage = "Error Status: " + response.statusText;
		});
	}
	
	if($scope.uid != null && $scope.uid != '')
	{
		fetchNoti();
	}
	
	
	
	$scope.IsVisible = false;
  /*  $scope.ShowHide = function () {
        //If DIV is visible it will be hidden and vice versa.
        $scope.IsVisible = $scope.IsVisible ? false : true;
    }*/
	
	$scope.isShowHide1 = function(param,$event) {
		$event.preventDefault();
		if (param == "show") {
			$scope.showbutton = true;
			$scope.hideval = true;
			$scope.showNextButton = !$scope.showNextButton
		}
	}
	
	$scope.nextfinaldate =$('#nextfinaldate').val();
	//to set next final date for the task
	$scope.tasknextfinaldate  = function(tid,$event) {
		$event.preventDefault();
		$scope.showNextButton = !$scope.showNextButton
		 
		var url = "/nextfinaltime/" +tid;
		
		var config = {
			headers : {
				'Content-Type' : 'application/json;charset=utf-8;'
			}
		}

		var data = {
			id : $scope.events[0].id,
			nextfinaldate:$scope.nextfinaldate
		};

		$http.post(url, data, config).then(
				function(response) {
					$scope.success = true;
					$scope.error = false;
					//console.log(response.data +"pass");
					$scope.successMessage = 'successful';
					$scope.form_data = {};
					$("#eventDetails").modal("hide");
					contMSG('Success', 'Next Date set', 'fa fa-check',
							'success', 'right');
					$scope.closeModal();
					
				},
				function(response) {
					$scope.success = false;
					console.log(response.data +"fail");
					$scope.error = true;
					$scope.errorMessage = 'error...!';
					contMSG('Error', 'Some Error Occured. Try Again..!',
							'fa fa-remove', 'danger', 'center');
				});
	}
	
	$rootScope.$on('tasktasknextfinaldate', function(event, data) {
		//  console.log(data + ' Inside Sibling one');
       //console.log("task id : "+data);
       $scope.tasknextfinaldate(data);
	});
	
	

		
	  // check if roleid is 'Tahsildar'.
	$scope.checkroles = function($event) {
		//var today = (new Date()).getDay();
       $event.preventDefault();
		if ($scope.roleid == 2) {
			 $scope.enddateoftask();
		} else {

			$scope.showError = false;
		}

	}
	
	
// $scope.endDate =$('#endDate').val();
	
//set end date of task	
    $scope.enddateoftask  = function() {
		 
		var url = "/setenddate/" + $scope.task_id;
		
		var config = {
			headers : {
				'Content-Type' : 'application/json;charset=utf-8;'
			}
		}
      console.log("envent [0] :"+$scope.events[0].id);
		var data = {
			//id : $scope.events[0].id,
			endDate:$scope.endDate
		};
		
		if(JSON.stringify(data)== NULL)
			{
			$scope.msg ="please enter the end date";
			}
		else
			{
			//console.log(JSON.stringify(data));
			$http.post(url, data, config).then(
					function(response) {
						console.log(response.data+"success" +response)
						$scope.success = true;
						$scope.error = false;
						console.log($scope.endDate+"endDate");
						$scope.successMessage = 'successful';
						$scope.form_data = {};
					//	$("#eventDetails").modal("hide");
						//contMSG('Success', 'Task Completed', 'fa fa-check',
					//			'success', 'right');
						$scope.closeModal();
						//fetchData();
					},
					function(response) {
						console.log(response.data)
						$scope.success = false;
						$scope.error = true;
					//	$scope.errorMessage = 'error...!';
					//	contMSG('Error', 'Some Error Occured. Try Again..!',
						//		'fa fa-remove', 'danger', 'center');
					});
			}
	}
	
	$rootScope.$on('selectSearchEmit1', function(event, data) 
			{
	    console.log(data + ' Insideseasrch  sss  Sibling one');
	    $scope.searchtextid45 = data;
	   // $scope.selectitem();
	    $scope.clickUpload(data);	
	  });

	/*$rootScope.$on('selectitem1Emit', function(event, data) {
		  //  console.log(data + ' Inside Sibling one');
		$("#taskDetails").modal("show")
		   // fetchNoti();
		  });*/
//searching
  $scope.selectitem = function() 
    {
	  console.log($scope.searchtextid45 +"$scope.searchtextid");
	  $scope.searchtextid = $scope.searchtextid45;
	  
	if($scope.searchtextid)
	{
		//alert("hii");
		$("#taskDetails").modal("show")
	}
	}
  
  
  //button disable on click
  function enableButton2() {
      document.getElementById("button2").disabled = false;
  }
	
	
	if($scope.uid != null && $scope.uid != '')
	{
		// get  received and send task Count
		$http({
			method : 'GET',
			url : 'gettaskscount/' + $scope.uid
		}).then(function(response) {
			console.log( " $s]]]"+ JSON.stringify(response.data));
		/*	console.log( " $s]]]"+response.data);
			console.log( " $s]]]"+response.data[0]);
			console.log( " $s]]]"+response.data[1]);
			console.log( $scope.uid +" $scope.uid");*/
			$scope.taskcount1 = response.data[0];
			$scope.taskcount2 = response.data[1];
		});
		
		
		// get Customer Count
		$http({
			method : 'GET',
			url : 'getCustCount'
		}).then(function(data) {
			$scope.custCount = data.data;
		});
		// get Property Count
		$http({
			method : 'GET',
			url : 'getPropCount'
		}).then(function(data) {
			$scope.propCount = data.data;
		});
		// get Project Count
		$http({
			method : 'GET',
			url : 'getProjCount'
		}).then(function(data) {
			$scope.projCount = data.data;
		});
		// get Employee Count
		$http({
			method : 'GET',
			url : 'getEmpCount'
		}).then(function(data) {
			$scope.empCount = data.data;
		});
		// get Task Count
		$http({
			method : 'GET',
			url : 'getTaskCount'
		}).then(function(data) {
			$scope.taskCount = data.data;
		});
		//getcount by userid  
		$http({
			method : 'GET',
			url : 'getProjCountbyid/'+$scope.uid
		}).then(function(data) {
			$scope.prcount = data.data;
		});
	}

	// Success msg
	function contMSG(title, msg, icon, state, align) {
		var placementFrom = 'top';
		var placementAlign = align;
		var state = state;
		var content = {};
		content.message = msg;
		content.title = title;
		content.url = '#';
		content.icon = icon;
		$.notify(content, {
			type : state,
			placement : {
				from : placementFrom,
				align : placementAlign
			},
			time : 1000,
			delay : 2000,
		});
	}
	  
	 
	 //for tooltip
	 $(".workflow,.workflow-close-icon").on('click',function(){
		  $(".click-menu").toggleClass('onclick-menu');
		});
	 
	
	 //to update the task details
	 $scope.saveUser = function() {
	
		    // $scope.user already updated!JSON.stringify($scope.task)  
		 var data = JSON.stringify($scope.task);
		 
		 console.log(data +"details of task");
		 
		 
		 return $http.post('/updatetask/'+ $scope.task_id,data).then(function (response)
					{
			 $scope.success = true;
				$scope.error = false;
				console.log($scope.endDate+"endDate");
				$scope.successMessage = 'successful';
				$scope.form_data = {};
				$scope.displaytask();
				$("#eventDetails").modal("hide");
				//contMSG('Success', 'Task Completed', 'fa fa-check',
			//			'success', 'right');
				$scope.closeModal();
				

			}, function (response) {
				 console.log('error'+JSON.stringify(response.data));
				 $scope.success = false;
					$scope.error = true;
			});
		 
	 
		 
	/*	 
		 return $http.post('/updatetask/'+ $scope.task_id,data).error(function(err) {
		    	
		      if(err.field && err.msg) {
		        // err like {field: "name", msg: "Server-side error for this username!"} 
		        $scope.editableForm.$setError(err.field, err.msg);
		      } else { 
		        // unknown error
		       // $scope.editableForm.$setError('name', 'Unknown error!');
		      }
		    });*/
		  };
		  
		  
		  $rootScope.$on('mybodyCtrlupdate', function(event, data) {
				//  console.log(data + ' Inside Sibling one');
		       //console.log("task id : "+data);
			  $scope.saveUser();
			});
		  
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////		  
		  $scope.printmodal = function()
		  {
	
			  $('#eventDetails').modal('hide');
			  $('body').removeClass('modal-open');
			  $('.modal-backdrop').remove();
		      
			   sessionStorage.setItem("taskid",$scope.task_id );
			   
			   $window.location.href = '#!printdetails';

		  }
		  
		  $rootScope.$on('print', function(event, data) {
			console.log(data + ' Inside Sibling one');

			  $scope.printmodal();
			});
		  
///////////////////////////////////////////////project list/////////////////////////////////////////////////////////

		   
		   
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		   
		  
		  $scope.updateteammem = function()
		  {
			  $scope.teamlist11 = [];
			  // alert($scope.project.id +"$scope.project.id"+$('#test1').val() );
				 
				   var value1 = $('#test1').val().substring($('#test1').val().lastIndexOf(':') + 1);
				   console.log($('#test1').val() +"$scope.project.id"+ value1);
				   
				   var url = 'readprojectteam1/'+value1;
					
					var config = {
			               headers : {
			                   'Content-Type': 'application/json;charset=utf-8;'
			               }
			       }
					$http.get(url).then(function (response) {
						// $scope.getDivAvailable = true;
					
						$scope.teamlist11 = response.data;
						//projectList();
						console.log(JSON.stringify($scope.teamlist11) +"team members");
						
					}, function error(response) {
						$scope.postResultMessage = "Error Status: " +  response.statusText;
					});
		  };
		 
		  $rootScope.$on('onmybodyCtrl', function(event, data) {
				//  console.log(data + ' Inside Sibling one');
		       //console.log("task id : "+data);
			  $scope.updateteammem();
			});
			
		 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		  
		  $scope.openfiledetails = function()
		  {
			  $('#eventDetails').modal('hide');
			  $('body').removeClass('modal-open');
			  $('.modal-backdrop').remove();
		      
				$window.location.href = '#!filesdetails';
				
		  }
	     
		   ////////////////////////////////////////////////////////////////////////////////////////////
 

	 //datepicker
	 $('.datepicker-default').datepicker();
	 
	 $(".content").on('click', '.print', function(){
		 //get the modal box content and load it into the printable div
		 $(".printable").html(
		   $(".modal-body").html()
		) });
		 //fire the print method
		// window.print();
		 
  
	//tooltip
	 $('[data-toggle="tooltip"]').tooltip(); 
	 
	 //for pagination
     $scope.viewby = 10;
     $scope.totalItems =  $scope.events.length;
     $scope.currentPage = 4;
     $scope.itemsPerPage = $scope.viewby;
     $scope.maxSize = 5; //Number of pager buttons to show

     $scope.setPage = function (pageNo) {
       $scope.currentPage = pageNo;
     };

     $scope.pageChanged = function() {
       console.log('Page changed to: ' + $scope.currentPage);
     };

   $scope.setItemsPerPage = function(num) {
     $scope.itemsPerPage = num;
     $scope.currentPage = 1; //reset to first page
   }
    	
  /////////////////////// pagination end////////////////////  	
   
   
   
   //for confirmation message for reject task
   
   //for confirmation message for reject task
	$scope.errorclick = function(tid,$event) {
		swal({
			title: 'Are you sure?',
			text: "You Want to Reject this Task!",
			type: 'warning',
			buttons:{
				confirm: {
					text : 'Yes, Reject it!',
					className : 'btn btn-success'
				},
				cancel: {
					visible: true,
					className: 'btn btn-danger'
				}
			}
		}).then((Delete) => {
			if (Delete) {
				swal({
					title: 'Rejected!',
					text: 'Your Task has been rejected.',
					type: 'success',
					buttons : {
						confirm: {
							className : 'btn btn-success'
						}
					}
				}).then(
						function() {
							
							$scope.taskReject(tid,$event);
						});
						
			} else {
				swal.close();
			}
		});
	};
	
	//in bodyController
	$rootScope.$on('taskreject', function(event, data) {
		//  console.log(data + ' Inside Sibling one');
       console.log("task id : "+data);
       $scope.errorclick(data);
	});
	
	
	
	
	 //for confirmation message for reject task
	$scope.taskclose = function(tid,$event) {
		swal({
			title: 'Are you sure?',
			text: "You want to Close this Task!",
			type: 'warning',
			buttons:{
				confirm: {
					text : 'Yes, Close it!',
					className : 'btn btn-success'
				},
				cancel: {
					visible: true,
					className: 'btn btn-danger'
				}
			}
		}).then((Delete) => {
			if (Delete) {
				swal({
					title: 'Close!',
					text: 'Your Task has been Closed.',
					type: 'success',
					buttons : {
						confirm: {
							className : 'btn btn-success'
						}
					}
				}).then(
						function() {
							
							$scope.taskcomplete(tid,$event);
						});
						
			} else {
				swal.close();
			}
		});
	};

	


	
	
});
