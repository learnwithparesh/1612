myapp.controller("navbarController" ,function($scope, $http, $window, $compile, ServiceTaskTracker,$location)
{
	var myEl = angular.element( document.querySelector( 'body' ) );
	myEl.removeClass('login');
	//alert(ServiceTaskTracker.getId() + ':'+ServiceTaskTracker.getName());
	$scope.alertOnClick = function(event) {
		alert("hi");
		console.log('Clicked event ' + event.title);
	}
	$scope.events = [];
	$http({
	    method: 'get', 
	    url: '/showtask'
	}).then(function (response, status, headers, config) {
	   console.log(response.data);
	   $scope.tasklist = response.data;
	   angular.forEach(response.data, function (value, key) {
		   $scope.events.push({
	           title: value.task_type,
	           start: value.insert_date,
	           description: value.tname,
	           color:value.color
	       });
       });
	   
	},function (error){
	    console.log(error, 'can not get data.');
	});	
	
	
	 $scope.editCat = function(id)
	   {
		 // var index = getSelecteIndex(id);
		  //console.log(index);
		   var cat = $scope.subcatsData[id];
		   $scope.modalTitle = 'Update Category';
		   $scope.submit_button = 'Update';
		   $scope.subcatName = cat.subcatname;
		   $scope.subcatDesc = cat.subcatdesc;
		   $scope.hidden_id = cat.id;
		   var modal_popup = angular.element('#updatemodal');
		   modal_popup.modal('show');
	   };
	
	$scope.displaytask=function(id){
		var tid =  $scope.tasklist[id] ;
		$scope.modalTitle = 'Update Category';
		var modal_popup = angular.element( document.querySelector( '#updatemodal' ) );
		 //var modal_popup = angular.element('#updatemodal');
		//var modal_popup = angular.element('#updatemodal');
		$(modal_popup).modal('show')
		//modal_popup.modal();
		//$scope.submit_button = 'Update';
	}
	
});
		