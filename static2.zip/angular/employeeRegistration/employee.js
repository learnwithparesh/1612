myapp.controller("addEmployeeCtrl", function($scope, $http, $window,
		$localStorage, $route, $routeParams, ServiceTaskTracker,$rootScope) {
	//$scope.id="";
	//$scope.userid ='';
	//$scope.role_id = $routeParams.$scope.role_id ;
	$scope.employee = {
		name : '',
		mid : '',
		lastname : ' ',
		email : '',
		password : '',
		contactnumber : '',
		gender : '',
		bdate : '',
		caddress : '',
		paddress : '',
		password : '',
		active : 0,
		roles : [ {
			id : 0
		} ]
	};

	$scope.addEmployee = function() {
		var url = "addemployee"
		var config = {
			headers : {
				'Content-Type' : 'application/json;charset=utf-8;'
			}
		}
		var data = {
			//task_id: $scope.task_id,
			name : $scope.name,
			mid : $scope.mid,
			lastname : $scope.lastname,
			email : $scope.email,
			password : $scope.password,
			roles : $scope.roles,
			email : $scope.email,
			contactnumber : $scope.contactnumber,
			gender : $scope.gender,
			bdate : $scope.bdate,
			caddress : $scope.caddress,
			paddress : $scope.paddress

		};

		$http.post(url, data, config).then(
				function(response) {
					$scope.success = true;
					$scope.error = false;
					$scope.successMessage = 'successful';
					contMSG('Success', 'Employee Reigstration Successful',
							'fa fa-bell', 'primary', 'right');

				},
				function(response) {
					contMSG('Danger', 'Some Error Occured. Try Again..!',
							'fa fa-remove', 'danger', 'center');
				});
	}

	//roles List
	function rolesList() {
		$scope.roless = [];
		var url = 'getroles';
		var config = {
			headers : {
				'Content-Type' : 'application/json;charset=utf-8;'
			}
		}
		$http.get(url).then(function(response) {
			//$scope.getDivAvailable = true;
			$scope.roless = response.data;
			
			console.log("roles: "+response.data);
			
		}, function error(response) {
			$scope.postResultMessage = "Error Status: " + response.statusText;
		});
	}
	rolesList();
	function contMSG(title, msg, icon, state, align) {
		var placementFrom = 'top';
		var placementAlign = align;
		var state = state;
		var content = {};
		content.message = msg;
		content.title = title;
		content.url = '#';
		content.icon = icon;
		$.notify(content, {
			type : state,
			placement : {
				from : placementFrom,
				align : placementAlign
			},
			time : 1000,
			delay : 2000,
		});
	}
	

  function employeelist() {
		//$scope.uid
		$rootScope.$emit('empEmit', null);
	}
	
  employeelist();


	//find all employee
	 $scope.userlist = function(id)
	 {
		 $scope.userid = id;
		 //alert(id +"userid");
		$scope.empList = {};
		var url = 'empbyid/'+id;
		var config = {
			headers : {
				'Content-Type' : 'application/json;charset=utf-8;'
			}
		}
		$http.get(url).then(function(response) {
		
			//$scope.empList = response.data;
			//$scope.id = response.data.id;
			$scope.name=response.data.name;
			$scope.bdate1 = response.data.bdate;
			$scope.caddress = response.data.caddress;
			$scope.contactnumber = response.data.contactnumber;
			$scope.email=response.data.email;
			$scope.gender=response.data.gender;
			$scope.paddress=response.data.paddress;
			$scope.password=response.data.password;
			$scope.posts=response.data.posts;
			$scope.roles = response.data.roles;
			$scope.roles.id = response.data.roles.id;
			$scope.bdate =  moment($scope.bdate1).format('DD/MM/YYYY');
			//roles : $scope.roles,
			console.log($scope.roles.name +"roles name");
			console.log(JSON.stringify(response.data) +"employee details");
		//	$scope.userid = response.data.id;
			console.log($scope.userid +" $scope.userid");
		}, function error(response) {
			$scope.postResultMessage = "Error Status: " + response.statusText;
		});

	};
	
	
	//find all employee
	 $scope.employeelist = function()
	 {
		 //alert(id +"userid");
		$scope.empList1 = {};
		var url = 'getempList';
		var config = {
			headers : {
				'Content-Type' : 'application/json;charset=utf-8;'
			}
		}
		$http.get(url).then(function(response) {
		
			$scope.empList1 = response.data;
		
			
		}, function error(response) {
			$scope.postResultMessage = "Error Status: " + response.statusText;
		});

	};
	
	
	$scope.employeelist();
	
	
	 $scope.scroll = function () {
	        $window.scrollTo(0, angular.element(document.getElementById('div1')).offsetTop);  
	        // $window.scrollTo(0, 0);  
	      };
	
	
	
	//update employee
	$scope.updateEmployee = function()
	{
		//alert( $scope.userid  +"$scope.userid");
		
		var url = "updateemployee/"+$scope.userid;
		
		var config = {
			headers : {
				'Content-Type' : 'application/json;charset=utf-8;'
			}
		}
		var data = {
			//task_id: $scope.task_id,
			name : $scope.name,
			mid : $scope.mid,
			lastname : $scope.lastname,
			email : $scope.email,
			password : $scope.password,
			roles : $scope.roles,
			email : $scope.email,
			contactnumber : $scope.contactnumber,
			gender : $scope.gender,
			bdate : $scope.bdate,
			caddress : $scope.caddress,
			paddress : $scope.paddress,
		

		};

		$http.post(url, data, config).then(
				function(response) {
					$scope.success = true;
					$scope.error = false;
					$scope.successMessage = 'successful';
					contMSG('Success', 'Employee Update Successful',
							'fa fa-bell', 'primary', 'right');

				},
				function(response) {
					contMSG('Danger', 'Some Error Occured. Try Again..!',
							'fa fa-remove', 'danger', 'center');
				});
	}

	
	
	
	  $('.datepicker-default').datepicker();
	
	/*$('.datepicker').datetimepicker({
		format: 'DD/MM/YYYY',
	});*/
});
