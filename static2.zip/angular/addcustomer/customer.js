myapp.controller("customerCtrl",function($scope,$routeParams,$rootScope,$http, $window, ServiceTaskTracker)
{
	
	var myEl = angular.element( document.querySelector( 'body' ) );
	myEl.removeClass('login');
	var myEl1 = angular.element( document.querySelector( '.wrapper' ) );
	myEl1.removeClass('wrapper-login');
	
	var myEl3 = angular.element( document.querySelector( '.main-header' ) );
	myEl3.css('display','block');

	var myEl4 = angular.element( document.querySelector( '.sidebar' ) );
	myEl4.css('display','block');

	$scope.customer={
			   id:'0',
			   name: '',
			   gender:'',
			   bdate:'01/01/2019',
			   email:'',
			   contactnumber:'',
			   adhaarCard:'',
			   caddress:'',
			   paddress:'',
			  //file:null,
			   property:[{
				   'prop_id':'1',
					area:'',
					address:'',
					category:''
				}]  
	};
	
	
	$scope.addItem=function(){
		  $scope.customer.property.push({
			  prop_id:1,
			  area:'',
			  address:'',
			  category:''
		});
	}
	 $scope.removeItem = function(m){
		// alert(m +"index")
		 $scope.customer.property.splice($scope.customer.property.indexOf(m),1);
			  }
	 // The width and height of the captured photo. We will set the
	  // width to the value defined here, but the height will be
	  // calculated based on the aspect ratio of the input stream.

	  var width = 320;    // We will scale the photo width to this
	  var height = 0;     // This will be computed based on the input stream

	  // |streaming| indicates whether or not we're currently streaming
	  // video from the camera. Obviously, we start at false.

	  var streaming = false;

	  // The various HTML elements we need to configure or control. These
	  // will be set by the startup() function.

	  var video = null;
	  var canvas = null;
	  var photo = null;
	  var startbutton = null;
	  video = document.getElementById('video');
	    canvas = document.getElementById('canvas');
	    photo = document.getElementById('photo');
	    startbutton = document.getElementById('startbutton');
	  function startup() {
	    
	   

	    video.addEventListener('canplay', function(ev){
	      if (!streaming) {
	        height = video.videoHeight / (video.videoWidth/width);
	      
	        // Firefox currently has a bug where the height can't be read from
	        // the video, so we will make assumptions if this happens.
	      
	        if (isNaN(height)) {
	          height = width / (4/3);
	        }
	      
	        video.setAttribute('width', width);
	        video.setAttribute('height', height);
	        canvas.setAttribute('width', width);
	        canvas.setAttribute('height', height);
	        streaming = true;
	      }
	    }, false);

	    startbutton.addEventListener('click', function(ev){
	      takepicture();
	      ev.preventDefault();
	    }, false);
	    
	    clearphoto();
	  }

	  // Fill the photo with an indication that none has been
	  // captured.

	  function clearphoto() {
	    var context = canvas.getContext('2d');
	    context.fillStyle = "#AAA";
	    context.fillRect(0, 0, canvas.width, canvas.height);

	    var data = canvas.toDataURL('image/png');
	    $scope.customer.pic = data;
	    photo.setAttribute('src', data);
	  }
	  
	  // Capture a photo by fetching the current contents of the video
	  // and drawing it into a canvas, then converting that to a PNG
	  // format data URL. By drawing it on an offscreen canvas and then
	  // drawing that to the screen, we can change its size and/or apply
	  // other changes before drawing it.

	  $scope.takepicture1 = function() {
		//  alert("hi");
		  height = video.videoHeight / (video.videoWidth/width);
	      
	        // Firefox currently has a bug where the height can't be read from
	        // the video, so we will make assumptions if this happens.
	      
	        if (isNaN(height)) {
	          height = width / (4/3);
	        }
	      
	        video.setAttribute('width', width);
	        video.setAttribute('height', height);
	        canvas.setAttribute('width', width);
	        canvas.setAttribute('height', height);
		  navigator.mediaDevices.getUserMedia({video: true, audio: false})
		    .then(function(stream) {
		      video.srcObject = stream;
		      video.play();
		    })
		    .catch(function(err) {
		      console.log("An error occurred: " + err);
		    });
	  }
	  $scope.takepicture = function() {
		 // alert("hi");
		
	    var context = canvas.getContext('2d');
	    if (width && height) {
	      canvas.width = width;
	      canvas.height = height;
	      context.drawImage(video, 0, 0, width, height);
	    
	      var data = canvas.toDataURL('image/png');
	      $scope.imgs = data;
	      photo.setAttribute('src', data);
	    } else {
	      clearphoto();
	    }
	  }

	  // Set up our event listener to run the startup process
	  // once loading is complete.
	 // window.addEventListener('load', startup, false);	   
	
	$scope.addcustomer = function()
	{
		
		//var url = "/customerregistration";
		//alert("in method");
		var formData = new FormData();
		
	      var file = $scope.myFile;
	      
	      var json = $scope.myJson;
	      
	      formData.append("file", file);
	      
          formData.append("customer", angular.toJson(data.customer));  

	    //  formData.append("ad",JSON.stringify(json));//important: convert to string JSON!
	      
	      var req = {
	        url: '/customerregistration',
	        method: 'POST',
	        headers: {'Content-Type': undefined},
	        data: formData,
	        transformRequest: function (data, headersGetterFunction) {
	          return data;
	        }
		
		
		/*var config = {
         
        }
		
		console.log("bdate "+$('#bdate').val());	

		 $scope.submitValue = $scope.customer.name;
		$scope.customer.bdate =$('#bdate').val();
		var data = JSON.stringify($scope.customer);
		$http.post(url, data, config).then(function (response) {
			 $scope.success = true;
			    $scope.error = false;
			    $scope.successMessage = 'successful';
			    contMSG('Success', 'Customer Added Successfully', 'fa fa-check','success','right');
			    
		}, function (response) {
			contMSG('Error', 'Some Error Occured. Try Again..!', 'fa fa-remove','danger','center');
		});
		
		$scope.firstname = "";
		$scope.lastname = "";*/
  }
	}
	
});