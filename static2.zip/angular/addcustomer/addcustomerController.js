myapp.controller("addcustomerController",function($scope,$routeParams,$rootScope,$http, $window, ServiceTaskTracker)
{
	
	var myEl = angular.element( document.querySelector( 'body' ) );
	myEl.removeClass('login');
	var myEl1 = angular.element( document.querySelector( '.wrapper' ) );
	myEl1.removeClass('wrapper-login');
	
	var myEl3 = angular.element( document.querySelector( '.main-header' ) );
	myEl3.css('display','block');

	var myEl4 = angular.element( document.querySelector( '.sidebar' ) );
	myEl4.css('display','block');
	

/*	function($scope) {
        $rootScope.$on("CallAddcustomer", function(){
           $scope.addcustomer();
        });
	*/
	$scope.adhaarCard ="";
	
	$scope.customer={
			   id:'0',
			   name: '',
			   gender:'',
			   bdate:'01/01/2019',
			   email:'',
			   contactnumber:'',
			   adhaarCard:'',
			   caddress:'',
			   paddress:'',
			   pic:'',
			  //file:null,
			   property:[{
				   'prop_id':'1',
					area:'',
					address:'',
					category:''
				}]  
	};
	
	$scope.addItem=function(){
		  $scope.customer.property.push({
			  prop_id:1,
			  area:'',
			  address:'',
			  category:''
		});
	}
	 $scope.removeItem = function(m){
		// alert(m +"index")
		 $scope.customer.property.splice($scope.customer.property.indexOf(m),1);
			  }

	 
	 $scope.getdetails = function () {

			   $scope.customerlist = [];
			   
			   var url = '/getallcustomers'+$scope.adhaarCard;
				
				var config = {
		               headers : {
		                   'Content-Type': 'application/json;charset=utf-8;'
		               }
		       }
				$http.get(url).then(function (response) {
					
					$scope.customerlist = response.data;
					$scope.adhaarCard = $scope.customerlist[0].adhaarCard;
					$scope.bdate = $scope.customerlist[0].bdate;
					$scope.caddress = $scope.customerlist[0].caddress;
					$scope.contactnumber = $scope.customerlist[0].contactnumber;
					$scope.email = $scope.customerlist[0].emaile;
					$scope.gender = $scope.customerlist[0].gender;
					$scope.name = $scope.customerlist[0].name;
					$scope.paddress = $scope.customerlist[0].paddress;
					$scope.updatedate = $scope.customerlist[0].updatedate;
					console.log(response.data);
				}, function error(response) {
					$scope.postResultMessage = "Error Status: " +  response.statusText;
				});
			  
			  }
	 
	//Success msg
		function contMSG(title, msg, icon,state,align) {
			var placementFrom = 'top';
			var placementAlign = align;
			var state = state;
			var content = {};
			content.message = msg;
			content.title = title;
			content.url = '#';
			content.icon = icon;
			$.notify(content, {
				type : state,
				placement : {
					from : placementFrom,
					align : placementAlign
				},
				time : 1000,
				delay : 2000,
			});
		} 
		
		/*
		$('.datepicker').datetimepicker({
			format: 'DD/MM/YYYY',
		});
		*/
		
		
		
		
		
		
		

			  // The width and height of the captured photo. We will set the
			  // width to the value defined here, but the height will be
			  // calculated based on the aspect ratio of the input stream.

			  var width = 320;    // We will scale the photo width to this
			  var height = 0;     // This will be computed based on the input stream

			  // |streaming| indicates whether or not we're currently streaming
			  // video from the camera. Obviously, we start at false.

			  var streaming = false;

			  // The various HTML elements we need to configure or control. These
			  // will be set by the startup() function.

			  var video = null;
			  var canvas = null;
			  var photo = null;
			  var startbutton = null;
			  video = document.getElementById('video');
			    canvas = document.getElementById('canvas');
			    photo = document.getElementById('photo');
			    startbutton = document.getElementById('startbutton');
			  function startup() {
			    
			   

			    video.addEventListener('canplay', function(ev){
			      if (!streaming) {
			        height = video.videoHeight / (video.videoWidth/width);
			      
			        // Firefox currently has a bug where the height can't be read from
			        // the video, so we will make assumptions if this happens.
			      
			        if (isNaN(height)) {
			          height = width / (4/3);
			        }
			      
			        video.setAttribute('width', width);
			        video.setAttribute('height', height);
			        canvas.setAttribute('width', width);
			        canvas.setAttribute('height', height);
			        streaming = true;
			      }
			    }, false);

			    startbutton.addEventListener('click', function(ev){
			      takepicture();
			      ev.preventDefault();
			    }, false);
			    
			    clearphoto();
			  }

			  // Fill the photo with an indication that none has been
			  // captured.

			  function clearphoto() {
			    var context = canvas.getContext('2d');
			    context.fillStyle = "#AAA";
			    context.fillRect(0, 0, canvas.width, canvas.height);

			    var data = canvas.toDataURL('image/png');
			    photo.setAttribute('src', data);
			  }
			  
			  // Capture a photo by fetching the current contents of the video
			  // and drawing it into a canvas, then converting that to a PNG
			  // format data URL. By drawing it on an offscreen canvas and then
			  // drawing that to the screen, we can change its size and/or apply
			  // other changes before drawing it.

			  $scope.takepicture1 = function() {
				//  alert("hi");
				  height = video.videoHeight / (video.videoWidth/width);
			      
			        // Firefox currently has a bug where the height can't be read from
			        // the video, so we will make assumptions if this happens.
			      
			        if (isNaN(height)) {
			          height = width / (4/3);
			        }
			      
			        video.setAttribute('width', width);
			        video.setAttribute('height', height);
			        canvas.setAttribute('width', width);
			        canvas.setAttribute('height', height);
				  navigator.mediaDevices.getUserMedia({video: true, audio: false})
				    .then(function(stream) {
				      video.srcObject = stream;
				      video.play();
				    })
				    .catch(function(err) {
				      console.log("An error occurred: " + err);
				    });
			  }
			  
			  var myimgss ;
			  
			  function base64toBlob(base64Data, contentType) {
				    contentType = contentType || '';
				    var sliceSize = 1024;
				    var byteCharacters = atob(base64Data);
				    var bytesLength = byteCharacters.length;
				    var slicesCount = Math.ceil(bytesLength / sliceSize);
				    var byteArrays = new Array(slicesCount);

				    for (var sliceIndex = 0; sliceIndex < slicesCount; ++sliceIndex) {
				        var begin = sliceIndex * sliceSize;
				        var end = Math.min(begin + sliceSize, bytesLength);

				        var bytes = new Array(end - begin);
				        for (var offset = begin, i = 0; offset < end; ++i, ++offset) {
				            bytes[i] = byteCharacters[offset].charCodeAt(0);
				        }
				        byteArrays[sliceIndex] = new Uint8Array(bytes);
				    }
				    return new Blob(byteArrays, { type: contentType });
				}
			
			  $scope.takepicture = function() {
				//  alert("hi");
				
			    var context = canvas.getContext('2d');
			    if (width && height) {
			      canvas.width = width;
			      canvas.height = height;
			      context.drawImage(video, 0, 0, width, height);
			    
			      var data = canvas.toDataURL('image/png');
			      photo.setAttribute('src', data);
			     //myimgss = data;
			     myimgss = data.replace(/^data:image\/(png|jpg);base64,/, "")
			      $scope.file = data.replace(/^data:image\/(png|jpg);base64,/, "");
			     $scope.customer.file = data.replace(/^data:image\/(png|jpg);base64,/, "");
			     $scope.customer.pic = data.replace(/^data:image\/(png|jpg);base64,/, "");
			     
			     //$scope.customer.pic = data;
			     video.srcObject.getVideoTracks().forEach(track => track.stop());
			      
			    } else {
			      clearphoto();
			    }
			  }

			  // Set up our event listener to run the startup process
			  // once loading is complete.
			 // window.addEventListener('load', startup, false);
			  function base64toBlob(base64Data, contentType) 
			  {
				    contentType = contentType || '';
				    var sliceSize = 1024;
				    var byteCharacters = atob(base64Data);
				    var bytesLength = byteCharacters.length;
				    var slicesCount = Math.ceil(bytesLength / sliceSize);
				    var byteArrays = new Array(slicesCount);

				    for (var sliceIndex = 0; sliceIndex < slicesCount; ++sliceIndex) {
				        var begin = sliceIndex * sliceSize;
				        var end = Math.min(begin + sliceSize, bytesLength);

				        var bytes = new Array(end - begin);
				        for (var offset = begin, i = 0; offset < end; ++i, ++offset) {
				            bytes[i] = byteCharacters[offset].charCodeAt(0);
				        }
				        byteArrays[sliceIndex] = new Uint8Array(bytes);
				    }
				    return new Blob(byteArrays, { type: contentType });
			 }
			 
			
			  $scope.addcustomer = function(){
				  var url = "/customerregistration";
					
					var config = {
							 // transformRequest: angular.identity,
						      // transformResponse: angular.identity,
						        headers: {
						         // 'Content-Type': undefined
						        }
			         
			        }
					
					// console.log("bdate "+$('#bdate').val());
					
					
					
					// var data = new data();
					 $scope.submitValue = $scope.customer.name;
					 
					   var data = new FormData();
					   // data.append('pic', $scope.customer.pic);
					   // data.append('customer',JSON.stringify($scope.customer));
					   // $scope.pic =
					    // var data11 = $scope.customer.pic.toDataURL();
					    // $scope.customer.pic =
						// data11.replace(/^data:image\/(png|jpg);base64,/, "");
						
					
					   var data  = JSON.stringify($scope.customer);
					   // var data = $scope.customer;
					  // data.append("customer",$scope.customer);
					   // data.append("pic",$scope.customer.pic);
					    
						// data.append('photo',
						// $("#photo")[0].$scope.customer.pic[0]);
						/* data.append('customer', $scope.customer.pic) */
					$http.post(url, data, config).then(function (response) {
						// console.log( $scope.customer.name+"name of customer"
						// +response.data.name);
						 $scope.customer.id = response.data.id;
						 $scope.success = true;
						    $scope.error = false;
						    $scope.successMessage = 'successful';
						    contMSG('Success', 'Customer Added Successfully', 'fa fa-check','success','right');
						    $scope.showDiv=true;
					}, function (response) {
						//console.log(JSON.stringify($scope.customer));
						$scope.showDiv=false;
						contMSG('Error', 'Some Error Occured. Try Again..!', 'fa fa-remove','danger','right');
					});
					
					$scope.firstname = "";
					$scope.lastname = "";
			  }
			/* $upload.upload({
				    url : 'customerregistration',
				    file : file,
				    data : $scope.customer,
				    method : 'POST'
				});
			 
			  */
			  
			  
			  
			/* $scope.addcustomer = function(){
					  var url = "/customerregistration";
					  var contentTypess = 'image/png';
						var config = {
				         
								
							      headers: {
							        // 'Content-Type': 'application/octet-stream'
							    	//  'Content-Type': undefined
							    	//  'Content-Type': 'multipart/form-data'
							    	  'Content-Type': 'multipart/form-data;boundary=gc0p4Jq0M2Yt08jU534c0p'
							      },
							      
								    transformResponse: angular.identity,
								    
								    transformRequest: function (data) {
						                var formData = new FormData();
						                //need to convert our json object to a string version of json otherwise
						                // the browser will do a 'toString()' on the object which will result 
						                // in the value '[Object object]' on the server.
						                formData.append("file",data.file);
						                formData.append("customer",data.customer);
						                formData.append("pic",data.pic);
									    
						                formData.append("model", angular.toJson(data.model));
						                //now add all of the assigned files
						                for (var i = 0; i < data.files; i++) {
						                    //add each file to the form data and iteratively name them
						                    formData.append("file" + i, data.files[i]);
						                }
						                return formData;
						            },
						}
						
						console.log("bdate "+$('#bdate').val());	
						var data = {
							"file":base64toBlob(myimgss,contentTypess),
							"customer":$scope.customer
						};
						
						 $scope.submitValue = $scope.customer.name;
					    $scope.customer.bdate =$('#bdate').val();
					  //  var form = $('#addcust')[0];
					    //var form = $('#fileUploadForm')[0];
                   console.log(myimgss);
                   console.log($scope.pic);
					    //var data = new FormData();
					    data.append("file",base64toBlob(myimgss,contentTypess));
					    data.append("customer",JSON.stringify($scope.customer));
					    fdata.append("customer", new Blob([JSON.stringify(
						    	$scope.customer
				            )], {
				                    type: "application/json"
				                }));
					    
					    var fdata = new FormData();
					 //   fdata.append("file", base64toBlob(myimgss,contentTypess));
					    fdata.append("file", $scope.pic);
					    fdata.append("customer", new Blob([JSON.stringify(
					    	$scope.customer
			            )], {
			                    type: "application/json"
			                }));
					    //	var data = JSON.stringify($scope.customer);
//					/	data.append('customer',$scope.customer)
						
					 //  data.append('pic', $scope.pic[0]);
						//data.append('customer',JSON.stringify($scope.customer));
					   data.append('customer', new Blob([JSON.stringify($scope.customer)], {
					        type: "application/json"
					    }));
						
					var data = new Blob([JSON.stringify($scope.customer)], {
				        type: "application/json"
				    });
					console.log(data +"FORM DATA........" +JSON.stringify($scope.data)+"");
					
						$http.post(url, data, config).then(function (response) {
							 $scope.success = true;
							    $scope.error = false;
							    $scope.successMessage = 'successful';
							    contMSG('Success', 'Customer Added Successfully', 'fa fa-check','success','right');
							    
						}, function (response) {
							contMSG('Error', 'Some Error Occured. Try Again..!', 'fa fa-remove','danger','center');
						});
						
						$scope.firstname = "";
						$scope.lastname = "";
				  }		
	*/
			  
			  $('.datepicker-default').datepicker();

});