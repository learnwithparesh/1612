myapp.controller("reportsController",function($scope, $http, $window,$localStorage, $filter,$compile,$routeParams,ServiceTaskTracker, $routeParams) {
	

	var myEl = angular.element( document.querySelector( 'body' ) );
	myEl.removeClass('login');
	var myEl1 = angular.element( document.querySelector( '.wrapper' ) );
	myEl1.removeClass('wrapper-login');
	
	var myEl3 = angular.element( document.querySelector( '.main-header' ) );
	myEl3.css('display','block');

	var myEl4 = angular.element( document.querySelector( '.sidebar' ) );
	myEl4.css('display','block');
	
	$scope.uid = $localStorage.message;
	$scope.roleid = $localStorage.roleid;
   $scope.startd ="";
   $scope.endd="";
   
	$scope.tasklist = [];
	function fetchtask()
	{
		//$scope.tasklist = [];
		var url = "showtask1/" + $scope.uid + "/" + $scope.roleid;
		var config = {
			headers : {
				'Content-Type' : 'application/json;charset=utf-8;'
			}
		}
		$http.get(url).then(function(response) {
			$scope.tasklist = response.data;
		// $scope.startd = $scope.tasklist[0].startDate;
			 $scope.endd = $scope.tasklist[0].endDate;
		}, function error(response) {
			$scope.postResultMessage = "Error Status: " + response.statusText;
		});
	}
	fetchtask();
	
	$scope.datepicker_from="08/07/2019";
	$scope.datepicker_to="08/07/2019";
	
	 /* $scope.startDate="2016-08-01";
	  $scope.endDate="2016-08-03";*/
	
	$scope.startDate="";
	$scope.endDate="";
	 var dTable;
	 var table;
	 setTimeout(function(){
	    angular.element(document).ready( function () {
	        dTable = $('#search_table');
	        table = dTable.DataTable();
	    });
	 },1000);
	    $(function(){
	    	  $('#filter').on('click', function(e){
	    	    e.preventDefault();
	    	    var startDate = $('#start').val(),
	    	        endDate = $('#end').val();
	    	      
	    	   
	    	    $scope.startDate = startDate;
	    	    $scope.endDate = endDate;
	    	    
	    	    console.log($scope.startDate +"startDate" +$scope.endDate +"");
	    	    
	    	    filterByDate(1, startDate, endDate); // We call our filter function
	    	    //table.draw();
	    	    dTable.dataTable().fnDraw(); // Manually redraw the table after filtering
	    	  });
	    	  
	    	  $scope.myFilter = function (startDate) { 
	    		//  console.log($scope.startd +"$scope.startd")
	    		   $scope.startd=  moment($scope.startd).format("DD/MM/YYYY");
	    		  $scope.endd=  moment($scope.endd).format("DD/MM/YYYY");
		    	 // return $scope.startDate ===  $scope.startd || $scope.endDate === $scope.endd; 
		    	  return $scope.startDate ===  "01/07/2019"|| $scope.endDate === "31/07/2019"; 

		    	};
	    	  
	    	  // Clear the filter. Unlike normal filters in Datatables,
	    	  // custom filters need to be removed from the afnFiltering array.
	    	  $('#clearFilter').on('click', function(e){
	    	    e.preventDefault();
	    	    $.fn.dataTableExt.afnFiltering.length = 0;
	    	    //table.draw();
	    	    dTable.dataTable().fnDraw();
	    	  });
	    	  
	    	});

	    	/* Our main filter function
	    	 * We pass the column location, the start date, and the end date
	    	 */
	    	var filterByDate = function(column, startDate, endDate) {
	    	  // Custom filter syntax requires pushing the new filter to the global filter array
	    			$.fn.dataTableExt.afnFiltering.push(
	    			   	function( oSettings, aData, iDataIndex ) {
	    			   		var rowDate = normalizeDate(aData[column]),
	    	              start = normalizeDate(startDate),
	    	              end = normalizeDate(endDate);
	    	          
	    	          // If our date from the row is between the start and end
	    	         //if (start <= rowDate && rowDate <= end) {
	    	      	/* if(start <= $scope.startd &&  $scope.endd <= end){
	    	            return true;
	    	          } else if ($scope.startd >= start && end === '' && start !== ''){
	    	            return true;
	    	          } else if ($scope.endd <= end && start === '' && end !== ''){
	    	            return true;
	    	          } else {
	    	            return false;
	    	          }*/
	    			   		$scope.startd=  moment($scope.startd).format("DD/MM/YYYY");
	  	   	    		    $scope.endd=  moment($scope.endd).format("DD/MM/YYYY");
	  	   	    		    
	  	   	    		 
	  	   	    		/*angular.forEach($scope.tasklist, function(value, key)
	  	   	    				 {
	  	   	    			
	  	   	    		$scope.startd =  $scope.tasklist[0].startDate;
	  	   	    	     $scope.endd  =  $scope.tasklist[0].endDate;*/
	  	   	    		//$scope.startd=  moment($scope.startd).format("DD/MM/YYYY");
  	   	    		   // $scope.endd=  moment($scope.endd).format("DD/MM/YYYY");
  	   	    		    //console.log($scope.startd +"$scope.startd" + $scope.endd +"$scope.endd");
	  	   	    		/*  if($scope.startDate != "" ||$scope.endDate !="")
	  	   	    		   {
	  	   	    			  
	  	   	    		    return true;
	  	   	    		   }*/
	  	   	    		  if(($scope.startDate >= $scope.startd && $scope.endDate >= $scope.endd) )
	  	   	    			  {
	  	   	    			
	  	   	    			  return true;
	  	   	    			  }
	  	   	    		 /*if($scope.endDate > $scope.endd || $scope.endDate == $scope.endd)
 	   	    			  {
	  	   	    			
 	   	    			  return true;
 	   	    			  }*/
	  	   	    		 
	  	   	           // });
	  	   	    		  
	  	   	    		 /* if($scope.startDate >= $scope.startd && $scope.endDate >= $scope.endd)
	  	   	    			  {
	  	   	    			  return true;
	  	   	    			  }*/
	    	        }
	    			);
	    		};

	    	// converts date strings to a Date object, then normalized into a YYYYMMMDD format (ex: 20131220). Makes comparing dates easier. ex: 20131220 > 20121220
	    	var normalizeDate = function(dateString) {
	    	  var date = new Date(dateString);
	    	  var normalized = date.getFullYear() + '' + (("0" + (date.getMonth() + 1)).slice(-2)) + '' + ("0" + date.getDate()).slice(-2);
	    	  return normalized;
	    	}

	   
	/*$('.datepicker').datetimepicker({
		format: 'DD/MM/YYYY',
	});
   
	*/
 })
 
 myapp.filter("myfilter", function($filter) {
      return function(items, from, to) {
            return $filter('filter')(items, "name", function(v){
              var date  = moment(v);
              return date >= moment(from) && date <= moment(to);
            });
      };
    });

