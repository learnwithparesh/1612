myapp.controller("bodyController", function($scope, $http, $window, $route, ServiceTaskTracker) {
	
	$scope.mytext1 = $route.current.mytext1;
	$scope.mytext = $route.current.mytext;

});
