myapp.controller("loginController", function($scope, $http, $window, $route,
		$routeParams, $localStorage, ServiceTaskTracker,$rootScope) {

	// $scope.uid = $routeParams.id;

	/*var myEl = angular.element( document.querySelector( 'body' ) );
	myEl.addClass('login');
	
	
	$scope.mytext1 = $route.current.mytext1;*/

/*	var myEl = angular.element(document.querySelector('body'));
	myEl.addClass('login');
	var myEl1 = angular.element(document.querySelector('.wrapper'));
	myEl1.addClass('wrapper-login');
	$scope.mytext1 = 'wrapper-login';
	$scope.mytext = 'logins';

	var myEl3 = angular.element(document.querySelector('.main-header'));
	myEl3.css('display', 'none');

	var myEl4 = angular.element(document.querySelector('.sidebar'));
	myEl4.css('display', 'none');
*/
	
	//window.onpopstate = function (e) { window.history.forward(1); }
	//window.onbeforeunload = function() { window.history.forward(1); };
	/*history.pushState(null, null, location.href);
    window.onpopstate = function () {
        history.go(1);
    };
*/

	history.pushState(null, null, location.href);
    window.onpopstate = function () {
        history.go(1);
    };
	
	var myEl3 = angular.element(document.querySelector('.main-header'));
	myEl3.css('display', 'none');

	var myEl4 = angular.element(document.querySelector('.sidebar'));
	myEl4.css('display', 'none');
	
	
	//$rootScope.$emit('loginControllerEmit', 'hide navbar');
	
	 angular.element(document).ready(function () {
	        $rootScope.$emit('loginControllerEmit', 'hide navbar');
	    });
	$scope.submitForm = function() {

		$http({
			method : 'POST',
			url : '/myLogin1',
			data : $scope.employee
		}).then(
				function(response) {
					$scope.content = response.data;
					console.log(response.data);
					console.log(response.data.rsd);

					if (response.data.rsd == 'success') {
						contMSG('Success', 'Login Successful', 'fa fa-check',
								'success', 'center');
						ServiceTaskTracker.setId(response.data.id);

						ServiceTaskTracker.setName(response.data.name);
						
						//storageService.save('uid', response.data.id);
						sessionStorage.setItem('uid', response.data.id);
						sessionStorage.setItem('rid', response.data.roles.id);
						
						$localStorage.message = response.data.id;
						$localStorage.roleid = response.data.roles.id;
                      // console.log()
						
						$window.location.href = '#!empdashboard';
					} else {
						contMSG('Warning',
								'Username or Password Does Not Match ...!!!',
								'fa fa-exclamation-triangle', 'danger',
								'center');
					}

					$scope.count++;
				}, function(error) {
					console.log(error, 'can not get data.');
				});

	};
	
	/*function showPassword(s) {
		var e = $(s).parent().find("input");
		"password" === e.attr("type") ? e.attr("type", "text") : e.attr(
				"type", "password")
	}
	$(function() {
		$(".show-password").on("click", function(event) {
			event.preventDefault();
			alert("hi sonia" );
			
			showPassword(this);
		});
	});*/
	
	
	 $scope.inputType = 'password';
	  $scope.showHideClass = 'glyphicon glyphicon-eye-open';

	  $scope.showPassword = function(){
		  
		  
	   if($scope.employee.password != null)
	   {
	    if($scope.inputType == 'password')
	    {
	     $scope.inputType = 'text';
	     $scope.showHideClass = 'glyphicon glyphicon-eye-close';
	    }
	    else
	    {
	     $scope.inputType = 'password';
	     $scope.showHideClass = 'glyphicon glyphicon-eye-open';
	    }
	   }
	  };
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	function contMSG(title, msg, icon, state, align) {
		var placementFrom = 'top';
		var placementAlign = align;
		var state = state;
		var content = {};
		content.message = msg;
		content.title = title;
		content.url = '#';
		content.icon = icon;
		$.notify(content, {
			type : state,
			placement : {
				from : placementFrom,
				align : placementAlign
			},
			time : 1000,
			delay : 2000,
		});
	}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	
/*$scope.logOut=function(){		
	 $window.localStorage.clear();
		//localStorage.removeItem($localStorage.roleid);
	}*/
});
