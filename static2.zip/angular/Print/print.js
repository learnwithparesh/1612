myapp.controller("printCtrl", function($scope, $http, $window,$route,
	$localStorage, $filter, $compile, ServiceTaskTracker, $routeParams, $timeout,$translate,$rootScope) {
	
	
	
	var myEl = angular.element(document.querySelector('body'));
	myEl.removeClass('login');
	var myEl1 = angular.element(document.querySelector('.wrapper'));
	myEl1.removeClass('wrapper-login');

	var myEl3 = angular.element(document.querySelector('.main-header'));
	myEl3.css('display', 'block');

	var myEl4 = angular.element(document.querySelector('.sidebar'));
	myEl4.css('display', 'block');

	//task details for edit...
	 $scope.task ={
	    		//customer:$scope.customer,
				//project: $scope.project,
				startDate:'',
				endDate:'',
				final_date:'',
				complete_date:'',
				filesid:'',
				color: '#007bffb8',
				status: 3,
				insert_by:'',
				insert_date:'',
				update_by:'',
				update_date:'',
				tname:'',
				task_type:1,
				assignto:{},
				arrivedfrom:'',
				branch:'',
				caseno:'',
				tapal:'',
				//संदर्भ
				inwordno:'',
				inworddate:'',
				letterdate:'',
				arrivedfrom:'',
				branch:'',
				sender:'',
				lettertype:'',
			
				lettersubject:'',
				letterdeliverytype:'',
			
				
				//workflow: '',
				//property_id : $scope.property.id,
				tasktype:{
					id : 0
				},
					
			//	employee:{}
	    }
	
	
	 function papdetails1()
	   {
	 //     console.log(sessionStorage.getItem("taskid") +"sessionStorage.getItem>>>>>>>>>>>>>>>>>");
	      
		   var url = 'showtaskbyid1/'+sessionStorage.getItem("taskid");
			
			var config = {
	               headers : {
	                   'Content-Type': 'application/json;charset=utf-8;'
	               }
	       }
			$http.get(url).then(function (response) {
			
				$scope.task =response.data;
			//	console.log(JSON.stringify(response.data)+"in print daatttttttt");
			//console.log(JSON.stringify($scope.task) +"in print");
				
			}, function error(response) {
				$scope.postResultMessage = "Error Status: " +  response.statusText;
			});
		  
	    }
		 papdetails1();
    
    
    
});