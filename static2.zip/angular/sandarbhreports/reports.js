myapp.controller("sandrabhreportsController",function($scope, $http, $window,$localStorage, $filter,$rootScope,$compile,$routeParams,ServiceTaskTracker, $routeParams, DTOptionsBuilder, DTColumnBuilder,DTColumnDefBuilder ) {
	

	var myEl = angular.element( document.querySelector( 'body' ) );
	myEl.removeClass('login');
	var myEl1 = angular.element( document.querySelector( '.wrapper' ) );
	myEl1.removeClass('wrapper-login');
	
	var myEl3 = angular.element( document.querySelector( '.main-header' ) );
	myEl3.css('display','block');

	var myEl4 = angular.element( document.querySelector( '.sidebar' ) );
	myEl4.css('display','block');
	$scope.uid = $localStorage.message;
	 $scope.roleid =$localStorage.roleid;
   $scope.startd ="";
   $scope.endd="";
   var date = new Date(), y = date.getFullYear(), m = date.getMonth();
   var firstDay = new Date(y, m, 1);
   var lastDay = new Date(y, m + 1, 0);

/*   firstDay = moment(firstDay).format('dd/mm/yyyy');
   lastDay = moment(lastDay).format('dd/mm/yyyy');*/
   
     $scope.date3 = firstDay;
       $scope.date4 = lastDay;
    	//$scope.tasklist = [];
   	$scope.test = function()
	{
		//alert($("#start").val() + ":" +$("#end").val());
		$scope.date3 = $("#start").val().formate(dd/mm/yyyy);
		$scope.date4 = $("#end1").val().formate(dd/mm/yyyy);
		console.log($scope.date3 +" " +$scope.date3);
		$scope.vm.dtInstance.rerender();
	}
	$scope.tasklist = [
		  {
			    "arrivedfrom": "string",
			    "assignto": {
			      "active": 0,
			      "bdate": "dd/MM/yyyy",
			      "caddress": "string",
			      "contactnumber": "string",
			      "email": "string",
			      "empavailable": [
			        {
			          "description": "string",
			          "employee": {},
			          "id": 0,
			          "leavefrom": "dd/MM/yyyy",
			          "leaveto": "dd/MM/yyyy",
			          "meetingetime": "yyyy-MM-dd HH:mm:ss",
			          "meetingstime": "yyyy-MM-dd HH:mm:ss"
			        }
			      ],
			      "gender": "string",
			      "id": 0,
			      "lastName": "string",
			      "mid": "string",
			      "name": "string",
			      "orgid": 0,
			      "paddress": "string",
			      "password": "string",
			      "posts": "string",
			      "roles": {
			        "description": "string",
			        "id": 0,
			        "role_name": "string"
			      }
			    },
			    "branch": "string",
			    "caseno": "string",
			    "casestartdate": "2019-11-23T01:29:16.552Z",
			    "casesubject": "string",
			    "casesubmissiondate": "dd/MM/yyyy",
			    "color": "string",
			    "complete_date": "dd/MM/yyyy",
			    "curtnotification": "string",
			    "customer": {
			      "adhaarCard": "string",
			      "bdate": "dd/MM/yyyy",
			      "c_address": "string",
			      "contact_number": "string",
			      "email": "string",
			      "gender": "string",
			      "id": 0,
			      "name": "string",
			      "p_address": "string",
			      "pic": "string",
			      "property": [
			        {
			          "address": "string",
			          "courtcaseno": "string",
			          "courtname": "string",
			          "courtstatus": "string",
			          "description": "string",
			          "filesid": "string",
			          "id": 0,
			          "insertdate": "2019-11-23T01:29:16.552Z",
			          "nexthearing": "string",
			          "otherowner": "string",
			          "propid": "string",
			          "villages": {
			            "id": 0,
			            "villagename": "string"
			          }
			        }
			      ],
			      "update_date": "2019-11-23T01:29:16.552Z"
			    },
			    "endDate": "dd/MM/yyyy",
			    "filesid": "string",
			    "final_date": "dd/MM/yyyy",
			    "id": 0,
			    "insert_by": "string",
			    "insert_date": "2019-11-23T01:29:16.552Z",
			    "inworddate": "2019-11-23T01:29:16.552Z",
			    "inwordno": "string",
			    "lastassign": {
			      "active": 0,
			      "bdate": "dd/MM/yyyy",
			      "caddress": "string",
			      "contactnumber": "string",
			      "email": "string",
			      "empavailable": [
			        {
			          "description": "string",
			          "employee": {},
			          "id": 0,
			          "leavefrom": "dd/MM/yyyy",
			          "leaveto": "dd/MM/yyyy",
			          "meetingetime": "yyyy-MM-dd HH:mm:ss",
			          "meetingstime": "yyyy-MM-dd HH:mm:ss"
			        }
			      ],
			      "gender": "string",
			      "id": 0,
			      "lastName": "string",
			      "mid": "string",
			      "name": "string",
			      "orgid": 0,
			      "paddress": "string",
			      "password": "string",
			      "posts": "string",
			      "roles": {
			        "description": "string",
			        "id": 0,
			        "role_name": "string"
			      }
			    },
			    "letterdate": "2019-11-23T01:29:16.552Z",
			    "letterdeliverytype": "string",
			    "lettersubject": "string",
			    "lettertype": "string",
			    "nextfinaldate": "2019-11-23T01:29:16.552Z",
			    "noticolor": "string",
			    "papchecked": "string",
			    "project": {
			      "address": "string",
			      "code": "string",
			      "desc1": "string",
			      "endDate": "dd/MM/yyyy",
			      "filesid": "string",
			      "id": 0,
			      "insert_by": 0,
			      "insert_date": "2019-11-23T01:29:16.552Z",
			      "prname": "string",
			      "projectteams": [
			        {
			          "employee": {
			            "active": 0,
			            "bdate": "dd/MM/yyyy",
			            "caddress": "string",
			            "contactnumber": "string",
			            "email": "string",
			            "empavailable": [
			              {
			                "description": "string",
			                "employee": {},
			                "id": 0,
			                "leavefrom": "dd/MM/yyyy",
			                "leaveto": "dd/MM/yyyy",
			                "meetingetime": "yyyy-MM-dd HH:mm:ss",
			                "meetingstime": "yyyy-MM-dd HH:mm:ss"
			              }
			            ],
			            "gender": "string",
			            "id": 0,
			            "lastName": "string",
			            "mid": "string",
			            "name": "string",
			            "orgid": 0,
			            "paddress": "string",
			            "password": "string",
			            "posts": "string",
			            "roles": {
			              "description": "string",
			              "id": 0,
			              "role_name": "string"
			            }
			          },
			          "id": 0,
			          "project": {}
			        }
			      ],
			      "startDate": "dd/MM/yyyy",
			      "teamhead": {
			        "active": 0,
			        "bdate": "dd/MM/yyyy",
			        "caddress": "string",
			        "contactnumber": "string",
			        "email": "string",
			        "empavailable": [
			          {
			            "description": "string",
			            "employee": {},
			            "id": 0,
			            "leavefrom": "dd/MM/yyyy",
			            "leaveto": "dd/MM/yyyy",
			            "meetingetime": "yyyy-MM-dd HH:mm:ss",
			            "meetingstime": "yyyy-MM-dd HH:mm:ss"
			          }
			        ],
			        "gender": "string",
			        "id": 0,
			        "lastName": "string",
			        "mid": "string",
			        "name": "string",
			        "orgid": 0,
			        "paddress": "string",
			        "password": "string",
			        "posts": "string",
			        "roles": {
			          "description": "string",
			          "id": 0,
			          "role_name": "string"
			        }
			      },
			      "update_by": 0,
			      "update_date": "2019-11-23T01:29:16.552Z"
			    },
			    "property_id": "string",
			    "sender": "string",
			    "startDate": "2019-11-23T01:29:16.552Z",
			    "status": 0,
			    "tapal": 0,
			    "tasktype": {
			      "description": "string",
			      "id": 0,
			      "ttype": "string"
			    },
			    "tname": "string",
			    "ttype": 0,
			    "update_by": 0,
			    "update_date": "dd/MM/yyyy",
			    "workflow": [
			      {
			        "date_assigned": "2019-11-23T01:29:16.552Z",
			        "description": "string",
			        "id": 0,
			        "noticode": "string",
			        "nstatus": "string",
			        "task": {
			          "arrivedfrom": "string",
			          "assignto": {
			            "active": 0,
			            "bdate": "dd/MM/yyyy",
			            "caddress": "string",
			            "contactnumber": "string",
			            "email": "string",
			            "empavailable": [
			              {
			                "description": "string",
			                "employee": {},
			                "id": 0,
			                "leavefrom": "dd/MM/yyyy",
			                "leaveto": "dd/MM/yyyy",
			                "meetingetime": "yyyy-MM-dd HH:mm:ss",
			                "meetingstime": "yyyy-MM-dd HH:mm:ss"
			              }
			            ],
			            "gender": "string",
			            "id": 0,
			            "lastName": "string",
			            "mid": "string",
			            "name": "string",
			            "orgid": 0,
			            "paddress": "string",
			            "password": "string",
			            "posts": "string",
			            "roles": {
			              "description": "string",
			              "id": 0,
			              "role_name": "string"
			            }
			          },
			          "branch": "string",
			          "caseno": "string",
			          "casestartdate": "2019-11-23T01:29:16.552Z",
			          "casesubject": "string",
			          "casesubmissiondate": "dd/MM/yyyy",
			          "color": "string",
			          "complete_date": "dd/MM/yyyy",
			          "curtnotification": "string",
			          "customer": {
			            "adhaarCard": "string",
			            "bdate": "dd/MM/yyyy",
			            "c_address": "string",
			            "contact_number": "string",
			            "email": "string",
			            "gender": "string",
			            "id": 0,
			            "name": "string",
			            "p_address": "string",
			            "pic": "string",
			            "property": [
			              {
			                "address": "string",
			                "courtcaseno": "string",
			                "courtname": "string",
			                "courtstatus": "string",
			                "description": "string",
			                "filesid": "string",
			                "id": 0,
			                "insertdate": "2019-11-23T01:29:16.552Z",
			                "nexthearing": "string",
			                "otherowner": "string",
			                "propid": "string",
			                "villages": {
			                  "id": 0,
			                  "villagename": "string"
			                }
			              }
			            ],
			            "update_date": "2019-11-23T01:29:16.552Z"
			          },
			          "endDate": "dd/MM/yyyy",
			          "filesid": "string",
			          "final_date": "dd/MM/yyyy",
			          "id": 0,
			          "insert_by": "string",
			          "insert_date": "2019-11-23T01:29:16.552Z",
			          "inworddate": "2019-11-23T01:29:16.552Z",
			          "inwordno": "string",
			          "lastassign": {
			            "active": 0,
			            "bdate": "dd/MM/yyyy",
			            "caddress": "string",
			            "contactnumber": "string",
			            "email": "string",
			            "empavailable": [
			              {
			                "description": "string",
			                "employee": {},
			                "id": 0,
			                "leavefrom": "dd/MM/yyyy",
			                "leaveto": "dd/MM/yyyy",
			                "meetingetime": "yyyy-MM-dd HH:mm:ss",
			                "meetingstime": "yyyy-MM-dd HH:mm:ss"
			              }
			            ],
			            "gender": "string",
			            "id": 0,
			            "lastName": "string",
			            "mid": "string",
			            "name": "string",
			            "orgid": 0,
			            "paddress": "string",
			            "password": "string",
			            "posts": "string",
			            "roles": {
			              "description": "string",
			              "id": 0,
			              "role_name": "string"
			            }
			          },
			          "letterdate": "2019-11-23T01:29:16.553Z",
			          "letterdeliverytype": "string",
			          "lettersubject": "string",
			          "lettertype": "string",
			          "nextfinaldate": "2019-11-23T01:29:16.553Z",
			          "noticolor": "string",
			          "papchecked": "string",
			          "project": {
			            "address": "string",
			            "code": "string",
			            "desc1": "string",
			            "endDate": "dd/MM/yyyy",
			            "filesid": "string",
			            "id": 0,
			            "insert_by": 0,
			            "insert_date": "2019-11-23T01:29:16.553Z",
			            "prname": "string",
			            "projectteams": [
			              {
			                "employee": {
			                  "active": 0,
			                  "bdate": "dd/MM/yyyy",
			                  "caddress": "string",
			                  "contactnumber": "string",
			                  "email": "string",
			                  "empavailable": [
			                    {
			                      "description": "string",
			                      "employee": {},
			                      "id": 0,
			                      "leavefrom": "dd/MM/yyyy",
			                      "leaveto": "dd/MM/yyyy",
			                      "meetingetime": "yyyy-MM-dd HH:mm:ss",
			                      "meetingstime": "yyyy-MM-dd HH:mm:ss"
			                    }
			                  ],
			                  "gender": "string",
			                  "id": 0,
			                  "lastName": "string",
			                  "mid": "string",
			                  "name": "string",
			                  "orgid": 0,
			                  "paddress": "string",
			                  "password": "string",
			                  "posts": "string",
			                  "roles": {
			                    "description": "string",
			                    "id": 0,
			                    "role_name": "string"
			                  }
			                },
			                "id": 0,
			                "project": {}
			              }
			            ],
			            "startDate": "dd/MM/yyyy",
			            "teamhead": {
			              "active": 0,
			              "bdate": "dd/MM/yyyy",
			              "caddress": "string",
			              "contactnumber": "string",
			              "email": "string",
			              "empavailable": [
			                {
			                  "description": "string",
			                  "employee": {},
			                  "id": 0,
			                  "leavefrom": "dd/MM/yyyy",
			                  "leaveto": "dd/MM/yyyy",
			                  "meetingetime": "yyyy-MM-dd HH:mm:ss",
			                  "meetingstime": "yyyy-MM-dd HH:mm:ss"
			                }
			              ],
			              "gender": "string",
			              "id": 0,
			              "lastName": "string",
			              "mid": "string",
			              "name": "string",
			              "orgid": 0,
			              "paddress": "string",
			              "password": "string",
			              "posts": "string",
			              "roles": {
			                "description": "string",
			                "id": 0,
			                "role_name": "string"
			              }
			            },
			            "update_by": 0,
			            "update_date": "2019-11-23T01:29:16.553Z"
			          },
			          "property_id": "string",
			          "sender": "string",
			          "startDate": "2019-11-23T01:29:16.553Z",
			          "status": 0,
			          "tapal": 0,
			          "tasktype": {
			            "description": "string",
			            "id": 0,
			            "ttype": "string"
			          },
			          "tname": "string",
			          "ttype": 0,
			          "update_by": 0,
			          "update_date": "dd/MM/yyyy",
			          "workflow": [
			            {}
			          ]
			        },
			        "task_from": {
			          "active": 0,
			          "bdate": "dd/MM/yyyy",
			          "caddress": "string",
			          "contactnumber": "string",
			          "email": "string",
			          "empavailable": [
			            {
			              "description": "string",
			              "employee": {},
			              "id": 0,
			              "leavefrom": "dd/MM/yyyy",
			              "leaveto": "dd/MM/yyyy",
			              "meetingetime": "yyyy-MM-dd HH:mm:ss",
			              "meetingstime": "yyyy-MM-dd HH:mm:ss"
			            }
			          ],
			          "gender": "string",
			          "id": 0,
			          "lastName": "string",
			          "mid": "string",
			          "name": "string",
			          "orgid": 0,
			          "paddress": "string",
			          "password": "string",
			          "posts": "string",
			          "roles": {
			            "description": "string",
			            "id": 0,
			            "role_name": "string"
			          }
			        },
			        "task_to": {
			          "active": 0,
			          "bdate": "dd/MM/yyyy",
			          "caddress": "string",
			          "contactnumber": "string",
			          "email": "string",
			          "empavailable": [
			            {
			              "description": "string",
			              "employee": {},
			              "id": 0,
			              "leavefrom": "dd/MM/yyyy",
			              "leaveto": "dd/MM/yyyy",
			              "meetingetime": "yyyy-MM-dd HH:mm:ss",
			              "meetingstime": "yyyy-MM-dd HH:mm:ss"
			            }
			          ],
			          "gender": "string",
			          "id": 0,
			          "lastName": "string",
			          "mid": "string",
			          "name": "string",
			          "orgid": 0,
			          "paddress": "string",
			          "password": "string",
			          "posts": "string",
			          "roles": {
			            "description": "string",
			            "id": 0,
			            "role_name": "string"
			          }
			        },
			        "title": "string",
			        "tstatus": "string",
			        "update_date": "2019-11-23T01:29:16.553Z"
			      }
			    ]
			  }
			];
	 console.log("$scope.date3"+$scope.date3);
	   console.log("$scope.date4"+$scope.date4);
	   
	
	
	$scope.taskdetailsbyid = function()
	{
		//alert("in test");
		var url = "sandrabhtask/" + $scope.uid + "/" + $scope.roleid;
		var config = {
			headers : {
				'Content-Type' : 'application/json;charset=utf-8;'
			}
		}
		var data = JSON.stringify($scope.task);
		$http.post(url, data, config).then(function(response) {
			
			$scope.tasklist = response.data;
		//	console.log("$scope.tasklist"+JSON.stringify($scope.tasklist));
			//$scope.startDate = 
			//console.log("hi"+JSON.stringify($scope.tasklist));
			// $scope.startDate = $scope.tasklist[0].startDate;
			// $scope.endDate = $scope.tasklist[0].endDate;
			// console.log( $scope.startDate +" $scope.startDate");
		}, function error(response) {
			$scope.postResultMessage = "Error Status: " + response.statusText;
		});
	}
	
	
	
	
	$scope.vm = {};
	$scope.vm.dtInstance = {};   
	$scope.vm.dtColumnDefs = [DTColumnDefBuilder.newColumnDef(2).notSortable()];
	$scope.vm.dtOptions = DTOptionsBuilder.newOptions()
					  .withOption('paging', true)
					  .withOption('searching', true)
					  .withOption('info', true)
					   .withDOM('Bfrtip')/*Bfrtip*/
					  .withColumnFilter({		
            aoColumns: [{
                type: 'number'
            }, {
                type: 'text',
                bRegex: true,
                bSmart: true
            },
            {
                type: 'text',
                bRegex: true,
                bSmart: true
            },
            {
            	type: 'select',
            	bRegex: false,
            	values: ['पर्यायी जमीन', 'भूखंड वाटप', 'प्रकल्प दाखला', 'इतर अधिकारामध्ये शेरा कमी करणे','इतर','लोकशाही दिन संदर्भ','शासन संदर्भ','लक्षवेधी व कपात सुचना संदर्भ','न्यायालयीन संदर्भ',
            		 'तारांकित प्रश्‍न','अतारांकित प्रश्‍न','लोकायुक्‍त संदर्भ','उपलोकायुक्त संदर्भ','जिल्हाधिकारी संदर्भ','अर्ध शासन,आयुक्त संदर्भ','अर्धशासकीय संदर्भ','आमदार संदर्भ','खासदार संदर्भ','आयुक्त संदर्भ',
            		 'मंत्री संदर्भ','पालकमंत्री संदर्भ','इतर संदर्भ']
            },
           
            {
            	 type: 'select',
                 bRegex: false,
                 values: 
                   	 ['पानशेत ','चासकामान ','उजनी ',
                   		 'वीर बाजी पासलकर प्रकल्प ',
                   		'थेटेवाडी', 'आस्थापना ', 
                   		'प्रशासन ',
                   		'वडीवले',
                   		'पवना',
                   		'वीर',
                   		'गुंजवणी',
                   		'मलवंडी ठुले',
                   		'निरा देवधर',
                   		'आंध्र',
                   		'नाझरे',
                   		'टाटा धरण',
                   		'अभिलेख कक्ष',
                   		 'भामा आसखेड',
                   		'कुकडी',
                   		'बोपगाव रायता',
                   		'कासरसाई',
                   		'आरळा कलमोडी',
                   		'डिंभे',
                   		'जाधववाडी',
                   		'आवक जावक',
                   		'टेमघर',
                   		'दाखले'
                   		]
                	
            },
            {
                type: 'text',
                bRegex: true,
                bSmart: true
            },
            {
                type: 'text',
                bRegex: true,
                bSmart: true
            },
            {
                type: 'text',
                bRegex: true,
                bSmart: true
            },
            {
                type: 'text',
                bRegex: true,
                bSmart: true
            },
            {
                type: 'select',
                bRegex: false,
                values: ['Complete', 'reject', 'assign', 'pending']
            }]
        })
					   .withButtons([
            /*'columnsToggle',*/
            'colvis',
            'copy',
            'print',
            'excel',
           /* {
                text: 'Some button',
                key: '1',
                action: function (e, dt, node, config) {
                    alert('Button activated');
                }
            }*/
        ]);
	
	$scope.openmodel = function(nid)
	{
		$rootScope.$emit('upempmodel', nid);
		
	//	$("#notification").modal("show");
	}
	
	  
	$('.datepicker-default').datepicker();

});