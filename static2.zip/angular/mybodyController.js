myapp.controller("mybodyController", function($scope, $http, $window,
	$localStorage, $filter, $compile, ServiceTaskTracker, $routeParams, $timeout,$translate,$rootScope) {
	
	$rootScope.$on('loginControllerEmit', function(event, data) {
	    console.log(data + ' Inside login controller');
	    
	    var myEl = angular.element(document.querySelector('body'));
		myEl.addClass('login');
		var myEl1 = angular.element(document.querySelector('.wrapper'));
		myEl1.addClass('wrapper-login');
		$scope.mytext1 = 'wrapper-login';
		$scope.mytext = 'logins';

		var myEl3 = angular.element(document.querySelector('.main-header'));
		myEl3.css('display', 'none');

		var myEl4 = angular.element(document.querySelector('.sidebar'));
		myEl4.css('display', 'none');
	  });

	
	
	
	$scope.uid = $localStorage.message;
	$scope.roleid = $localStorage.roleid;
	$scope.task_id='';
	$scope.status='';
	
	$scope.todaydate = new Date();


	
	$scope.showval = false;
	$scope.hideval = true;
	

	
/*	$scope.workflow = {
		description : "",
		task_from : {
			id : $scope.uid
		},
		task_to : {
			   id:''
			},
			
		task : {
			id : 0,
			status : 2,
			update_by : $scope.uid,
			update_date : ""
		}
	};*/
	
	$scope.workflow = {
			description : "",
			noticode:'2',
			task_from : {
				id : $scope.uid
			},
			task_to : {
			   id:''
			},
			
			task : {
				id : 0,
				status : 2,
				update_by : $scope.uid,
				update_date : ""
			}
		};
	
	$scope.addItem = function() {
		$scope.workflow.task.push({
			task_id : value.task.task_id
		});
	}
	
	
	$rootScope.$on('editformemit', function(event, data) {
		  console.log(data + ' Inside emp dashboard click');
		  $scope.uid = data;
		$scope.editableForms1();
		
		    
		  });
	
	$scope.editableForms1 = function(){
		// $scope.uid
		 
		 $http({
				method : 'post',
				url : "getempbyid/" + $scope.uid

			}).then(function(response, status, headers, config) {
			// console.log("ui "+ $scope.uid+"roleid"+$scope.roleid);
				$scope.employee = response.data;
				console.log(JSON.stringify(response.data));
				$("#updateemployee").modal("show");
				// $scope.task_id = $scope.taskEvents[0].id;
			}, function(error) {
			});
		
	}
	// update password
	$scope.updateemployee = function() {

	 var data = JSON.stringify($scope.employee);
	 
	 return $http.post('/updateemployee/'+$scope.uid,data).then(function (response)
				{
		 $scope.success = true;
			$scope.error = false;
			// console.log($scope.endDate+"endDate");
			$scope.successMessage = 'successful';
			
			$scope.form_data = {};
			
			$("#updateemployee").modal("hide");
			contMSG('Success', 'profile updated', 'fa fa-check',
					'success', 'right');
			$scope.closeModal();
			fetchData();

		}, function (response) {
			 console.log('error'+JSON.stringify(response.data));
			 $scope.success = false;
				$scope.error = true;
		});
	 }
	
	$rootScope.$on('upempmodel', function(event, data) {
		  // console.log(data + ' Inside emp dashboard click');
		 $scope.notification(data);
		    
		  });
	$scope.workflowdata1=[];
	
	// on click notification
	// $scope.taskdetails ={};
	$scope.value='';
	$scope.noticode='';
	$scope.taskdetails = [];
	 // view in search
	$scope.notification =  function(d1)
	 {
		console.log("value :"+d1+"");
		$scope.value = d1;
		sessionStorage.setItem('tasksssid',d1 );
		console.log("after value :"+d1);
		
		var url = '/showtaskbyid1/'+d1;
		
		var config = {
			headers : {
				'Content-Type' : 'application/json;charset=utf-8;'
			}
		}
		$http.get(url).then(function(response) {
			// console.log("test : "+JSON.stringify(response.data));
			$scope.taskdetails = response.data;
			$scope.task_id = response.data.id;
			$scope.status = response.data.status;
			
			$scope.noticolor = response.data.noticolor;
			
			$scope.workflowdata1 = response.data.workflow;
			$scope.noticode = $scope.workflowdata1[0].noticode;
			
			console.log("$scope.noticode"+$scope.noticode);
			// console.log($scope.taskdetails.filesid +"$scope.noticode ");
			
//		   console.log("notification data:"+JSON.stringify($scope.taskdetails));
		// 
			$("#notification").modal("show");
			
		}, function error(response) {
			$scope.postResultMessage = "Error Status: " + response.statusText;
		});
	}
	
	
	 
	 
	 
		// hide and show div
		$scope.isShowHide = function(param) {
			if (param == "show") {
				$scope.showval = true;
				$scope.hideval = true;
				$scope.showFirstButton = !$scope.showFirstButton
			}
		}
		
		
		$scope.updateNoticode = function(d2)
		{	
		    alert("in update code" +d2);
			console.log("in update code" +d2);
	        var url = "/updateNoticode/"+d2;
		    var config = {
				headers : {
					'Content-Type' : 'application/json;charset=utf-8;'
				}
			}

			var data = {
				noticode :'1',
			};

			$http.post(url, data, config).then(
					function(response) {
						$scope.success = true;
						$scope.error = false;
						// alert("success");
						$scope.successMessage = 'successful';
						
						
					},
					function(response) {
						$scope.success = false;
						$scope.error = true;
						$scope.errorMessage = 'error...!';
					});
		}
	    
		// work flow assign
		$scope.assigntask = function() {
			// console.log("$scope.task_id"+$scope.task_id +"$scope.task_id");
			$scope.showFirstButton = !$scope.showFirstButton
			var url = "addworkflow/" + $scope.task_id;

			var config = {
				headers : {
					'Content-Type' : 'application/json;charset=utf-8;'
				}
			}
			var data = JSON.stringify($scope.workflow);
		// console.log(data);
			$http.post(url, data, config).then(
					function(response) {
						$scope.success = true;
						$scope.error = false;
						$scope.successMessage = 'successful';
						$("#eventDetails").modal("hide");
						contMSG('Success', 'Task Assigned Successfully',
								'fa fa-check', 'success', 'right');

					},
					function(response) {
						contMSG('Danger', 'Some Error Occured. Try Again..!',
								'fa fa-remove', 'danger', 'center');
					});
		}
		
		// task complete
		$scope.taskcomplete = function()
		{
			// console.log("$scope.task_id"+$scope.task_id +"$scope.task_id");
			var url = "/completetask/" + $scope.task_id;
			var config = {
				headers : {
					'Content-Type' : 'application/json;charset=utf-8;'
				}
			}

			var data = {
				id : $scope.task_id
			};

			$http.post(url, data, config).then(
					function(response) {
						$scope.success = true;
						$scope.error = false;
						$scope.successMessage = 'successful';
						$scope.form_data = {};
						$("#eventDetails").modal("hide");
						contMSG('Success', 'Task Completed', 'fa fa-check',
								'success', 'right');
						$scope.closeModal();
						fetchData();
					},
					function(response) {
						$scope.success = false;
						$scope.error = true;
						$scope.errorMessage = 'error...!';
						contMSG('Error', 'Some Error Occured. Try Again..!',
								'fa fa-remove', 'danger', 'center');
					});
		}

		// task reject function
		$scope.taskReject = function() {
			console.log("$scope.task_id"+$scope.task_id +"$scope.task_id");
			var url = "/rejecttask/" + $scope.task_id;
			var config = {
				headers : {
					'Content-Type' : 'application/json;charset=utf-8;'
				}
			}

			var data = {
				id : $scope.task_id,
			};

			$http.post(url, data, config).then(
					function(response) {
						$scope.success = true;
						$scope.error = false;
						$scope.successMessage = 'successful';
						$scope.form_data = {};
						$("#notification").modal("hide");
						$scope.closeModal();
						contMSG('Rejected', 'Oops! Task Rejected',
								'fa fa-exclamation-triangle', 'danger', 'center');
						fetchData();
					},
					function(response) {
						$scope.success = false;
						$scope.error = true;
						$scope.errorMessage = 'error...!';
						contMSG('Error', 'Some Error Occured. Try Again..!',
								'fa fa-remove', 'danger', 'center');
					});
		}
		
		
		
		 

			// find all employee
			 function employeeList() {
				$scope.empList = {};
				var url = 'getempList';
				var config = {
					headers : {
						'Content-Type' : 'application/json;charset=utf-8;'
					}
				}
				$http.get(url).then(function(response) {
					// $scope.getDivAvailable = true;
					// console.log('empList : '+JSON.stringify(response.data));
					$scope.empList = response.data;
				}, function error(response) {
					$scope.postResultMessage = "Error Status: " + response.statusText;
				});

			}
			employeeList();
	

		// Success msg
			function contMSG(title, msg, icon, state, align) {
				var placementFrom = 'top';
				var placementAlign = align;
				var state = state;
				var content = {};
				content.message = msg;
				content.title = title;
				content.url = '#';
				content.icon = icon;
				$.notify(content, {
					type : state,
					placement : {
						from : placementFrom,
						align : placementAlign
					},
					time : 1000,
					delay : 2000,
				});
			}
			  		

			 
			 // for tooltip
			 $(".workflow,.workflow-close-icon").on('click',function(){
				  $(".click-menu").toggleClass('onclick-menu');
				});
			 
				
				$scope.logout = function() {
		         
				// alert($scope.uid +"before $localStorage.message");
					
					localStorage.clear();
					window.localStorage.clear()

			// alert($scope.uid +"$localStorage.message");
						
					$window.location.href = '#!/';
				}
				
				
				$scope.printtask = function() {
				
				
				// $rootScope.$emit('print', $scope.value);
				
				sessionStorage.setItem("taskid",$scope.value );
				   
				   $window.location.href = '#!printdetails';
				}
				
				/*
				 * $scope.printmodal = function() {
				 * 
				 * $('#eventDetails').modal('hide');
				 * $('body').removeClass('modal-open');
				 * $('.modal-backdrop').remove();
				 * 
				 * sessionStorage.setItem("taskid",$scope.task_id );
				 * 
				 * $window.location.href = '#!printdetails'; }
				 * 
				 * $rootScope.$on('print', function(event, data) {
				 * console.log(data + ' Inside Sibling one');
				 * 
				 * $scope.printmodal(); });
				 */
				
				// task details for edit...
				 $scope.task ={
				    		// customer:$scope.customer,
							
							startDate:'',
							endDate:'',
							final_date:'',
							complete_date:'',
							filesid:'',
							color: '#007bffb8',
							status: 3,
							insert_by:'',
							insert_date:'',
							update_by:'',
							update_date:'',
							tname:'',
							task_type:1,
							assignto:{},
							
							arrivedfrom:'',
							branch:'',
							caseno:'',
							
							// संदर्भ
							inwordno:'',
							inworddate:'',
							letterdate:'',
							arrivedfrom:'',
							branch:'',
							sender:'',
							lettertype:'',
						
							lettersubject:'',
							letterdeliverytype:'',
							project:{
								id:0,
								prname:''
							},
							
							// workflow: '',
							// property_id : $scope.property.id,
							tasktype:{
								id : 0
							},
							
								
						// employee:{}
				    }
				
				

				 // to update the task details
				 $scope.savenotificationedit = function() {
				
					    // $scope.user already
						// updated!JSON.stringify($scope.task)
					 var data = JSON.stringify($scope.task);
					 
					// console.log(data +"details of task");
					 
					 
					 return $http.post('/updatetask/'+ $scope.task_id,data).then(function (response)
								{
						 $scope.success = true;
							$scope.error = false;
							console.log($scope.endDate+"endDate");
							$scope.successMessage = 'successful';
							$scope.form_data = {};
							$scope.displaytask();
							$("#eventDetails").modal("hide");
							// contMSG('Success', 'Task Completed', 'fa
							// fa-check',
						// 'success', 'right');
							$scope.closeModal();
							

						}, function (response) {
							// console.log('error'+JSON.stringify(response.data));
							 $scope.success = false;
								$scope.error = true;
						});
				 }			
				 
				
				 
				 $scope.isShowHide12 = function(param,$event) {
						$event.preventDefault();
						if (param == "show") {
							$scope.showval = true;
							$scope.hideval = true;
							$scope.showFirstButton = !$scope.showFirstButton
						}
					}
				 
				// in employee dashboard controller
				  $scope.setCompleteTask = function(nid)
				  {
		        		$rootScope.$emit('taskcomp' , +nid);
		        	}
				 
				 $scope.setRejectTask = function(tid)
				  {
					// $event.preventDefault();
		        		//alert("hi"+tid);
		        		// from employeedashboard controller
		        		$rootScope.$emit('taskreject' , +tid);
		        		// $scope.clickUpload(nid);
		        	}
				 
				 
				 $scope.setnextfinaldate = function(tid)
				  {
					// $event.preventDefault();
		        	//	alert("hi"+tid);
		        		// from employeedashboard controller
		        		$rootScope.$emit('tasktasknextfinaldate' , +tid);
		        		// $scope.clickUpload(nid);
		        	}
		        	
		        	$scope.reassigntask = function(tid)
					  {
			        		//alert("hi"+tid);
			        		$rootScope.$emit('taskassign' , +tid);
			        		
			        	}
		        	
		      // ///////////////////////////////////////////////////////////////
		        	var i = 0;
		        	$scope.reAssigntask = function(tid,$event) {
		        		$event.preventDefault();
		        		console.log("task: "+tid+"id: value:");
		        		var url
		        		
		        		url = "displaytaskbyid/"+tid;
		        		
		        		$http.get(url).then(function(response) {
		        			//alert("in" + response.data);
		        			$scope.tasktask = response.data;
		        			
		        			$scope.assignto =$scope.tasktask[0];
		        			$scope.lastassign = $scope.tasktask[1];
		        	        $scope.endDate1 = $scope.tasktask[2];
		        			console.log("hello" + $scope.assignto + "$scope.lastassign " +$scope.lastassign);
		        		}),
		        		

		        		$scope.showFirstButton = !$scope.showFirstButton;
		        		
		       
		        		// if($scope.assignto.id == $scope.lastassign.id &&
						// $scope.assignto.id == uid && $scope.task.endDate ==
						// null)
	        			console.log("before if Assign to: " +$scope.assignto +"last assign to: " +$scope.lastassign +" user id: " + $scope.uid);

		        		if($scope.assignto == $scope.lastassign)
		        		{
		        			console.log("Assign to: " +$scope.assignto +"last assign to: " +$scope.lastassign +" user id: " + $scope.uid);
		        			// alert("in first");
		        			var v = '';
		        			v = $scope.endDate;
		        			url = "addworkflow/"+tid+"/"+v.toString().split('/').join('-');
		        			console.log("url with date" +url);
		        		}
		        		else
		        		{
		        			console.log("else Assign to: " +$scope.assignto +"last assign to: " +$scope.lastassign +" user id: " + $scope.uid);

		        			url = "addworkflow/" + tid;
		        		}

		        		var config = {
		        			headers : {
		        				'Content-Type' : 'application/json;charset=utf-8;'
		        			}
		        		}
		        		
		        		
		        		var data = JSON.stringify($scope.workflow);
		        		console.log("workflow::" +data);
		        		
		        		$http.post(url, data, config).then(
		        				function(response) {
		        					$scope.success = true;
		        					$scope.error = false;
		        					$scope.successMessage = 'successful';
		        					$("#eventDetails").modal("hide");
		        					$("#notification").modal("hide");
		        					contMSG('Success', 'Task Assigned Successfully',
		        							'fa fa-check', 'success', 'right');
		        					// $scope.displaytask();
		        					// $route.reload();
		        				},
		        				function(response) {
		        					contMSG('Danger', 'Some Error Occured. Try Again..!',
		        							'fa fa-remove', 'danger', 'center');
		        				});
		        	}
		        	 i++;
		        	 
		        	 // for confirmation message for reject task
		        		$scope.taskreject1 = function(tid,$event) {
		        			swal({
		        				title: 'Are you sure?',
		        				text: "You Want to Reject this Task!",
		        				type: 'warning',
		        				buttons:{
		        					confirm: {
		        						text : 'Yes, Reject it!',
		        						className : 'btn btn-success'
		        					},
		        					cancel: {
		        						visible: true,
		        						className: 'btn btn-danger'
		        					}
		        				}
		        			}).then((Delete) => {
		        				if (Delete) {
		        					swal({
		        						title: 'Rejected!',
		        						text: 'Your Task has been rejected.',
		        						type: 'success',
		        						buttons : {
		        							confirm: {
		        								className : 'btn btn-success'
		        							}
		        						}
		        					}).then(
		        							function() {
		        								
		        								$scope.taskReject(tid,$event);
		        							});
		        							
		        				} else {
		        					swal.close();
		        				}
		        			});
		        		};
		        		


			        		// hide and show div
		$scope.isShowHide = function(param,$event) {
		$event.preventDefault();
		if (param == "show") {
		$scope.showval = true;
		$scope.hideval = true;
		$scope.showFirstButton = !$scope.showFirstButton
		}
     };	
		//  $scope.project_id='';
	  // get all project list
	  $scope.projectList = function()
	  
	   {
			   $scope.project1 = 
			   [
				   {
				     "address": "string",
				     "code": "string",
				     "desc1": "string",
				     "endDate": "dd/MM/yyyy",
				     "filesid": "string",
				     "id": 0,
				     "insert_by": 0,
				     "insert_date": "2019-11-15T06:47:03.870Z",
				     "prname": "string",
				     "projectteams": [
				       {
				         "employee": {
				           "active": 0,
				           "bdate": "dd/MM/yyyy",
				           "caddress": "string",
				           "contactnumber": "string",
				           "email": "string",
				           "empavailable": [
				             {
				               "description": "string",
				               "employee": {},
				               "id": 0,
				               "leavefrom": "dd/MM/yyyy",
				               "leaveto": "dd/MM/yyyy",
				               "meetingetime": "yyyy-MM-dd HH:mm:ss",
				               "meetingstime": "yyyy-MM-dd HH:mm:ss"
				             }
				           ],
				           "gender": "string",
				           "id": 0,
				           "lastName": "string",
				           "mid": "string",
				           "name": "string",
				           "orgid": 0,
				           "paddress": "string",
				           "password": "string",
				           "posts": "string",
				           "roles": {
				             "description": "string",
				             "id": 0,
				             "role_name": "string"
				           }
				         },
				         "id": 0,
				         "project": {
				           "address": "string",
				           "code": "string",
				           "desc1": "string",
				           "endDate": "dd/MM/yyyy",
				           "filesid": "string",
				           "id": 0,
				           "insert_by": 0,
				           "insert_date": "2019-11-15T06:47:03.871Z",
				           "prname": "string",
				           "projectteams": [
				             {}
				           ],
				           "startDate": "dd/MM/yyyy",
				           "teamhead": {
				             "active": 0,
				             "bdate": "dd/MM/yyyy",
				             "caddress": "string",
				             "contactnumber": "string",
				             "email": "string",
				             "empavailable": [
				               {
				                 "description": "string",
				                 "employee": {},
				                 "id": 0,
				                 "leavefrom": "dd/MM/yyyy",
				                 "leaveto": "dd/MM/yyyy",
				                 "meetingetime": "yyyy-MM-dd HH:mm:ss",
				                 "meetingstime": "yyyy-MM-dd HH:mm:ss"
				               }
				             ],
				             "gender": "string",
				             "id": 0,
				             "lastName": "string",
				             "mid": "string",
				             "name": "string",
				             "orgid": 0,
				             "paddress": "string",
				             "password": "string",
				             "posts": "string",
				             "roles": {
				               "description": "string",
				               "id": 0,
				               "role_name": "string"
				             }
				           },
				           "update_by": 0,
				           "update_date": "2019-11-15T06:47:03.871Z"
				         }
				       }
				     ],
				     "startDate": "dd/MM/yyyy",
				     "teamhead": {
				       "active": 0,
				       "bdate": "dd/MM/yyyy",
				       "caddress": "string",
				       "contactnumber": "string",
				       "email": "string",
				       "empavailable": [
				         {
				           "description": "string",
				           "employee": {},
				           "id": 0,
				           "leavefrom": "dd/MM/yyyy",
				           "leaveto": "dd/MM/yyyy",
				           "meetingetime": "yyyy-MM-dd HH:mm:ss",
				           "meetingstime": "yyyy-MM-dd HH:mm:ss"
				         }
				       ],
				       "gender": "string",
				       "id": 0,
				       "lastName": "string",
				       "mid": "string",
				       "name": "string",
				       "orgid": 0,
				       "paddress": "string",
				       "password": "string",
				       "posts": "string",
				       "roles": {
				         "description": "string",
				         "id": 0,
				         "role_name": "string"
				       }
				     },
				     "update_by": 0,
				     "update_date": "2019-11-15T06:47:03.871Z"
				   }
				 ];
			   var url = 'viewproject';
				
				var config = {
		               headers : {
		                   'Content-Type': 'application/json;charset=utf-8;'
		               }
		       }
				$http.get(url).then(function (response) {
					$scope.project1 = response.data;
					$scope.project_id = $scope.project1[0].id;
			
				}, function error(response) {
					$scope.postResultMessage = "Error Status: " +  response.statusText;
				});
			  
			  };
	   $scope.projectList();
	   
		
	   //for update team from employeedashboard
		$scope.emdashupdateteammem = function()
		{
			$rootScope.$emit('onmybodyCtrl');
			
		}
		
		
		//from employeedashboard for update task
		$scope.updateTaskes = function()
		{
			$rootScope.$emit('mybodyCtrlupdate');
			
		}

//////////////////////////////////////////////////////////////////////////////////////////////////////
		// Send the task in SR
		$scope.sendtoSR = function(tid,$event) {
			// $event.preventDefault();
				// alert("task id : " +tid);
				var url = "/tasksendtosr/" + tid +"/" +$scope.uid;
				var config = {
					headers : {
						'Content-Type' : 'application/json;charset=utf-8;'
					}
				}

				var data = {
					id : tid,
						assignto:{
							id : $scope.uid
						},
			     	workflow:$scope.workflow
						
					
					// assignto : $scope.events[0].insert_by,
				    // insert_by:$scope.uid
					
				};
				// data.append(JSON.stringify($scope.workflow));
             console.log(JSON.stringify($scope.workflow));
				$http.post(url, data, config).then(
						function(response) {
							console.log(JSON.stringify(response.data));
							$scope.success = true;
							$scope.error = false;
							$scope.successMessage = 'successful';
							$scope.form_data = {};
						//	$("#eventDetails").modal("hide");
							$("#notification").modal("hide");
							contMSG('Success', 'Task Send to SR', 'fa fa-check',
									'success', 'right');
						// $scope.closeModal();
							// fetchData();
						},
						function(response) {
							console.log(JSON.stringify(response.data) +"error");
							$scope.success = false;
							$scope.error = true;
							$scope.errorMessage = 'error...!';
							contMSG('Error', 'Some Error Occured. Try Again..!',
									'fa fa-remove', 'danger', 'center');
						});
			}
		
		
		// confirm send to SR
		$scope.sendToSrConfirm = function(tid,$event) {
			swal({
				title: 'Are you sure?',
				text: "You want to Send this Task to SR!",
				type: 'warning',
				buttons:{
					confirm: {
						text : 'Yes!',
						className : 'btn btn-success'
					},
					cancel: {
						visible: true,
						className: 'btn btn-danger'
					}
				}
			}).then((Delete) => {
				if (Delete) {
					swal({
						title: 'Close!',
						text: 'Your Task has been Send.',
						type: 'success',
						buttons : {
							confirm: {
								className : 'btn btn-success'
							}
						}
					}).then(
							function() {
								
								$scope.sendtoSR(tid,$event);
							});
							
				} else {
					swal.close();
				}
			});
		};
		
		
///////////////////////////////////////////////////////////////////////////	
		
		
		// /Send to Await
		
		// Send the task in SR
		$scope.sendtoAwait = function(tid,$event) {
			// $event.preventDefault();
				// alert("task id : " +tid);
				var url = "/tasksendtoAwait/" + tid;
				var config = {
					headers : {
						'Content-Type' : 'application/json;charset=utf-8;'
					}
				}
				
					var data = JSON.stringify($scope.workflow);
				
			  
				$http.post(url, data, config).then(
						function(response) {
							console.log(JSON.stringify(response.data));
							$scope.success = true;
							$scope.error = false;
							$scope.successMessage = 'successful';
							$scope.form_data = {};
						/*	$("#eventDetails").modal("hide");*/
							$("#notification").modal("hide");
							contMSG('Success', 'Task Send to Await', 'fa fa-check',
									'success', 'right');
						// $scope.closeModal();
							// fetchData();
						},
						function(response) {
							console.log(JSON.stringify(data) +"error");
							$scope.success = false;
							$scope.error = true;
							$scope.errorMessage = 'error...!';
							contMSG('Error', 'Some Error Occured. Try Again..!',
									'fa fa-remove', 'danger', 'center');
						});
			}
		
		
		// confirm send to SR
		$scope.sendToAwaitConfirm = function(tid,$event) {
			swal({
				title: 'Are you sure?',
				text: "You want to Send this Task to Await!",
				type: 'warning',
				buttons:{
					confirm: {
						text : 'Yes!',
						className : 'btn btn-success'
					},
					cancel: {
						visible: true,
						className: 'btn btn-danger'
					}
				}
			}).then((Delete) => {
				if (Delete) {
					swal({
						title: 'Close!',
						text: 'Your Task has been In Await.',
						type: 'success',
						buttons : {
							confirm: {
								className : 'btn btn-success'
							}
						}
					}).then(
							function() {
								
								$scope.sendtoAwait(tid,$event);
							});
							
				} else {
					swal.close();
				}
			});
		};


});
