
myapp.controller('myCtrl', ['$scope','$http',  function($scope,$http,$window){
    
	
	
	 $scope.uploadResult ="";
     //$scope.filelist=[];
	 $scope.filelist=[{
		 id:0,
		 filelist:{id:0}
	 }];
	 
     $scope.filesids=[];
     
	    $scope.myForm = {
	    	testid :sessionStorage.getItem('taskid11'),
	        files: ''
	    }
	    
	    $scope.value='';
	///////// file upload ///////////////////////////////////////////////////////////////////////////////////////////////
	     $scope.doUploadFile = function()
	     {  
     	  // alert("$scope.doUploadFile"+sessionStorage.getItem('taskid11') );
     	  $scope.myForm.testid = sessionStorage.getItem('taskid11') ;
	    	var url = "/uploadMultiFiles";
	 
	        var data = new FormData();
	        
	        console.log ($scope.myForm.files.length +"$scope.myForm.files.length");
	       
	        data.append("testid", $scope.myForm.testid);
	        
	        
	        angular.forEach($scope.myForm.files, function (val, key) 
	        	{
	        	data.append('files', val);						
	    	  });
	   
	        var config = {
	            transformRequest: angular.identity,
	            transformResponse: angular.identity,
	            headers: {
	                'Content-Type': undefined
	            }
	        }
	        
	 
	        $http.post(url, data, config).then(
	            // Success
	            function(response) {
	                $scope.uploadResult =  response.data;
	                $scope.filelist = JSON.parse(response.data);
	              //  console.log(JSON.parse(response.data));
	           
	                for(var i = 0; i < $scope.filelist.length;i++)
	                {
	                	// console.log("$scope.filesids" +$scope.filelist[i].id); 
	                	 $scope.filesids.push($scope.filelist[i].id)
	                	 // $scope.filesids[] = $scope.filelist[i].id;
	                	 $scope.value=$scope.filelist[i].id;
	                	
	                }
	                
	             //   console.log("files id : "+JSON.stringify($scope.filesids));
	                
	           
	            },
	            // Error
	            function(response) {
	                $scope.uploadResult = response.data;
	            });
	    };
	    
	    
	    

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	    
	  //find all File list
		 function fileslist1() {
			//$scope.fileslist = {};
			var url = 'getfilesList';
			var config = {
				headers : {
					'Content-Type' : 'application/json;charset=utf-8;'
				}
			}
			$http.get(url).then(function(response) {
				// $scope.getDivAvailable = true;
				// console.log('empList : '+JSON.stringify(response.data));
				$scope.fList = response.data;
				//console.log('files type list : '+JSON.stringify($scope.fList));
			}, function error(response) {
				$scope.postResultMessage = "Error Status: " + response.statusText;
			});

		}
		 fileslist1();
		 
		 
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		 $scope.filesmodel = {
				  ffileslist1:[{
						id :''
				    }]  
			    }
	
		 //Update file with file type
		 $scope.filetypeid  = function() {
			
             	 var url = "/getfileid/" + $scope.filesids;
         
				var config = {
					headers : {
						'Content-Type' : 'application/json;charset=utf-8;'
					}
				}
			
				 var data  = JSON.stringify( $scope.filesmodel);
			
					$http.post(url, data, config).then(
							function(response) {
							//	console.log(response.data+"success" +response)
								$scope.success = true;
								$scope.error = false;
							//	console.log($scope.endDate+"endDate");
								$scope.successMessage = 'successful';
								
							},
							function(response) {
								console.log(response.data)
								$scope.success = false;
								$scope.error = true;
							});
					}
			
		 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		 /// Success msg
				function contMSG(title, msg, icon,state,align) {
					var placementFrom = 'top';
					var placementAlign = align;
					var state = state;
					var content = {};
					content.message = msg;
					content.title = title;
					content.url = '#';
					content.icon = icon;
					$.notify(content, {
						type : state,
						placement : {
							from : placementFrom,
							align : placementAlign
						},
						time : 1000,
						delay : 2000,
						z_index: 5000,
					});
				} 
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		 $scope.save  = function() {
				
         	 var url = "/setfileid";
     
			var config = {
				headers : {
					'Content-Type' : 'application/json;charset=utf-8;'
				}
			}
		
			 var data  = JSON.stringify( $scope.filelist);
		
				$http.post(url, data, config).then(
						function(response) {
							console.log(response.data+"success" +response)
							$scope.success = true;
							$scope.error = false;
							$scope.successMessage = 'successful';
							 
							
							 contMSG('Success', 'File Added Successfully', 'fa fa-check','success','right');
						
							 $("#myModal").modal("hide");
							 $('body').removeClass('modal-open');
							  $('.modal-backdrop').remove();
							 window.location.href= '#!printdetails';
							
							 
							
							
						},
						function(response) {
							//alert(response);
							contMSG('Danger', 'Some Error Occured. Try Again..!',
									'fa fa-remove', 'danger', 'right');
						});
	
				}
		 
		 $scope.closemodel = function()
		 {
			 //alert("in close model");
			 $("#myModal").modal("hide");
			 $('body').removeClass('modal-open');
			  $('.modal-backdrop').remove();
			 //$location.href('#!printdetails');
			 window.location.href= '#!printdetails';
		 }
		 
    
}]);