myapp.controller("addtaskController",function($scope, $http, $window,$rootScope, $localStorage,$route, $routeParams, ServiceTaskTracker,$translate) 
{

	var myEl = angular.element( document.querySelector( 'body' ) );
	myEl.removeClass('login');
	var myEl1 = angular.element( document.querySelector( '.wrapper' ) );
	myEl1.removeClass('wrapper-login');
	
	var myEl3 = angular.element( document.querySelector( '.main-header' ) );
	myEl3.css('display','block');

	var myEl4 = angular.element( document.querySelector( '.sidebar' ) );
	myEl4.css('display','block');
	
	var myEl = angular.element( document.querySelector( 'body' ) );
	myEl.removeClass('wrapper-login');
	  
	    $scope.required = true;
	   $scope.success = false;
	   $scope.error = false;
	   $scope.property = {};
	  $scope.name='';
	   // login userid
        $scope.uid = $localStorage.message;
        var task_name = false;
        
    	$scope.roleid = $localStorage.roleid;
        $scope.submitValue = "";
        $scope.id = "";
        
        $scope.showFirstButton=true

	   
        // variable for events details all events..
        $scope.eventdetails =[];
        // today date
        $scope.today = new Date();
        
        // find the from type
        $scope.task_type = [];
	 // $scope.dates = $routeParams.dates;
        // variables
        $scope.task_id='';
	   $scope.tname = "";
	   $scope.startdate="";
	   $scope.endDate="";
	   $scope.project_id="";
	   $scope.taskid='';
	 //task details for edit...
	   // change the text of the button onclick
	   $scope.CustomerInfo1  ='जतन करा';
	   $scope.changeText = function() {
	       $scope.CustomerInfo1  = 'अद्ययावत करा';
	   }; 
	   // calling method of add customer controller
	  /*
		 * function($scope) { $scope.childmethod = function() {
		 * $rootScope.$emit("CallAddcustomer", {}); } }
		 */
	    
	  
	    // Gets data from the Database of all events
	    $scope.Events =[];
	  /*
		 * $http({ method: 'GET', url: 'showtask' }).then(function (data) {
		 * $scope.Events = data.data; $scope.tname = $scope.Events[0].tname;
		 * $scope.eventdetails = JSON.stringify( $scope.Events); }, function () {
		 * alert('Error'); });
		 */
	    
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	   
	    $scope.getallcustomers = function(){  	
	    	// get all customerlist
	 	   $http({
	 		    method: 'get', 
	 		    url: '/getallcustomers'
	 		}).then(function (response, status, headers, config) {
	 		    $scope.listcustomers = response.data;
	 		    // console.log(response.data);
	 		},function (error){
	 		    console.log(error, 'can not get data.');
	 		});	  
	    }
	   
	    $scope.getallcustomers();
	   
	   $scope.customers = [
		   {id : 1, name : "first"},
		   {id : 2, name : "second"},
		   {id : 3, name : "third"},
		 ];
	   
	  // $scope.papchecked="";
	   
	  /* $scope.checkedoption = function()
	   {
		   if ($scope.papchecked)
		   {
			   $scope.papchecked = "true";
		     } 
		   else {
			   $scope.papchecked  = "false";
		     }
		   
	   },*/
	   
	   $scope.resetTaskFields = function(){ 
		   $scope.filesid = '';
			
		$scope.tname = '';
			
	   }
	   
	   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	   
	   // add task into database.
	   $scope.addTask = function(){ 
		  //alert("hi");
			  var url = "saveTask";

			  var config = {
						headers : {
							'Content-Type' : 'application/json;charset=utf-8;'
						}
					}
				console.log("takstype d :"+$scope.tasktyped);
				console.log("selected property id :"+$scope.property.id +":"+$scope.assignto);
				var data = {
						// task_id: $scope.task_id,
						
						customer:$scope.customer,
						project: $scope.project,
						startDate: $scope.startDate,
						endDate:$scope.endDate,
						finaldate: $scope.finaldate,
						completedate: $scope.completedate,
						filesid:$scope.filesid,
						color: '#49a0ff',
						status: 3,
						insertby:  $scope.uid,
						insertdate:$scope.today,
						updateby: $scope.updateby,
						updatedate:$scope.updatedate,
						tname: $scope.tname,
						typeoftask:$scope.typeoftask,
						// task_type:1,
						assignto:$scope.assignto,
						arrivedfrom:$scope.arrivedfrom,
						branch:$scope.branch,
						caseno:$scope.caseno,
						papchecked:$scope.papchecked,
						noticolor:2,
						
						// संदर्भ
						inwordno:$scope.inwordno,
						inworddate:$scope.inworddate,
						letterdate:$scope.letterdate,
						arrivedfrom:$scope.arrivedfrom,
						branch :$scope.branch,
						sender:$scope.sender,
						lettertype:$scope.lettertype,
					    
						lettersubject:$scope.lettersubject,
						letterdeliverytype:$scope.letterdeliverytype,
						files:$scope.files,
						
						workflow: $scope.workflow,
					/*	property_id : $scope.property.id,*/
						villages:$scope.villages,
						property_id : $scope.property.id,
						
						tasktype:{
							id : $scope.tasktyped
						},
							
						employee:$scope.employee,
						
						
		        };
             
				
			    
				
				// console.log("before task data "+JSON.stringify(data));
				$http.post(url, data, config).then(
						function(response) {
							//alert(response.data +"dataid" +response.data.id);
							$scope.success = true;
							$scope.error = false;
							 
							$scope.successMessage = 'successful';
							 //console.log($scope.letterdate+" letter date::: "+data.letterdate);
							// $("#eventDetails").modal("hide");
							$scope.resetTaskFields();
							$scope.task_id = response.data.id;
							$scope.ttype =  response.data.ttype; 
							$scope.tapal = response.data.tapal;
							console.log("task type: " +$scope.ttype +"$scope.tapal : " +$scope.tapal);
							
							/*contMSG('Success', "Task No : "+response.data.id + ', Assigned Successfully',
									'fa fa-check','success','right');*/
							
							
								
							
							//console.log(response.data.tapal +"tapal value");
							
							if(response.data.ttype == 1)
								{
								contMSG('Success', 'Task No : '+response.data.tapal + ' Assigned Successfully', 'fa fa-check','success','right');
								}
							else 
								contMSG('Success', 'Tapal No : '+response.data.tapal + ' Assigned Successfully', 'fa fa-check','success','right');
						
							
							$scope.tname =response.data.tname
							$scope.startdate =response.data.startDate;
						  // console.log(response.data.id);
						   
							
							
							sessionStorage.setItem('taskid',response.data.id );
							sessionStorage.setItem('taskid11',response.data.id );
							
							 $("#myModal").modal("show");
						
							// $window.location.href = '#!printdetails';
							
						},
						function(response) {
							contMSG('Danger', 'Some Error Occured. Try Again..!',
									'fa fa-remove', 'danger', 'right');
						});
	
		  },
		
		
		
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////		  
		  $scope.checktaskcontent = function()
		  {
	          if($scope.filesid.length === 0 || typeof $scope.filesid === 'undefined'&& 
	        		  $scope.assignto.length === 0 || typeof $scope.assignto === 'undefined' &&
	        		  $scope.tname.length === 0 || typeof $scope.tname === 'undefined')
	        		 
	             {
	        	  $scope.msg = "pls enter something";
	   
	          }else{
	        	  $scope.addTask();
	             $scope.msg = "Something Entered";
	           }
	         } 
		  
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////		  
		  $scope.checkContent = function()
		  {
	          if($scope.filesid.length === 0 || typeof $scope.filesid === 'undefined' || 
	        		  $scope.assignto.length === 0 || typeof $scope.assignto === 'undefined' ||
	        		  $scope.inwordno.length === 0 || typeof $scope.inwordno === 'undefined' || 
	        		  $scope.arrivedfrom.length === 0 || typeof $scope.arrivedfrom === 'undefined' || 
	        		  $scope.branch.length === 0 || typeof $scope.branch === 'undefined' ||
	        		  $scope.lettertype.length === 0 || typeof $scope.lettertype.branch === 'undefined')
	             {
	        	//  alert("alert");
	        	  $scope.msg = "pls enter something";
	   
	          }else{
	        	  $scope.addTask();
	             $scope.msg = "Something Entered";
	           }
	         } 
		  
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	   
		  // check if task is already assign of same property.
	   $scope.checkTask = function()
	   {
	     var today = (new Date()).getDay();
	 
		if($scope.eventdetails.includes($scope.propid)){
    	   if($scope.eventdetails.includes($scope.tname))
    	   {	
    	     $scope.showError = true;
    	   } 
    	 else
    	   {
    		  $scope.addTask();
    	     $scope.showError = false;
    	   }
		  }
    	   else {
    		   $scope.addTask();
    	       $scope.showError = false;
    	     
    	     
    	   }
	     
    	 };
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	   
	      // get value of tasktype from database.
		   function tasktype()
		   {
				   $scope.tasktype1 = [];
				   var url = 'showtasktype';
					
					var config = {
			               headers : {
			                   'Content-Type': 'application/json;charset=utf-8;'
			               }
			       }
					$http.get(url).then(function (response) {
						$scope.tasktype1 = response.data;
						// console.log(response.data);
					}, function error(response) {
						$scope.postResultMessage = "Error Status: " +  response.statusText;
					});
				  
				  }
		   tasktype();
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////		   
		   // get all employee list from database
		   function empList()
		   {
				   $scope.emplist = [];
				   var url = 'getempList';
					var config = {
			               headers : {
			                   'Content-Type': 'application/json;charset=utf-8;'
			               }
			       }
					$http.get(url).then(function (response) {
						// $scope.getDivAvailable = true;
						$scope.emplist = response.data;
						// console.log(response.data);
					}, function error(response) {
						$scope.postResultMessage = "Error Status: " +  response.statusText;
					});
				  
				  }
		   empList();
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////		   
		   // get all project list
		   function projectList()
		   {
				   $scope.project1 = [];
				   var url = 'viewproject';
					
					var config = {
			               headers : {
			                   'Content-Type': 'application/json;charset=utf-8;'
			               }
			       }
					$http.get(url).then(function (response) {
						// $scope.getDivAvailable = true;
						$scope.project1 = response.data;
						$scope.project_id = $scope.project1[0].id;
						//console.log($scope.project_id +"$scope.project_id0000")
						//console.log(response.data);
					}, function error(response) {
						$scope.postResultMessage = "Error Status: " +  response.statusText;
					});
				  
				  }
		   projectList();
		   
		   
		   $rootScope.$on('childEmit', function(event, data) {
				//  console.log(data + ' Inside Sibling one');

			   projectList();
			});
		   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////		   
		   // property List
		   function propertyList()
		   {
				   $scope.property1 = [];
				   var url = 'viewproperty';
					
					var config = {
			               headers : {
			                   'Content-Type': 'application/json;charset=utf-8;'
			               }
			       }
					$http.get(url).then(function (response) {
						// $scope.getDivAvailable = true;
						$scope.property1 = response.data;
						
						$scope.propid = $scope.property1[0].propid;
						// console.log($scope.propid +"$scope.propid");
						
						//console.log(response.data);
					}, function error(response) {
						$scope.postResultMessage = "Error Status: " +  response.statusText;
					});
				  
				  }
		   propertyList();
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////		   
		   // team member list
		  // function teammember()
		   $scope.teammember = function() {
		   
				   $scope.teamlist1 = [];
				   
				 //  console.log($scope.project.id +"$scope.project.id");
				   
				   var url = 'readprojectteam1/'+$scope.project.id;
					
					var config = {
			               headers : {
			                   'Content-Type': 'application/json;charset=utf-8;'
			               }
			       }
					$http.get(url).then(function (response) {
						// $scope.getDivAvailable = true;
					
						$scope.teamlist1 = response.data;
						
						// $scope.propid = $scope.property1[0].propid;
						// console.log($scope.propid +"$scope.propid");
						//console.log("team list :"+JSON.stringify($scope.teamlist1));
						// console.log(response.data);
					}, function error(response) {
						$scope.postResultMessage = "Error Status: " +  response.statusText;
					});
				  
				  }
		  // teammember();
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////		   
		   // WorkflowList
		   function workflowList()
		   {
				   $scope.workflow = [];
				   var url = 'getworkflow';
					
					var config = {
			               headers : {
			                   'Content-Type': 'application/json;charset=utf-8;'
			               }
			       }
					$http.get(url).then(function (response) {
							$scope.workflow = response.data;
						
						//console.log(response.data);
					}, function error(response) {
						$scope.postResultMessage = "Error Status: " +  response.statusText;
					});
				  
				  }
		   workflowList();
		   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////		   
		   $scope.adhaarCard ="";
			
			$scope.customer={
					   id:'0',
					   name: '',
					   gender:'',
					   bdate:'01/01/2019',
					   email:'',
					   contact_number:'',
					   adhaarCard:'',
					   c_address:'',
					   p_address:'',
					  // pic:'',
					  // file:'',
					   
					   property:[{
						   'prop_id':'0',
							area:'',
							address:'',
							category:'',
								
						}]  
			};
			
			$scope.addItem=function(){
				  $scope.customer.property.push({
					  prop_id:1,
					  area:'',
					  address:'',
					  category:'',
					  village:''
				});
			}
			 $scope.removeItem = function(m){
				 $scope.customer.property.splice($scope.customer.property.indexOf(m),1);
					  }
			 
			 $scope.addcustomer = function(){
				  var url = "/customerregistration";
					
					var config = {
							 // transformRequest: angular.identity,
						      // transformResponse: angular.identity,
						        headers: {
						         // 'Content-Type': undefined
						        }
			         
			        }
					
					// console.log("bdate "+$('#bdate').val());
					
					
					
					// var data = new data();
					 $scope.submitValue = $scope.customer.name;
					 
					   var data = new FormData();
					   // data.append('pic', $scope.customer.pic);
					   // data.append('customer',JSON.stringify($scope.customer));
					   // $scope.pic =
					    // var data11 = $scope.customer.pic.toDataURL();
					    // $scope.customer.pic =
						// data11.replace(/^data:image\/(png|jpg);base64,/, "");
						
					
					   var data  = JSON.stringify($scope.customer);
					   // var data = $scope.customer;
					  // data.append("customer",$scope.customer);
					   // data.append("pic",$scope.customer.pic);
					    
						// data.append('photo',
						// $("#photo")[0].$scope.customer.pic[0]);
						/* data.append('customer', $scope.customer.pic) */
					$http.post(url, data, config).then(function (response) {
						// console.log( $scope.customer.name+"name of customer"
						// +response.data.name);
						 $scope.customer.id = response.data.id;
						 $scope.success = true;
						    $scope.error = false;
						    $scope.successMessage = 'successful';
						    contMSG('Success', 'Customer Added Successfully', 'fa fa-check','success','right');
						    $scope.showDiv=true;
					}, function (response) {
						//console.log(JSON.stringify($scope.customer));
						$scope.showDiv=false;
						contMSG('Error', 'Some Error Occured. Try Again..!', 'fa fa-remove','danger','right');
					});
					
					$scope.firstname = "";
					$scope.lastname = "";
			  }
			 /*
				 * $scope.getdetails = function () {
				 * 
				 * $scope.customerlist = [];
				 * 
				 * var url = '/getallcustomers/'+$scope.customer.adhaarCard;
				 * 
				 * var config = { headers : { 'Content-Type':
				 * 'application/json;charset=utf-8;' } }
				 * $http.get(url).then(function (response) {
				 * 
				 * //$scope.customerlist = response.data; $scope.adhaarCard =
				 * response.data.adhaarCard; $scope.bdate =
				 * response.data.bdate; $scope.c_address =
				 * response.data.c_address; $scope.contact_number =
				 * response.data.contact_number; $scope.email =
				 * response.data.email; $scope.contact_number =
				 * response.data.contact_number; $scope.gender =
				 * response.data.gender; $scope.name = response.data.name;
				 * $scope.p_address = response.data.p_address;
				 * $scope.update_date = response.data.update_date;
				 * console.log(response.data); }, function error(response) {
				 * $scope.postResultMessage = "Error Status: " +
				 * response.statusText; });
				 *  }
				 */
			
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////		   
			   $scope.customerlist = [];
		     	 $scope.getdetails = function () {

					   $scope.customerlist = [];
					   
					   var url = '/getallcustomers/'+$scope.customer.adhaarCard;
						
						var config = {
				               headers : {
				                   'Content-Type': 'application/json;charset=utf-8;'
				               }
				       }
						$http.get(url).then(function (response) {
							//console.log("ghhhhhhhhhhhhh : "+JSON.stringify(response.data));
							//console.log(JSON.stringify(response.data)+">>>>>>>>>>>>>>>>>>>>>>>>$scope.customerlist");

							if(response.data.length && $scope.customer.adhaarCard != '')
							{
								
								// alert("hii");
								$scope.customerlist = response.data;
								// $scope.customerlist = response.data;
								$scope.customer.adhaarCard = $scope.customerlist[0].adhaarCard;
								$scope.customer.bdate = $scope.customerlist[0].bdate;
								$scope.customer.caddress = $scope.customerlist[0].caddress;
								$scope.customer.contactnumber = $scope.customerlist[0].contactnumber;
								$scope.customer.email = $scope.customerlist[0].email;
								//$scope.customer.contact_number = $scope.customerlist[0].contact_number;
								$scope.customer.gender = $scope.customerlist[0].gender;
								$scope.customer.name = $scope.customerlist[0].name;
								$scope.customer.paddress = $scope.customerlist[0].paddress;
								$scope.customer.updatedate = $scope.customerlist[0].updatedate;
								$scope.customer.pic = $scope.customerlist[0].pic;
								$scope.customer.id = $scope.customerlist[0].id;
								$scope.customer.property = $scope.customerlist[0].property;
								$scope.property.id= $scope.customer.property[0];
								$scope.property.villages=$scope.customer.property[0];

								// photo.setAttribute('src',
							// URL.createObjectURL($scope.customerlist[0].pic));
							// photo.setAttribute('src',
							// window.URL.createObjectURL(new
							// Blob($scope.customerlist[0].pic, {type:
							// "image/png"})));
								console.log(JSON.stringify($scope.property.villages.id)+"$scope.property.villages............value of village "+$scope.property.villages.id);
								 $scope.myimgs =  $scope.customerlist[0].pic;
							}
							else
							{
								// alert("else");
								$scope.customer.id='0'
								// $scope.customer.adhaarCard = '';
								$scope.customer.bdate =  '';
								$scope.customer.c_address =  '';
								$scope.customer.contact_number =  '';
								$scope.customer.email =  '';
								$scope.customer.contact_number =  '';
								$scope.customer.gender =  '';
								$scope.customer.name =  '';
								$scope.customer.p_address =  '';
								$scope.customer.update_date =  '';
								$scope.customer.pic ='',
								$scope.customer.property = [{
									   'prop_id':'0',
										area:'',
										address:'',
										category:''
									}]  ;
								
								$scope.customer.id = '';
								// $scope.customer.property =
								// $scope.customerlist[0].property;
							}

							
						}, function error(response) {
							$scope.postResultMessage = "Error Status: " +  response.statusText;
						});
					  
					  }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////			 
			// Success msg
				function contMSG(title, msg, icon,state,align) {
					var placementFrom = 'top';
					var placementAlign = align;
					var state = state;
					var content = {};
					content.message = msg;
					content.title = title;
					content.url = '#';
					content.icon = icon;
					$.notify(content, {
						type : state,
						placement : {
							from : placementFrom,
							align : placementAlign
						},
						time : 1000,
						delay : 2000,
						z_index: 5000,
					});
				} 
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////				
				// show and hide div for upload files
				$('.Show').click(function() {
				    $('#target').show(500);
				    $('.Show').hide(0);
				    $('.Hide').show(0);
				});
				$('.Hide').click(function() {
				    $('#target').hide(500);
				    $('.Show').show(0);
				    $('.Hide').hide(0);
				});
				$('.toggle').click(function() {
				    $('#target').toggle('slow');
				});
		/*
		 * 
		 * $('.datepicker').datetimepicker({ format: 'DD/MM/YYYY', });
		 */
			
			
			
			
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			  // The width and height of the captured photo. We will set the
			  // width to the value defined here, but the height will be
			  // calculated based on the aspect ratio of the input stream.

			  var width = 320;    // We will scale the photo width to this
			  var height = 0;     // This will be computed based on the input
									// stream

			  // |streaming| indicates whether or not we're currently
				// streaming
			  // video from the camera. Obviously, we start at false.

			  var streaming = false;

			  // The various HTML elements we need to configure or control.
				// These
			  // will be set by the startup() function.

			  var video = null;
			  var canvas = null;
			  var photo = null;
			  var startbutton = null;
			  video = document.getElementById('video');
			    canvas = document.getElementById('canvas');
			    photo = document.getElementById('photo');
			    startbutton = document.getElementById('startbutton');
			  function startup() {
			    
			   

			    video.addEventListener('canplay', function(ev){
			      if (!streaming) {
			        height = video.videoHeight / (video.videoWidth/width);
			      
			        // Firefox currently has a bug where the height can't be
					// read from
			        // the video, so we will make assumptions if this happens.
			      
			        if (isNaN(height)) {
			          height = width / (4/3);
			        }
			      
			        video.setAttribute('width', width);
			        video.setAttribute('height', height);
			        canvas.setAttribute('width', width);
			        canvas.setAttribute('height', height);
			        streaming = true;
			      }
			    }, false);

			    startbutton.addEventListener('click', function(ev){
			      takepicture();
			      ev.preventDefault();
			    }, false);
			    
			    clearphoto();
			  }

			  // Fill the photo with an indication that none has been
			  // captured.

			  function clearphoto() {
			    var context = canvas.getContext('2d');
			    context.fillStyle = "#AAA";
			    context.fillRect(0, 0, canvas.width, canvas.height);

			    var data = canvas.toDataURL('image/png');
			    photo.setAttribute('src', data);
			  }
			  
			  // Capture a photo by fetching the current contents of the video
			  // and drawing it into a canvas, then converting that to a PNG
			  // format data URL. By drawing it on an offscreen canvas and
				// then
			  // drawing that to the screen, we can change its size and/or
				// apply
			  // other changes before drawing it.

			  $scope.takepicture1 = function() {
				// alert("hi");
				  height = video.videoHeight / (video.videoWidth/width);
			      
			        // Firefox currently has a bug where the height can't be
					// read from
			        // the video, so we will make assumptions if this happens.
			      
			        if (isNaN(height)) {
			          height = width / (4/3);
			        }
			      
			        video.setAttribute('width', width);
			        video.setAttribute('height', height);
			        canvas.setAttribute('width', width);
			        canvas.setAttribute('height', height);
				  navigator.mediaDevices.getUserMedia({video: true, audio: false})
				    .then(function(stream) {
				      video.srcObject = stream;
				      video.play();
				    })
				    .catch(function(err) {
				      console.log("An error occurred: " + err);
				    });
			  }
			  
			  var myimgss ;
			  
			  function base64toBlob(base64Data, contentType) {
				    contentType = contentType || '';
				    var sliceSize = 1024;
				    var byteCharacters = atob(base64Data);
				    var bytesLength = byteCharacters.length;
				    var slicesCount = Math.ceil(bytesLength / sliceSize);
				    var byteArrays = new Array(slicesCount);

				    for (var sliceIndex = 0; sliceIndex < slicesCount; ++sliceIndex) {
				        var begin = sliceIndex * sliceSize;
				        var end = Math.min(begin + sliceSize, bytesLength);

				        var bytes = new Array(end - begin);
				        for (var offset = begin, i = 0; offset < end; ++i, ++offset) {
				            bytes[i] = byteCharacters[offset].charCodeAt(0);
				        }
				        byteArrays[sliceIndex] = new Uint8Array(bytes);
				    }
				    return new Blob(byteArrays, { type: contentType });
				}
			
			  $scope.takepicture = function() {
				// alert("hi");
				
			    var context = canvas.getContext('2d');
			    if (width && height) {
			      canvas.width = width;
			      canvas.height = height;
			      context.drawImage(video, 0, 0, width, height);
			    
			      var data = canvas.toDataURL('image/png');
			      photo.setAttribute('src', data);
			     // myimgss = data;
			     myimgss = data.replace(/^data:image\/(png|jpg);base64,/, "")
			      $scope.file = data.replace(/^data:image\/(png|jpg);base64,/, "");
			     $scope.customer.file = data.replace(/^data:image\/(png|jpg);base64,/, "");
			     $scope.customer.pic = data.replace(/^data:image\/(png|jpg);base64,/, "");
			     
			     // $scope.customer.pic = data;
			     video.srcObject.getVideoTracks().forEach(track => track.stop());
			      
			    } else {
			      clearphoto();
			    }
			  }

			  // Set up our event listener to run the startup process
			  // once loading is complete.
			 // window.addEventListener('load', startup, false);
			  function base64toBlob(base64Data, contentType) 
			  {
				    contentType = contentType || '';
				    var sliceSize = 1024;
				    var byteCharacters = atob(base64Data);
				    var bytesLength = byteCharacters.length;
				    var slicesCount = Math.ceil(bytesLength / sliceSize);
				    var byteArrays = new Array(slicesCount);

				    for (var sliceIndex = 0; sliceIndex < slicesCount; ++sliceIndex) {
				        var begin = sliceIndex * sliceSize;
				        var end = Math.min(begin + sliceSize, bytesLength);

				        var bytes = new Array(end - begin);
				        for (var offset = begin, i = 0; offset < end; ++i, ++offset) {
				            bytes[i] = byteCharacters[offset].charCodeAt(0);
				        }
				        byteArrays[sliceIndex] = new Uint8Array(bytes);
				    }
				    return new Blob(byteArrays, { type: contentType });
			 }
			 
//////////////////////////////////////////////////for sandrabh search////////////////////////////////////////////////////////////////////////////////////////////////////
			$scope.customer.id = '';
		//	$scope.selectname='';
			$scope.papdetails=function()
			{
					   $scope.paplist = [];
					   
					// console.log($scope.customer.id +"select user name");
					   
					   var url = 'papdetails/'+$scope.customer.id;
						
						var config = {
				               headers : {
				                   'Content-Type': 'application/json;charset=utf-8;'
				               }
				       }
						$http.get(url).then(function (response)
								{
						
						
								// alert("hii");
								$scope.paplist = response.data;
								
							//	console.log("PAP Details: "+JSON.stringify(response.data));
								$scope.adhaarCard = response.data.adhaarCard;
								//$scope.adhaarCard = $scope.paplist[0].adhaarCard;
								$scope.bdate = response.data.bdate;
								$scope.c_address = response.data.c_address;
								$scope.contact_number = response.data.contact_number;
								$scope.email = response.data.email;
								$scope.contact_number = response.data.contact_number;
								$scope.gender = response.data.gender;
								$scope.name = response.data.name;
								$scope.p_address = response.data.p_address;
								$scope.update_date = response.data.update_date;
								$scope.pic = response.data.pic;
								$scope.property = response.data.property;
								$scope.property.id= response.data.property[0];
								//$scope.villagename = response.data.villagename
							//	$scope.property.villages_id=response.data.property[0];
							    $scope.myimgs = response.data.pic;
							//console.log($scope.villagename+"$scope.property.villlages");
						}, function error(response) {
							$scope.postResultMessage = "Error Status: " +  response.statusText;
						});
					  
			}
			
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////			
			
		//FILE UPLOAD	
			
			/*$scope.uploadFile = function() {

				   alert("hello");
			        var file = document.getElementById('file').files[0];
			        console.log('file is ' );
			        console.log(file);

			        var uploadUrl = "/doupload";

			        var fd = new FormData();
			        fd.append('uploadfile', file);
			         
			        $http.post(uploadUrl, fd, {
			           transformRequest: angular.identity,
			           headers: {'Content-Type': undefined}
			        })

			        .success(function(){
			        	Coneole.loe("success");
			        	console.log(JSON.stringify(fd) +"data");
			        })

			        .error(function(){
			        	console("error");
			        	console.log(JSON.stringify(fd) +"data");
			        });
			    }*/
			
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////			
			  // villageList
			   function villagelist()
			   {
					   $scope.villages1 = [];
					   var url = 'villagelist';
						
						var config = {
				               headers : {
				                   'Content-Type': 'application/json;charset=utf-8;'
				               }
				       }
						$http.get(url).then(function (response) {
								$scope.villages1 = response.data;
							
							console.log(response.data);
						}, function error(response) {
							$scope.postResultMessage = "Error Status: " +  response.statusText;
						});
					  
					  }
			   villagelist();
			   
			
		
			  
			  $(".selPAP").select2();
			
			  $('.datepicker-default').datepicker({
				  timeZone: '',
				  format: 'dd/mm/yyyy'
			  });
			  
			  
			
				
			  
			  
});