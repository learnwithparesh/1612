// CONTROLLER UPLOAD FILE
myapp.controller('importexcelController', ['$scope', '$http', function($scope, $http){
    $scope.doUploadFile = function(){
       var file = $scope.files[0];
       var url = "/api/fileUpload";
       
       var data = new FormData();
       data.append('uploadfile', file);
       data.append('insertby', $scope.insertby);
       
       var config = {
    	   	transformRequest: angular.identity,
    	   	transformResponse: angular.identity,
	   		headers : {
	   			'Content-Type': undefined
	   	    }
       }
       console.log("data"+JSON.stringify(data));
       $http.post(url, data, config).then(function (response) {
			$scope.uploadResult=response.data;
		}, function (response) {
			$scope.uploadResult=response.data;
		});
    };
}]);