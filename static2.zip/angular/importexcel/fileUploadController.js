// CONTROLLER UPLOAD FILE
fileUploadApp.controller('fileUploadController', ['$scope', '$http', function($scope, $http){
    $scope.doUploadFile = function(){
       var file = $scope.uploadedFile[0];
       var url = "/FileUpload/api/fileUpload";
       
       var data = new FormData();
       data.append('uploadfile', $scope.uploadedFile[0]);
    
       var config = {
    	   	transformRequest: angular.identity,
    	   	transformResponse: angular.identity,
	   		headers : {
	   			'Content-Type': undefined
	   	    }
       }
       console.log(JSON.stringify(data));
       $http.post(url, data, config).then(function (response) {
			$scope.uploadResult=response.data;
		}, function (response) {
			$scope.uploadResult=response.data;
		});
    };
}]);