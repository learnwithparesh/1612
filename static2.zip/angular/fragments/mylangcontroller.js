myapp.controller("mylangcontroller", function($scope, $http, $window,
	$localStorage, $filter, $compile, ServiceTaskTracker, $routeParams, $timeout,$translate) {
	
	$scope.language = sessionStorage.getItem("mylang");
	  
	$scope.changeLanguage = function(lang){
	   $translate.use(lang); 
	   sessionStorage.setItem('mylang',lang);

	  }
	if($scope.language)
	{
		//alert("hi");
		$scope.changeLanguage($scope.language);	
		
	}
	
});
