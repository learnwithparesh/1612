var myapp = angular.module("myapp", ['ngRoute','ngStorage','angular-fullcalendar','ui.bootstrap','angucomplete-alt','chart.js','pascalprecht.translate','datatables', 'datatables.buttons','datatables.columnfilter','xeditable','angularjs-datetime-picker']);

myapp.config(function($routeProvider, $locationProvider,$translateProvider) {
    $routeProvider
   .when("/", {
    	 mytext:"login",
    	 mytext1:"wrapper-login",
        templateUrl : "angular/login/login.html",
        controller: 'loginController'
    })
    .when("/test", {
        templateUrl : "angular/test.html"
    })
    .when("/empdashboard", {
        templateUrl : "angular/empdashboard/empdashboard.html",
        controller : "empdashboardCtrl"
    })
    .when("/taskreport", {
        templateUrl : "angular/taskreport/searchresult.html",
        controller : "taskReoprtCtrl"
    })
    .when("/addcustomer", {
        templateUrl : "angular/addcustomer/addcustomer.html",
        controller : "addcustomerController"
    })
    
    .when("/addproperty", {
        templateUrl : "angular/addproperty/addproperty.html",
        controller : "addpropertyController"
    })
    
    .when("/addtasks/:dates", {
        templateUrl : "angular/addtask/addtask.html",
        controller : "addtaskController"
    })
    .when("/addtasks", {
        templateUrl : "angular/addtask/addtask.html",
        controller : "addtaskController"
    }) 
    .when("/holidays", {
        templateUrl : "angular/holidays/holiday.html",
        controller : "addholidays"
    })
    
     .when("/addleave", {
        templateUrl : "angular/addleave/addleave.html",
        controller : "addleave"
    })
       .when("/addemployee", {
        templateUrl : "angular/employeeRegistration/employee.html",
        controller : "addEmployeeCtrl"
    })
      .when("/searching/:id", {
        templateUrl : "angular/searchResult/searchresult.html",
        controller : "empdashboardCtrl"
    })
     .when("/addproject", {
        templateUrl : "angular/project/project.html",
        controller : "addprojectController"
    })
    .when("/printdetails", {
        templateUrl : "angular/Print/papdetails.html",
        controller :  "printCtrl"
    })
    
      .when("/searchdetails", {
        templateUrl : "angular/searchResult/searchresult.html",
        controller :  "search1Controller"
    })
    
     .when("/myreports", {
        templateUrl : "angular/myreport/reports.html",
        controller : "myreportsController"
    })
      .when("/sandrabhreports", {
        templateUrl : "angular/sandarbhreports/reports.html",
        controller : "sandrabhreportsController"
    })
     .when("/tapalreports", {
        templateUrl : "angular/tapalreports/reports.html",
        controller : "tapalreports"
    })
    .when("/testauto", {
        templateUrl : "angular/autocomplete/autocomplete.html",
        controller : "reportsController"
    })
      .when("/testpanel", {
        templateUrl : "angular/addtask/addtask2.html",
        controller : "addtaskController"
    })
    
     .when("/filesdetails", {
        templateUrl : "angular/FileDetailsView/filedetails.html",
        controller : "filesdetailsctrl"
    })
    
      .when("/reportsSandarbh", {
        templateUrl : "angular/reportsSandarbh/sandarbhReports.html",
        controller : "reportsSandrabhCtrl"
    })
    .when("/reportstapal", {
        templateUrl : "angular/newTapalReports/tapalreports.html",
        controller : "tapalreportsnew"
    })
    .when("/importexcel", {
        templateUrl : "angular/importexcel/importexcel.html",
        controller : "importexcelController"
    })
    .otherwise({
    	templateUrl : "angular/login/login.html",
        controller: 'loginController'
  });
    
    /* 
    })*/
     
    
    
    /*
     $locationProvider.html5Mode({
    	 enabled: true,
    	 requireBase: false
    	});*/
    var en_translations = {
    	    "language"  : "Selected Language English",
    	    "greeting"  : "Welcome Dinesh",
    	    "dashboard" :"Dashboard",
    	    "Projects"	:"Projects",
    	    "Customers" :"PAP",
    	    "Employees" :"Employees",
    	    "Tasks"     : "Tasks",
    	    "Calender"  : "Calender",
    	    "Table"     : "Table",
    	    "Task Details" :"Task Details",
    	    "Start Date" :"Start Date",
    	    "End Date"   :"End Date",
    	    "Task id"    :"Task id",
    	    "Insert date":"Date",
    	    "Description" :"Description",
    	    "Task Name" :"Task Name",
    	    "Customer Name":"PAP Name",
    	    "Phone Number":"Phone Number",
    	    "Property Id" :"Property Id",
    	    "Update Date" :"Update Date",
    	    "Workflow" :"Workflow",
    	    "Next Date":"Next Date",
    	    "Assign To":"Assign To",
    	    "Close Task":"Close Task",
    	    "Reject" :"Reject",
    	    "Send to next Table" :"Send to next Table",
    	    "Set Next FinalDate":"Set Next FinalDate",
    	    "Next Date" :"Next Date",
    	    "Assign" : "Assign",
            "Task Info" :"Task Info",
            "RTI" :"RTI",
            "Court Case"  :"Court Case",
            "Tapal/Post" :"Tapal/Post",
    	    "Customer Info" :"PAP",
    	    "Adhaar Card" :"Adhaar Card",
    	    "Name" :"Name",
    	    "Gender" :"Gender",
    	    "Date of Birth":"Date of Birth",
    	    "Email Address" :"Email Address",
    	    "Current Address": "Current Address",
    	    "Permanent Address" :"Permanent Address",
    	    "Add Property" :"Add Property",
    	    "Case Number":"Case Number",
    	    "Court Status" :"Court Status",
    	    "Address":"Address",
    	    "CustomerInfo" :"PAP",
    	    "Cancel" :"Cancel",
    	    "File Id" :"File Id",
    	    "Inward Number" :"Inward Number",
    	    "Inward Date" :"Inward Date",
    	    "Letter Date" :"Letter Date",
    	    "Arrived From" :"Arrived From",
    	    "Sender" :"Sender",
    	    "Letter Type" :"Letter Type",
    	    "Letter Subject" :"Letter Subject",
    	    "Branch" :"Branch",
    	    "Type of Letter Delivery" :"Type of Letter Delivery",
    	    "Task Type" :"Task Type",
    	    "Property":"Property",
    	    "Project Name" :"Project Name",
    	    "Project Code":"Project Code",
    	    "Team Head" :"Team Head", 
    	    "Address":"Address",
    	    "Add Team Members" :"Add Team Members",
    	    "Team Member":"Team Member",
    	    "Project Info":"Project Info",
    	    "Employee Info":"Employee Info",
    	    "Employee First Name" :"Employee First Name",
    	    "Employee Middle Name" :"Employee Middle Name",
    	    "Employee Last Name":"Employee Last Name",
    	    "Role" :"Role",
    	    "Email" :"Email",
    	    "Password" :"Password",
    	    "Employee" :"Employee",
    	    "Assign" :"Assign",
    	    "ID":  "ID",
    	    "CustomerInfo1" :"Add PAP",
    	     "Workdone":"Workdone",
    	     "Received":"Received",
    	     "Report Result":"Report Result",
    	     "Report Details":"Report Details",
    	     "Status":"Status",
    	     "On Camera":"On Camera",
    	     "Take photo":"Take photo",
    	     "Add Task":"Add Task",
    	     "Cancel":"Cancel",
    	     "Add Leave": "Add Leave",
    	     "Leave Info" :"Leave Info",
    	    "Leave From" :"Leave From",
    	    "Official Meeting Start Time" :"Official Meeting Start Time",
    	    "Official Meeting End Time" :"Official Meeting End Time",
    	    "Leave To" :"Leave To",
    	    "Add Project":"Project",
    	    "Receipt ID" :"Receipt ID",
    	    "Tahsildar":"Tahsildar",
    	    "Task summary":"Task summary",
    	    "Submitted by":"Submitted by",
    	    "Submitted To":"Submitted To",
             "Receipt":"Receipt",
             "Collector Office":"Collector Office",
             "pune":"Pune",
             "ID Proof" :"ID Proof",
             "Registered No":"Registered No",
             "Rehabilitation Branch":"Rehabilitation Branch",
             "email": "Email",
             "Photo":"Photo",
             "020-26121001":"020-26121001",
             "Village":"Village",
              "Tapal":"Tapal",
              "PAPSandrabhId":"PAP Sandrabh Id",
              "view":"view",
              "startdate":"Start Date",
              "Assigned":"Assigned",
              "Pending":"Pending",
              "Rejected":"Rejected",
              "Completed":"Completed",
              "Assign Date":"Assign Date"
            
    	    
    	  }
    	  
    	  var sp_translations = {
    	    "language"  : "Selected Language Spanish",
    	    "greeting"  : "डॅशबोर्ड", 
    	    "dashboard" :"डॅशबोर्ड",
            "Projects"  :"प्रकल्प ",
            "Customers" :"प्रकल्पग्रस्त/ अर्जदार",
            "Employees" :"कर्मचारी",
            "Tasks"     :"संदर्भ ",
            "Calender"  :"कॅलेंडर",
            "Table"     :"टेबल",
            "Task Details":"संदर्भ  तपशील",
            "Start Date":"कालावधी ",
            "End Date"  :"अंतिम",
            "Task id" :"कार्य आयडी",
            "Insert date" :"तारीख ",
            "Description" :"विशेष सुचना",
            "Task Name" :"संदर्भ",
            "Customer Name" :"ग्राहकाचे नाव",
            "Phone Number" :"संपर्क क्रमांक",
            "Property Id":"गट क्रमांक",
            "Update Date":"अद्यतन तारीख",
            "Workflow":"कार्य प्रवाह",
            "Next Date": "पुढील तारीख",
            "Assign To": "यांना नियुक्त करा",
            "Close Task":"कार्य बंद करा",
            "Reject":"नाकारू",
            "Send to next Table" :"पुढील सारणीवर पाठवा",
            "Set Next FinalDate":"पुढील अंतिम तारीख सेट करा",
            "Next Date":"पुढील तारीख",
            "Assign" :"नियुक्त करा",
            "Task Info" :"कार्य माहिती",
            "RTI" :"आरटीआय",
            "Court Case" :"न्यायालयीन खटला",
            "Tapal/Post" :"तापल / पोस्ट",
            "CustomerInfo" :"अर्जदार माहिती ",
            "Adhaar Card" :"आधार कार्ड",
            "Name" : "नाव",
            "Gender" :"लिंग",
            "Date of Birth" :"जन्मतारीख",
            "Email Address" :"ईमेल पत्ता",
            "Current Address" :"सध्याचा पत्ता",
            "Permanent Address":"कायमचा पत्ता",
            "Add Property" :"जमीन  दाखला",
            "Case Number" :"केस नंबर",
            "Court Status" :"न्यायालयाची स्थिती",
            "Address" :"पत्ता",
            "Customer Info" :"अर्जदार माहिती ",
            "Cancel" :"रद्द करा",
            "File Id":"फाइल आयडी",
            "Inward Number" :"आवक क्रमांक ",
            "Inward Date" :"आवक दिनांक ",
            "Letter Date" :"पत्राचा दिनांक ",
            "Arrived From" :"कोठून आले ",
            "Sender" :"पाठविणाऱ्याचे नाव ",
            "Letter Type":"पत्र प्रकार ",
            "Letter Subject" :"पत्राचा विषय",
            "Branch":"शाखेची माहिती ",
            "Type of Letter Delivery" :"पत्रव्यवहाराचा प्रकार ",
            "Task Type":"विषय ",
            "Property" : "गट क्रमांक",
            "Project Name":"प्रकल्प नाव ",
            "Project Code" :"प्रकल्प क्रमांक ",
            "Team Head" :"पुनर्वसन अधिकारी ",
            "Address":"पत्ता ",
            "Add Team Members":"इतर कार्यालयीन अधिकारी/कर्मचारी ",
            "Team Member":"इतर कार्यालयीन अधिकारी/कर्मचारी ",
            "Project Info" :"प्रकल्प माहिती",
            "Employee Info":"कर्मचाऱ्याचा पत्ता ",
            "Employee First Name":"कर्मचाऱ्याचे पहिले नाव ",
            "Employee Middle Name" :"कर्मचाऱ्याचे मधले नाव ",
             "Employee Last Name" :"कर्मचाऱ्याचे आडनाव ",
             "Role":"भूमिका / कामाचे स्वरूप ",
             "Email" :"इमेल पत्ता ",
             "Password":"पासवर्ड ",
             "Employee" : "कर्मचाऱ्याचा",
             "Assign" :"नियुक्त कर",
             "ID" :"आयडी",
         	"CustomerInfo1" :"जतन करा ",
         	 "Workdone":"कार्य पूर्ण",
         	 "Received":"आलेले कार्य",
         	 "Report Result":"अहवाल परिणाम",
         	 "Report Details":"अहवाल तपशील",
         	 "Status":"स्थिती",
         	 "On Camera":"कॅमेरा चालू  करा ",
         	 "Take photo":"छायाचित्र घे",
         	 "Add Task":"जमा करा",
         	 "Cancel":"रद्द करा",
         	 "Add Leave":"रजा",
             "Leave Info":"रजे संदर्भातील माहिती ",
             "Leave From":"रजा घेण्याचा कालावधी ",
             "Leave To":"सुट्टी दर्शवा ",
             "Official Meeting Start Time":"कार्यालयीन बैठकीचा कालावधी ",
             "Official Meeting End Time":"कार्यालयीन बैठकीचा समाप्ती वेळ",
             "Add Project":"प्रकल्प",
             "Receipt ID":"पावती क्रं.",
             "Tahsildar":"तहसीलदार",
             "Task summary":"कार्य सारांश",
             "Submitted by":"सादर करणारा",
             "Submitted To":"कार्यवाही करिता",
             "Receipt":"पावती",
             "Collector Office":"जिल्हाधिकारी कार्यालय",
             "pune":"पुणे",
             "ID Proof":"ओळखपत्र क्रं ",
             "Registered No":"नोंदणी  क्रं",
             "Rehabilitation Branch":"पुनर्वसन शाखा",
             "email":"ई मेल ",
             "Photo":"छायाचित्र",
             "020-26121001":"०२०-२६१२१००१",
             "Village":"गावं",
             "Tapal":"टपाल",
             "PAPSandrabhId":"PAP संदर्भ क्रं",
             "view":"उघडा",
             "startdate":"कार्यवाही दिनांक  ",
             "Assigned":"नियुक्त केलेले ",
             "Pending":"प्रलंबित ",
             "Rejected":"रद्द",
             "Completed":"पूर्ण ",
             "Assign Date":"नियुक्त तारीख"
         
           
             
    	  }
    	  
    	  $translateProvider.translations('en',en_translations);
    	  
    	  $translateProvider.translations('sp',sp_translations);
    	  
    	  $translateProvider.preferredLanguage('en');
    	  
    	  $translateProvider.useSanitizeValueStrategy(null);
  
 
});

myapp.directive("myMainHeader", function() {
	  return {
		 // restrict: 'E',
	    templateUrl : "/angular/fragments/mainheader.html",
	    restrict: 'E',
	    replace: true
	  };
});
myapp.directive("myNavbar", function() {
	  return {
		 // restrict: 'E',
	    templateUrl : "/angular/fragments/navbar.html",
	    restrict: 'E',
	    replace: true
	  };
});
myapp.directive("mySidebar", function() {
	  return {
		 // restrict: 'E',
	    templateUrl : "/angular/fragments/sidebar.html",
	    restrict: 'E',
	    replace: true
	  };
});
myapp.directive("myFooter", function() {
	  return {
		 // restrict: 'E',
	    templateUrl : "/angular/fragments/footer.html",
	    restrict: 'E',
	    replace: true
	  };
});

var dateTimePicker = function() {
    return {
        restrict: "A",
        require: "ngModel",
        link: function (scope, element, attrs, ngModelCtrl) {
            var parent = $(element).parent();
            var dtp = parent.datetimepicker({
               /* format: "LL",
                showTodayButton: true*/
            });
            dtp.on("dp.change", function (e) {
                ngModelCtrl.$setViewValue(moment(e.date).format("LL"));
                scope.$apply();
            });
        }
    };
};

myapp.directive('dateTimePicker', dateTimePicker);




//parse a date in dd-mm-yyyy format
function parseDate(input) {
var parts = input.split('/');
// Note: months are 0-based
return new Date(parts[2], parts[1]-1, parts[0]); 
}

myapp.filter("myfilter1", function() {
return function(items, from, to) {
	  
	//  console.log(parseDate(from));
	 // console.log(parseDate(to)+"hj");
	  var df = moment(from);
	  var dt = moment(to);

     // console.log("fm :"+df);
	 // console.log("to :"+dt);
      var arrayToReturn = [];        
      for (var i=0; i<items.length; i++){
          var tf =  moment(items[i].startDate).format("LL"),
              tt = new Date(items[i].endDate * 1000);
         // var df =  new Date(items[i].startDate);
        //  console.log(df);
//          console.log("jk"+moment(items[i].startDate).format("LL")+"original"+moment(items[i].startDate)+"tt"+tt);
          
         var s =  moment(items[i].startDate).isBetween(df,dt);
          if (s)  {
              arrayToReturn.push(items[i]);
          }
      }
      
      return arrayToReturn;
};
});
/*
myapp.directive('mydirective', function() {
	return {
		restrict:'E',
		transclude:'true',
		 scope: {
		      alert: '&'
		    },
		 controller: function($scope){
		      $scope.value = 'directive scope value';
		    },
		    
		    template: '<button ng-click="alert({message: value})">Alert</button>',
	    template: '<span ng-transclude></span>',
	    
	    link:function(scope){
	    	element .append("<strong>"+attr.title+"<strong>")
	        }
	  };
	});
*/


/*myapp.directive('myDirective', function(){
	  return {
	    restrict: 'E',
	    scope: {
	      alert: '&'
	    },
	    controller: function($scope){
	      $scope.value = 'directive scope value';
	    },
	    template: '<button ng-click="alert({message: value})">Alert</button>'
	  }
	});*/

/*$scope.clickNoti = function(nid) {	
	//	$scope.getEvents();		
		$scope.clickUpload(nid);		
	}
*/

/*myapp.controller("translateController" ,["$scope","$translate",function($scope,$translate){
	 $scope.changeLanguage(sessionStorage.getItem('mylang'));
	  $scope.changeLanguage = function(lang){
	   $translate.use(lang); 
	   sessionStorage.setItem('mylang',lang);

	  }
	}]);
*/

/*myapp.directive('psDatetimePicker', function (moment) {
    var format = 'MM/DD/YYYY hh:mm A';

    return {
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, element, attributes, ctrl) {
            element.datetimepicker({
                format: format
            });
            var picker = element.data("DateTimePicker");

            ctrl.$formatters.push(function (value) {
                var date = moment(value);
                if (date.isValid()) {
                    return date.format(format);
                }
                return '';
            });

            element.on('change', function (event) {
                scope.$apply(function() {
                    var date = picker.getDate();
                    ctrl.$setViewValue(date.valueOf());
                });
            });
        }
    };
});*/
myapp.directive('pagination', function() {
	  return {
		    restrict: 'E',
		    scope: {
		      numPages: '=',
		      currentPage: '=',
		      onSelectPage: '&'
		    },
		    templateUrl: 'pagination.html',
		    replace: true,
		    link: function(scope) {
		      scope.$watch('numPages', function(value) {
		        scope.pages = [];
		        for(var i=1;i<=value;i++) {
		          scope.pages.push(i);
		        }
		        if ( scope.currentPage > value ) {
		          scope.selectPage(value);
		        }
		      });
		      scope.noPrevious = function() {
		        return scope.currentPage === 1;
		      };
		      scope.noNext = function() {
		        return scope.currentPage === scope.numPages;
		      };
		      scope.isActive = function(page) {
		        return scope.currentPage === page;
		      };

		      scope.selectPage = function(page) {
		        if ( ! scope.isActive(page) ) {
		          scope.currentPage = page;
		          scope.onSelectPage({ page: page });
		        }
		      };

		      scope.selectPrevious = function() {
		        if ( !scope.noPrevious() ) {
		          scope.selectPage(scope.currentPage-1);
		        }
		      };
		      scope.selectNext = function() {
		        if ( !scope.noNext() ) {
		          scope.selectPage(scope.currentPage+1);
		        }
		      };
		    }
		  };
		});

  
// DIRECTIVE - FILE MODEL
myapp.directive('fileModel', ['$parse', function ($parse) {
	return {
	    restrict: 'A'
		, link: function (scope, element, attrs) {
		var model = $parse(attrs.fileModel);
		var modelSetter = model.assign;
		element.bind('change', function () {
			var files = [];
	     	angular.forEach(element[0].files,function(file){
               files.push(file);
			})
			scope.$apply(function () {
		     	modelSetter(scope, files);
			 });
			});
		}
	};
  }]);